class CategoryModel {
  const CategoryModel({
    required this.id,
    required this.name,
    required this.iconName,
  });

  final String id;
  final String name;
  final String iconName;

  factory CategoryModel.fromJson(Map<String, dynamic> json) {
    return CategoryModel(
      id: json['id'] as String? ?? '',
      name: json['name'] as String? ?? '',
      iconName: json['iconName'] as String? ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'iconName': iconName,
    };
  }

  CategoryModel copyWith({String? id, String? name, String? iconName}) {
    return CategoryModel(
      id: id ?? this.id,
      name: name ?? this.name,
      iconName: iconName ?? this.iconName,
    );
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        other is CategoryModel &&
        other.id == id &&
        other.name == name &&
        other.iconName == iconName;
  }

  @override
  int get hashCode => Object.hash(id, name, iconName);
}
