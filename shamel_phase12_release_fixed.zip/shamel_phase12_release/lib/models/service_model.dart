class ServiceModel {
  const ServiceModel({
    required this.id,
    required this.providerId,
    required this.categoryId,
    required this.title,
    required this.description,
    required this.price,
  });

  final String id;
  final String providerId;
  final String categoryId;
  final String title;
  final String description;
  final double price;

  factory ServiceModel.fromJson(Map<String, dynamic> json) {
    return ServiceModel(
      id: json['id'] as String? ?? '',
      providerId: json['providerId'] as String? ?? '',
      categoryId: json['categoryId'] as String? ?? '',
      title: json['title'] as String? ?? '',
      description: json['description'] as String? ?? '',
      price: (json['price'] as num?)?.toDouble() ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'providerId': providerId,
      'categoryId': categoryId,
      'title': title,
      'description': description,
      'price': price,
    };
  }

  ServiceModel copyWith({String? id, String? providerId, String? categoryId, String? title, String? description, double? price}) {
    return ServiceModel(
      id: id ?? this.id,
      providerId: providerId ?? this.providerId,
      categoryId: categoryId ?? this.categoryId,
      title: title ?? this.title,
      description: description ?? this.description,
      price: price ?? this.price,
    );
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        other is ServiceModel &&
        other.id == id &&
        other.providerId == providerId &&
        other.categoryId == categoryId &&
        other.title == title &&
        other.description == description &&
        other.price == price;
  }

  @override
  int get hashCode => Object.hash(id, providerId, categoryId, title, description, price);
}
