class OrderModel {
  const OrderModel({
    required this.id,
    required this.userId,
    required this.serviceId,
    required this.status,
    required this.createdAt,
  });

  final String id;
  final String userId;
  final String serviceId;
  final String status;
  final String createdAt;

  factory OrderModel.fromJson(Map<String, dynamic> json) {
    return OrderModel(
      id: json['id'] as String? ?? '',
      userId: json['userId'] as String? ?? '',
      serviceId: json['serviceId'] as String? ?? '',
      status: json['status'] as String? ?? '',
      createdAt: json['createdAt'] as String? ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'userId': userId,
      'serviceId': serviceId,
      'status': status,
      'createdAt': createdAt,
    };
  }

  OrderModel copyWith({String? id, String? userId, String? serviceId, String? status, String? createdAt}) {
    return OrderModel(
      id: id ?? this.id,
      userId: userId ?? this.userId,
      serviceId: serviceId ?? this.serviceId,
      status: status ?? this.status,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        other is OrderModel &&
        other.id == id &&
        other.userId == userId &&
        other.serviceId == serviceId &&
        other.status == status &&
        other.createdAt == createdAt;
  }

  @override
  int get hashCode => Object.hash(id, userId, serviceId, status, createdAt);
}
