class AdModel {
  const AdModel({
    required this.id,
    required this.title,
    required this.subtitle,
    this.imageUrl,
    required this.isActive,
  });

  final String id;
  final String title;
  final String subtitle;
  final String? imageUrl;
  final bool isActive;

  factory AdModel.fromJson(Map<String, dynamic> json) {
    return AdModel(
      id: json['id'] as String? ?? '',
      title: json['title'] as String? ?? '',
      subtitle: json['subtitle'] as String? ?? '',
      imageUrl: json['imageUrl'] as String?,
      isActive: json['isActive'] as bool? ?? false,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'subtitle': subtitle,
      'imageUrl': imageUrl,
      'isActive': isActive,
    };
  }

  AdModel copyWith({String? id, String? title, String? subtitle, String? imageUrl, bool? isActive}) {
    return AdModel(
      id: id ?? this.id,
      title: title ?? this.title,
      subtitle: subtitle ?? this.subtitle,
      imageUrl: imageUrl ?? this.imageUrl,
      isActive: isActive ?? this.isActive,
    );
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        other is AdModel &&
        other.id == id &&
        other.title == title &&
        other.subtitle == subtitle &&
        other.imageUrl == imageUrl &&
        other.isActive == isActive;
  }

  @override
  int get hashCode => Object.hash(id, title, subtitle, imageUrl, isActive);
}
