class RatingModel {
  const RatingModel({
    required this.id,
    required this.orderId,
    required this.rating,
    this.comment,
  });

  final String id;
  final String orderId;
  final double rating;
  final String? comment;

  factory RatingModel.fromJson(Map<String, dynamic> json) {
    return RatingModel(
      id: json['id'] as String? ?? '',
      orderId: json['orderId'] as String? ?? '',
      rating: (json['rating'] as num?)?.toDouble() ?? 0,
      comment: json['comment'] as String?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'orderId': orderId,
      'rating': rating,
      'comment': comment,
    };
  }

  RatingModel copyWith({String? id, String? orderId, double? rating, String? comment}) {
    return RatingModel(
      id: id ?? this.id,
      orderId: orderId ?? this.orderId,
      rating: rating ?? this.rating,
      comment: comment ?? this.comment,
    );
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        other is RatingModel &&
        other.id == id &&
        other.orderId == orderId &&
        other.rating == rating &&
        other.comment == comment;
  }

  @override
  int get hashCode => Object.hash(id, orderId, rating, comment);
}
