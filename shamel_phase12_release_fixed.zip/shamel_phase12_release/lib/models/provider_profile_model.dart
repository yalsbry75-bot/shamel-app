class ProviderProfileModel {
  const ProviderProfileModel({
    required this.id,
    required this.userId,
    required this.businessName,
    required this.specialty,
    required this.rating,
  });

  final String id;
  final String userId;
  final String businessName;
  final String specialty;
  final double rating;

  factory ProviderProfileModel.fromJson(Map<String, dynamic> json) {
    return ProviderProfileModel(
      id: json['id'] as String? ?? '',
      userId: json['userId'] as String? ?? '',
      businessName: json['businessName'] as String? ?? '',
      specialty: json['specialty'] as String? ?? '',
      rating: (json['rating'] as num?)?.toDouble() ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'userId': userId,
      'businessName': businessName,
      'specialty': specialty,
      'rating': rating,
    };
  }

  ProviderProfileModel copyWith({String? id, String? userId, String? businessName, String? specialty, double? rating}) {
    return ProviderProfileModel(
      id: id ?? this.id,
      userId: userId ?? this.userId,
      businessName: businessName ?? this.businessName,
      specialty: specialty ?? this.specialty,
      rating: rating ?? this.rating,
    );
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        other is ProviderProfileModel &&
        other.id == id &&
        other.userId == userId &&
        other.businessName == businessName &&
        other.specialty == specialty &&
        other.rating == rating;
  }

  @override
  int get hashCode => Object.hash(id, userId, businessName, specialty, rating);
}
