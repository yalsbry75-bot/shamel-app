class SubscriptionModel {
  const SubscriptionModel({
    required this.id,
    required this.providerId,
    required this.planName,
    required this.status,
    this.expiresAt,
  });

  final String id;
  final String providerId;
  final String planName;
  final String status;
  final String? expiresAt;

  factory SubscriptionModel.fromJson(Map<String, dynamic> json) {
    return SubscriptionModel(
      id: json['id'] as String? ?? '',
      providerId: json['providerId'] as String? ?? '',
      planName: json['planName'] as String? ?? '',
      status: json['status'] as String? ?? '',
      expiresAt: json['expiresAt'] as String?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'providerId': providerId,
      'planName': planName,
      'status': status,
      'expiresAt': expiresAt,
    };
  }

  SubscriptionModel copyWith({String? id, String? providerId, String? planName, String? status, String? expiresAt}) {
    return SubscriptionModel(
      id: id ?? this.id,
      providerId: providerId ?? this.providerId,
      planName: planName ?? this.planName,
      status: status ?? this.status,
      expiresAt: expiresAt ?? this.expiresAt,
    );
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        other is SubscriptionModel &&
        other.id == id &&
        other.providerId == providerId &&
        other.planName == planName &&
        other.status == status &&
        other.expiresAt == expiresAt;
  }

  @override
  int get hashCode => Object.hash(id, providerId, planName, status, expiresAt);
}
