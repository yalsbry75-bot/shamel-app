class ReportModel {
  const ReportModel({
    required this.id,
    required this.reporterId,
    required this.targetId,
    required this.reason,
    required this.status,
  });

  final String id;
  final String reporterId;
  final String targetId;
  final String reason;
  final String status;

  factory ReportModel.fromJson(Map<String, dynamic> json) {
    return ReportModel(
      id: json['id'] as String? ?? '',
      reporterId: json['reporterId'] as String? ?? '',
      targetId: json['targetId'] as String? ?? '',
      reason: json['reason'] as String? ?? '',
      status: json['status'] as String? ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'reporterId': reporterId,
      'targetId': targetId,
      'reason': reason,
      'status': status,
    };
  }

  ReportModel copyWith({String? id, String? reporterId, String? targetId, String? reason, String? status}) {
    return ReportModel(
      id: id ?? this.id,
      reporterId: reporterId ?? this.reporterId,
      targetId: targetId ?? this.targetId,
      reason: reason ?? this.reason,
      status: status ?? this.status,
    );
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        other is ReportModel &&
        other.id == id &&
        other.reporterId == reporterId &&
        other.targetId == targetId &&
        other.reason == reason &&
        other.status == status;
  }

  @override
  int get hashCode => Object.hash(id, reporterId, targetId, reason, status);
}
