import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shamel/main.dart';

void main() {
  testWidgets('Shamel app starts with ProviderScope', (tester) async {
    await tester.pumpWidget(const ProviderScope(child: ShamelApp()));
    expect(find.text('شامل'), findsOneWidget);
  });
}
