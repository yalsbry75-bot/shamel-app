import 'package:flutter/material.dart';

import '../admin_panel/presentation/screens/admin_login_screen.dart';
import '../admin_panel/presentation/screens/admin_shell.dart';
import '../features/ads/presentation/screens/ad_details_screen.dart';
import '../features/ads/presentation/screens/ads_screen.dart';
import '../features/ads/presentation/screens/create_ad_screen.dart';
import '../features/auth/presentation/screens/account_type_screen.dart';
import '../features/auth/presentation/screens/login_screen.dart';
import '../features/auth/presentation/screens/onboarding_screen.dart';
import '../features/auth/presentation/screens/otp_screen.dart';
import '../features/auth/presentation/screens/splash_screen.dart';
import '../features/categories/presentation/screens/categories_screen.dart';
import '../features/categories/presentation/screens/search_screen.dart';
import '../features/home/presentation/screens/customer_shell.dart';
import '../features/orders/presentation/screens/create_order_screen.dart';
import '../features/orders/presentation/screens/order_details_screen.dart';
import '../features/orders/presentation/screens/orders_screen.dart';
import '../features/notifications/presentation/screens/notifications_screen.dart';
import '../features/profile/presentation/screens/profile_screen.dart';
import '../features/profile/presentation/screens/settings_screen.dart';
import '../features/profile/presentation/screens/support_screen.dart';
import '../features/release/presentation/screens/production_setup_required_screen.dart';
import '../features/provider/presentation/screens/business_profile_form_screen.dart';
import '../features/provider/presentation/screens/business_profile_screen.dart';
import '../features/provider/presentation/screens/provider_shell.dart';
import '../features/services/presentation/screens/service_details_screen.dart';

class AppRoutes {
  const AppRoutes._();

  static const splash = '/';
  static const onboarding = '/onboarding';
  static const login = '/login';
  static const otp = '/otp';
  static const accountType = '/account-type';
  static const customerShell = '/customer';
  static const providerShell = '/provider';
  static const businessProfile = '/provider/business-profile';
  static const businessProfileForm = '/provider/business-profile-form';
  static const categories = '/categories';
  static const search = '/search';
  static const serviceDetails = '/service-details';
  static const createOrder = '/create-order';
  static const orders = '/orders';
  static const orderDetails = '/order-details';
  static const notifications = '/notifications';
  static const profile = '/profile';
  static const ads = '/ads';
  static const createAd = '/ads/create';
  static const adDetails = '/ads/details';
  static const settings = '/settings';
  static const support = '/support';
  static const productionSetup = '/release/setup-required';
  static const adminLogin = '/admin/login';
  static const adminShell = '/admin';

  static Route<dynamic> onGenerateRoute(RouteSettings settings) {
    late final Widget page;
    switch (settings.name) {
      case splash:
        page = const SplashScreen();
        break;
      case onboarding:
        page = const OnboardingScreen();
        break;
      case login:
        page = const LoginScreen();
        break;
      case otp:
        page = const OtpScreen();
        break;
      case accountType:
        page = const AccountTypeScreen();
        break;
      case customerShell:
        page = const CustomerShell();
        break;
      case providerShell:
        page = const ProviderShell();
        break;
      case businessProfile:
        page = const BusinessProfileScreen();
        break;
      case businessProfileForm:
        page = const BusinessProfileFormScreen();
        break;
      case categories:
        page = const CategoriesScreen();
        break;
      case search:
        page = const SearchScreen();
        break;
      case serviceDetails:
        page = const ServiceDetailsScreen();
        break;
      case createOrder:
        page = const CreateOrderScreen();
        break;
      case orders:
        page = const OrdersScreen();
        break;
      case orderDetails:
        page = OrderDetailsScreen(orderId: settings.arguments?.toString() ?? '');
        break;
      case notifications:
        page = const NotificationsScreen();
        break;
      case profile:
        page = const ProfileScreen();
        break;
      case ads:
        page = const AdsScreen();
        break;
      case createAd:
        page = const CreateAdScreen();
        break;
      case adDetails:
        page = AdDetailsScreen(adId: settings.arguments?.toString() ?? '');
        break;
      case settings:
        page = const SettingsScreen();
        break;
      case support:
        page = const SupportScreen();
        break;
      case productionSetup:
        page = const ProductionSetupRequiredScreen();
        break;
      case adminLogin:
        page = const AdminLoginScreen();
        break;
      case adminShell:
        page = const AdminShell();
        break;
      default:
        page = const SplashScreen();
    }

    return PageRouteBuilder<dynamic>(
      settings: settings,
      pageBuilder: (_, animation, secondaryAnimation) => page,
      transitionsBuilder: (_, animation, secondaryAnimation, child) {
        final tween = Tween<Offset>(
          begin: const Offset(0.06, 0),
          end: Offset.zero,
        ).chain(CurveTween(curve: Curves.easeOutCubic));
        return FadeTransition(
          opacity: animation,
          child: SlideTransition(position: animation.drive(tween), child: child),
        );
      },
    );
  }
}
