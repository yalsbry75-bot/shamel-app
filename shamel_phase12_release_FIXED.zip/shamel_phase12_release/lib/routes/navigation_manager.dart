import 'package:flutter/material.dart';

class NavigationManager {
  const NavigationManager._();

  static Future<T?> push<T>(BuildContext context, String routeName, {Object? arguments}) {
    return Navigator.of(context).pushNamed<T>(routeName, arguments: arguments);
  }

  static Future<T?> replace<T>(BuildContext context, String routeName, {Object? arguments}) {
    return Navigator.of(context).pushReplacementNamed<T, Object?>(routeName, arguments: arguments);
  }

  static void back<T>(BuildContext context, [T? result]) {
    Navigator.of(context).pop<T>(result);
  }
}
