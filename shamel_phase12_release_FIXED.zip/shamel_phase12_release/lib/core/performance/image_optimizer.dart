import 'dart:typed_data';

import 'package:image/image.dart' as img;

import '../config/backend_config.dart';

class OptimizedImageResult {
  const OptimizedImageResult({required this.imageBytes, required this.thumbnailBytes});

  final Uint8List imageBytes;
  final Uint8List thumbnailBytes;
}

class ImageOptimizer {
  const ImageOptimizer._();

  static OptimizedImageResult optimize(Uint8List bytes) {
    final decoded = img.decodeImage(bytes);
    if (decoded == null) {
      return OptimizedImageResult(imageBytes: bytes, thumbnailBytes: bytes);
    }

    final main = decoded.width > BackendConfig.imageResizeMaxWidth
        ? img.copyResize(decoded, width: BackendConfig.imageResizeMaxWidth)
        : decoded;
    final thumbnail = decoded.width > BackendConfig.thumbnailWidth
        ? img.copyResize(decoded, width: BackendConfig.thumbnailWidth)
        : decoded;

    return OptimizedImageResult(
      imageBytes: Uint8List.fromList(img.encodeJpg(main, quality: BackendConfig.imageQuality)),
      thumbnailBytes: Uint8List.fromList(img.encodeJpg(thumbnail, quality: BackendConfig.thumbnailQuality)),
    );
  }
}
