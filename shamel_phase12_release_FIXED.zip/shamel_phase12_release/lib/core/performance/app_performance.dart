import 'package:firebase_performance/firebase_performance.dart';
import 'package:flutter/foundation.dart';

class AppPerformance {
  const AppPerformance._();

  static bool _ready = false;

  static Future<void> initialize() async {
    try {
      await FirebasePerformance.instance.setPerformanceCollectionEnabled(!kDebugMode);
      _ready = true;
    } catch (_) {
      _ready = false;
    }
  }

  static Future<T> trace<T>(
    String name,
    Future<T> Function() action, {
    Map<String, String> attributes = const <String, String>{},
  }) async {
    if (!_ready) return action();
    final traceName = _normalizeTraceName(name);
    final trace = FirebasePerformance.instance.newTrace(traceName);
    try {
      for (final entry in attributes.entries) {
        trace.putAttribute(_normalizeAttribute(entry.key), _trim(entry.value));
      }
      await trace.start();
      final result = await action();
      trace.incrementMetric('success', 1);
      return result;
    } catch (_) {
      trace.incrementMetric('failure', 1);
      rethrow;
    } finally {
      try {
        await trace.stop();
      } catch (_) {}
    }
  }

  static String _normalizeTraceName(String value) {
    final cleaned = value.trim().replaceAll(RegExp(r'[^A-Za-z0-9_]+'), '_');
    if (cleaned.isEmpty) return 'shamel_trace';
    return cleaned.length > 90 ? cleaned.substring(0, 90) : cleaned;
  }

  static String _normalizeAttribute(String value) {
    final cleaned = value.trim().replaceAll(RegExp(r'[^A-Za-z0-9_]+'), '_');
    if (cleaned.isEmpty) return 'attr';
    return cleaned.length > 32 ? cleaned.substring(0, 32) : cleaned;
  }

  static String _trim(String value) => value.length > 100 ? value.substring(0, 100) : value;
}
