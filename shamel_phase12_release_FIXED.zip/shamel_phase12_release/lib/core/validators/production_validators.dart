import '../errors/app_exception.dart';
import '../security/input_sanitizer.dart';

class ProductionValidators {
  const ProductionValidators._();

  static String requiredText(String value, {required String fieldName, int minLength = 1, int maxLength = 500}) {
    final cleaned = InputSanitizer.text(value, maxLength: maxLength);
    if (cleaned.length < minLength) {
      throw AppException('$fieldName غير مكتمل.', code: 'INVALID_INPUT');
    }
    return cleaned;
  }

  static String yemeniPhone(String value) {
    final cleaned = InputSanitizer.phone(value);
    final local = cleaned.startsWith('+967') ? cleaned.substring(4) : cleaned;
    if (!RegExp(r'^[0-9]{7,9}$').hasMatch(local)) {
      throw const AppException('رقم الهاتف غير صحيح.', code: 'INVALID_PHONE');
    }
    return cleaned.startsWith('+967') ? cleaned : '+967$local';
  }

  static double nonNegativePrice(double value) {
    if (value < 0) throw const AppException('السعر لا يمكن أن يكون سالبًا.', code: 'INVALID_PRICE');
    return value;
  }
}
