import 'app_log_level.dart';

class AppErrorLogModel {
  const AppErrorLogModel({
    required this.logId,
    required this.level,
    required this.message,
    required this.source,
    required this.createdAt,
    this.code,
    this.userId,
    this.stackTrace,
    this.context = const <String, String>{},
  });

  final String logId;
  final AppLogLevel level;
  final String message;
  final String source;
  final DateTime createdAt;
  final String? code;
  final String? userId;
  final String? stackTrace;
  final Map<String, String> context;

  Map<String, dynamic> toJson() {
    return <String, dynamic>{
      'logId': logId,
      'level': level.label,
      'message': message,
      'source': source,
      'createdAt': createdAt.toIso8601String(),
      'code': code,
      'userId': userId,
      'stackTrace': stackTrace,
      'context': context,
    };
  }
}
