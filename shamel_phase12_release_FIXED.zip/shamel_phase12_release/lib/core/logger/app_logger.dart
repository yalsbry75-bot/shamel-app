import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';

import '../database/firestore_collections.dart';
import 'app_error_log_model.dart';
import 'app_log_level.dart';

class AppLogger {
  AppLogger._({FirebaseFirestore? firestore}) : _firestore = firestore;

  static final AppLogger instance = AppLogger._();

  final FirebaseFirestore? _firestore;

  Future<void> info(String message, {String source = 'app', Map<String, String> context = const <String, String>{}}) {
    return log(level: AppLogLevel.info, message: message, source: source, context: context);
  }

  Future<void> warning(String message, {String source = 'app', String? code, Map<String, String> context = const <String, String>{}}) {
    return log(level: AppLogLevel.warning, message: message, source: source, code: code, context: context);
  }

  Future<void> error(
    Object error,
    StackTrace stackTrace, {
    String source = 'app',
    String? code,
    String? userId,
    bool fatal = false,
    Map<String, String> context = const <String, String>{},
  }) {
    return log(
      level: fatal ? AppLogLevel.fatal : AppLogLevel.error,
      message: error.toString(),
      source: source,
      code: code,
      userId: userId,
      stackTrace: stackTrace.toString(),
      context: context,
    );
  }

  Future<void> log({
    required AppLogLevel level,
    required String message,
    required String source,
    String? code,
    String? userId,
    String? stackTrace,
    Map<String, String> context = const <String, String>{},
  }) async {
    final now = DateTime.now();
    final item = AppErrorLogModel(
      logId: 'log_${now.microsecondsSinceEpoch}',
      level: level,
      message: _safe(message),
      source: _safe(source),
      createdAt: now,
      code: code,
      userId: userId,
      stackTrace: stackTrace,
      context: context.map((key, value) => MapEntry(_safe(key), _safe(value))),
    );

    if (kDebugMode) {
      debugPrint('[${level.label}] ${item.source}: ${item.message}');
    }

    try {
      final firestore = _firestore ?? FirebaseFirestore.instance;
      await firestore
          .collection(FirestoreCollections.appErrorLogs)
          .doc(item.logId)
          .set(item.toJson())
          .timeout(const Duration(seconds: 8));
    } catch (_) {
      // Logging must never break a user flow.
    }
  }

  String _safe(String value) {
    final trimmed = value.trim();
    if (trimmed.length <= 900) return trimmed;
    return '${trimmed.substring(0, 900)}...';
  }
}
