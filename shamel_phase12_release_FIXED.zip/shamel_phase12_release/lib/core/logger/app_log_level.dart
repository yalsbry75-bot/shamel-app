enum AppLogLevel {
  debug,
  info,
  warning,
  error,
  fatal;

  String get label {
    switch (this) {
      case AppLogLevel.debug:
        return 'debug';
      case AppLogLevel.info:
        return 'info';
      case AppLogLevel.warning:
        return 'warning';
      case AppLogLevel.error:
        return 'error';
      case AppLogLevel.fatal:
        return 'fatal';
    }
  }
}
