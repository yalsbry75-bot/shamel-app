import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';

import '../storage/cloud_storage_service.dart';
import '../theme/app_text_styles.dart';
import 'shamel_text_field.dart';

final cloudStorageServiceProvider = Provider<CloudStorageService>((ref) => CloudStorageService());

class CloudImagePickerField extends ConsumerStatefulWidget {
  const CloudImagePickerField({
    super.key,
    required this.controller,
    required this.hintText,
    required this.storagePathPrefix,
    this.maxLines = 1,
  });

  final TextEditingController controller;
  final String hintText;
  final String storagePathPrefix;
  final int maxLines;

  @override
  ConsumerState<CloudImagePickerField> createState() => _CloudImagePickerFieldState();
}

class _CloudImagePickerFieldState extends ConsumerState<CloudImagePickerField> {
  bool _uploading = false;
  String? _error;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ShamelTextField(
          controller: widget.controller,
          hintText: widget.hintText,
          prefixIcon: Icons.cloud_upload_outlined,
          maxLines: widget.maxLines,
          suffixIcon: TextButton(
            onPressed: _uploading ? null : _pickAndUpload,
            child: _uploading
                ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                : const Text('رفع'),
          ),
        ),
        if (_error != null) ...[
          const SizedBox(height: 6),
          Text(_error!, style: AppTextStyles.caption.copyWith(color: Colors.redAccent)),
        ],
      ],
    );
  }

  Future<void> _pickAndUpload() async {
    setState(() {
      _uploading = true;
      _error = null;
    });
    try {
      final picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 90);
      if (picked == null) {
        setState(() => _uploading = false);
        return;
      }
      final bytes = await picked.readAsBytes();
      final contentType = _contentType(picked.name);
      final safeName = picked.name.replaceAll(RegExp(r'[^A-Za-z0-9_.-]'), '_');
      final result = await ref.read(cloudStorageServiceProvider).uploadImageBytes(
            bytes: bytes,
            path: '${widget.storagePathPrefix}/${DateTime.now().microsecondsSinceEpoch}_$safeName',
            contentType: contentType,
          );
      final current = widget.controller.text.trim();
      widget.controller.text = widget.maxLines > 1 && current.isNotEmpty ? '$current\n${result.downloadUrl}' : result.downloadUrl;
    } catch (_) {
      _error = 'تعذر رفع الصورة. تحقق من الاتصال ونوع الملف.';
    } finally {
      if (mounted) setState(() => _uploading = false);
    }
  }

  String _contentType(String name) {
    final lower = name.toLowerCase();
    if (lower.endsWith('.png')) return 'image/png';
    if (lower.endsWith('.webp')) return 'image/webp';
    return 'image/jpeg';
  }
}
