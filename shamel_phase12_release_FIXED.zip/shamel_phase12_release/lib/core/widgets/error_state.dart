import 'package:flutter/material.dart';

import '../theme/app_colors.dart';
import '../theme/app_text_styles.dart';
import 'glass_container.dart';
import 'shamel_button.dart';

class ErrorState extends StatelessWidget {
  const ErrorState({
    super.key,
    required this.message,
    this.onRetry,
  });

  final String message;
  final VoidCallback? onRetry;

  @override
  Widget build(BuildContext context) {
    return GlassContainer(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.error_outline_rounded, size: 42, color: AppColors.error),
          const SizedBox(height: 12),
          Text('حدث خطأ', style: AppTextStyles.section),
          const SizedBox(height: 8),
          Text(message, style: AppTextStyles.caption, textAlign: TextAlign.center),
          if (onRetry != null) ...[
            const SizedBox(height: 18),
            ShamelButton.secondary(label: 'إعادة المحاولة', onPressed: onRetry),
          ],
        ],
      ),
    );
  }
}
