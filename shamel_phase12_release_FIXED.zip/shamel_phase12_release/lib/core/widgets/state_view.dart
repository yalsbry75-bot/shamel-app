import 'package:flutter/material.dart';

import '../utils/ui_state.dart';
import 'empty_state.dart';
import 'error_state.dart';
import 'loading_skeleton.dart';

class StateView<T> extends StatelessWidget {
  const StateView({
    super.key,
    required this.state,
    required this.builder,
    required this.emptyTitle,
    required this.emptyMessage,
  });

  final UiState<T> state;
  final Widget Function(T? data) builder;
  final String emptyTitle;
  final String emptyMessage;

  @override
  Widget build(BuildContext context) {
    switch (state.status) {
      case ViewState.loading:
        return const Column(
          children: [
            LoadingSkeleton(),
            SizedBox(height: 12),
            LoadingSkeleton(height: 120),
          ],
        );
      case ViewState.error:
        return ErrorState(message: state.message ?? 'تعذر تحميل المحتوى.');
      case ViewState.empty:
        return EmptyState(title: emptyTitle, message: emptyMessage);
      case ViewState.initial:
      case ViewState.success:
        return builder(state.data);
    }
  }
}
