import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

import '../../firebase_options.dart';
import '../config/production_config.dart';
import '../monitoring/app_monitoring.dart';
import '../notifications/push_notification_service.dart';

class FirebaseBackendInitializer {
  const FirebaseBackendInitializer._();

  static Future<bool> initialize() async {
    if (!ProductionConfig.isFirebaseConfigured) {
      return false;
    }

    try {
      await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
      await AppMonitoring.initialize();
      if (!kIsWeb) {
        await PushNotificationService().initialize();
      }
      return true;
    } catch (error, stackTrace) {
      await AppMonitoring.recordError(error, stackTrace, fatal: true, source: 'FirebaseBackendInitializer');
      return false;
    }
  }
}
