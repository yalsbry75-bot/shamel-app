import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_messaging/firebase_messaging.dart';

import '../database/firestore_collections.dart';

@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // The main isolate initializes Firebase. Keep this handler side-effect free in Phase 9.
}

class PushNotificationService {
  PushNotificationService({FirebaseMessaging? messaging, FirebaseFirestore? firestore})
      : _messaging = messaging ?? FirebaseMessaging.instance,
        _firestore = firestore ?? FirebaseFirestore.instance;

  final FirebaseMessaging _messaging;
  final FirebaseFirestore _firestore;

  Future<void> initialize() async {
    await _messaging.requestPermission(alert: true, badge: true, sound: true);
    FirebaseMessaging.onBackgroundMessage(firebaseMessagingBackgroundHandler);
  }

  Future<String?> registerDeviceToken(String userId) async {
    if (userId.trim().isEmpty) return null;
    final token = await _messaging.getToken();
    if (token == null || token.isEmpty) return null;
    await _firestore.collection(FirestoreCollections.userDevices).doc(token).set({
      'token': token,
      'userId': userId,
      'platform': 'flutter',
      'updatedAtServer': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
    return token;
  }
}
