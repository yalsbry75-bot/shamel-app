enum ViewState { initial, loading, success, empty, error }

class UiState<T> {
  const UiState({
    this.status = ViewState.initial,
    this.data,
    this.message,
  });

  final ViewState status;
  final T? data;
  final String? message;

  bool get isLoading => status == ViewState.loading;
  bool get hasError => status == ViewState.error;
  bool get isEmpty => status == ViewState.empty;
  bool get isSuccess => status == ViewState.success;

  UiState<T> copyWith({
    ViewState? status,
    T? data,
    String? message,
  }) {
    return UiState<T>(
      status: status ?? this.status,
      data: data ?? this.data,
      message: message ?? this.message,
    );
  }
}
