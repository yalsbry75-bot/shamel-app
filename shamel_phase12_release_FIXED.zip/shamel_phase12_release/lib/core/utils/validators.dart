import '../constants/app_constants.dart';

class Validators {
  const Validators._();

  static final RegExp _digitsOnly = RegExp(r'^\d+$');

  static String? phone(String? value) {
    final text = value?.trim() ?? '';
    if (text.isEmpty) return 'أدخل رقم الهاتف';
    if (!_digitsOnly.hasMatch(text)) return 'رقم الهاتف يجب أن يحتوي على أرقام فقط';
    if (text.length < 8) return 'رقم الهاتف غير مكتمل';
    if (text.length > 9) return 'رقم الهاتف أطول من المطلوب';
    return null;
  }

  static String? otp(String? value) {
    final text = value?.trim() ?? '';
    if (text.isEmpty) return 'أدخل رمز التحقق';
    if (!_digitsOnly.hasMatch(text)) return 'رمز التحقق يجب أن يحتوي على أرقام فقط';
    if (text.length != AppConstants.otpLength) {
      return 'أدخل رمز التحقق المكون من ${AppConstants.otpLength} أرقام';
    }
    return null;
  }

  static String? requiredText(String? value, String label) {
    final text = value?.trim() ?? '';
    if (text.isEmpty) return 'أدخل $label';
    if (text.length < 2) return '$label قصير جدًا';
    return null;
  }
}
