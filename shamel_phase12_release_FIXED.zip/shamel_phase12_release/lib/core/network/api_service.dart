import '../errors/app_exception.dart';
import 'api_response.dart';

abstract class ApiService {
  Future<ApiResponse<T>> get<T>(String path);
  Future<ApiResponse<T>> post<T>(String path, Map<String, dynamic> body);
}

class DisabledApiService implements ApiService {
  const DisabledApiService();

  @override
  Future<ApiResponse<T>> get<T>(String path) async {
    await Future<void>.delayed(const Duration(milliseconds: 250));
    throw const AppException('طبقة REST API الاحتياطية غير مفعلة؛ التطبيق يستخدم Firebase في Phase 10.');
  }

  @override
  Future<ApiResponse<T>> post<T>(String path, Map<String, dynamic> body) async {
    await Future<void>.delayed(const Duration(milliseconds: 250));
    throw const AppException('طبقة REST API الاحتياطية غير مفعلة؛ التطبيق يستخدم Firebase في Phase 10.');
  }
}
