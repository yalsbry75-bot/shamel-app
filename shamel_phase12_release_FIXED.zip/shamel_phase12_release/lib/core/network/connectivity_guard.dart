import 'package:connectivity_plus/connectivity_plus.dart';

import '../errors/app_exception.dart';

class ConnectivityGuard {
  ConnectivityGuard({Connectivity? connectivity}) : _connectivity = connectivity ?? Connectivity();

  final Connectivity _connectivity;

  Future<void> ensureOnline() async {
    final result = await _connectivity.checkConnectivity();
    if (result.contains(ConnectivityResult.none)) {
      throw const AppException('لا يوجد اتصال بالإنترنت. تحقق من الشبكة وحاول مرة أخرى.', code: 'NO_INTERNET');
    }
  }

  Stream<bool> get onlineChanges {
    return _connectivity.onConnectivityChanged.map((items) => !items.contains(ConnectivityResult.none)).distinct();
  }
}
