import '../errors/app_exception.dart';
import 'api_response.dart';

class ResponseHandler {
  const ResponseHandler._();

  static T unwrap<T>(ApiResponse<T> response) {
    if (response.isSuccess) return response.data;
    throw AppException(
      response.message ?? 'حدث خطأ غير متوقع.',
      code: response.statusCode.toString(),
    );
  }
}
