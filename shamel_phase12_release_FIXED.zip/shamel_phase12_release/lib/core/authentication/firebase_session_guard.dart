import 'package:firebase_auth/firebase_auth.dart';

import '../errors/app_exception.dart';

class FirebaseSessionGuard {
  const FirebaseSessionGuard({FirebaseAuth? auth}) : _auth = auth ?? FirebaseAuth.instance;

  final FirebaseAuth _auth;

  String requireUserId() {
    final userId = _auth.currentUser?.uid;
    if (userId == null || userId.isEmpty) {
      throw const AppException('الجلسة منتهية. أعد تسجيل الدخول.', code: 'SESSION_EXPIRED');
    }
    return userId;
  }

  bool get isSignedIn => _auth.currentUser != null;
}
