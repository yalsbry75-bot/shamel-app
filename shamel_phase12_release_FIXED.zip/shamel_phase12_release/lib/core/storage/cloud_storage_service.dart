import 'dart:typed_data';

import 'package:firebase_storage/firebase_storage.dart';

import '../config/backend_config.dart';
import '../errors/app_exception.dart';
import '../logger/app_logger.dart';
import '../network/connectivity_guard.dart';
import '../performance/app_performance.dart';
import '../performance/image_optimizer.dart';
import '../security/file_security_validator.dart';
import '../security/rate_limiter_service.dart';

class CloudStorageUploadResult {
  const CloudStorageUploadResult({
    required this.fullPath,
    required this.downloadUrl,
    this.thumbnailPath,
    this.thumbnailUrl,
  });

  final String fullPath;
  final String downloadUrl;
  final String? thumbnailPath;
  final String? thumbnailUrl;
}

class CloudStorageService {
  CloudStorageService({FirebaseStorage? storage, ConnectivityGuard? connectivity, RateLimiterService? rateLimiter})
      : _storage = storage ?? FirebaseStorage.instance,
        _connectivity = connectivity ?? ConnectivityGuard(),
        _rateLimiter = rateLimiter ?? const RateLimiterService();

  final FirebaseStorage _storage;
  final ConnectivityGuard _connectivity;
  final RateLimiterService _rateLimiter;

  Future<CloudStorageUploadResult> uploadImageBytes({
    required Uint8List bytes,
    required String path,
    required String contentType,
    String? ownerId,
  }) async {
    FileSecurityValidator.validateImage(bytes: bytes, contentType: contentType);
    await _rateLimiter.check(
      key: 'upload_${ownerId ?? 'anonymous'}',
      rule: RateLimiterService.uploadRule,
      message: 'تم رفع صور كثيرة خلال وقت قصير. حاول لاحقًا.',
    );
    await _connectivity.ensureOnline();

    final optimized = ImageOptimizer.optimize(bytes);
    if (optimized.imageBytes.lengthInBytes > BackendConfig.maxImageBytes) {
      throw const AppException('حجم الصورة كبير جدًا بعد الضغط.', code: 'IMAGE_TOO_LARGE');
    }

    try {
      return await AppPerformance.trace('storage_upload_image', () async {
        final metadata = SettableMetadata(
          contentType: 'image/jpeg',
          customMetadata: <String, String>{'source': 'shamel_app', 'originalContentType': contentType},
        );
        final ref = _storage.ref(path);
        await ref.putData(optimized.imageBytes, metadata).timeout(const Duration(seconds: BackendConfig.requestTimeoutSeconds));
        final url = await ref.getDownloadURL();

        final thumbnailRef = _storage.ref(_thumbnailPath(path));
        await thumbnailRef.putData(optimized.thumbnailBytes, metadata).timeout(const Duration(seconds: BackendConfig.requestTimeoutSeconds));
        final thumbnailUrl = await thumbnailRef.getDownloadURL();

        return CloudStorageUploadResult(
          fullPath: ref.fullPath,
          downloadUrl: url,
          thumbnailPath: thumbnailRef.fullPath,
          thumbnailUrl: thumbnailUrl,
        );
      }, attributes: {'storage': 'firebase', 'type': 'image'});
    } on FirebaseException catch (error, stack) {
      await AppLogger.instance.error(error, stack, source: 'storage.uploadImageBytes', code: error.code);
      throw AppException(_message(error), code: error.code);
    }
  }

  Future<void> deleteByPath(String fullPath) async {
    if (fullPath.trim().isEmpty) return;
    try {
      await _connectivity.ensureOnline();
      await _storage.ref(fullPath).delete();
    } on FirebaseException catch (error, stack) {
      if (error.code == 'object-not-found') return;
      await AppLogger.instance.error(error, stack, source: 'storage.deleteByPath', code: error.code);
      throw AppException(_message(error), code: error.code);
    }
  }

  String _thumbnailPath(String path) {
    final segments = path.split('/');
    final file = segments.isEmpty ? path : segments.removeLast();
    final thumbnailFile = 'thumb_$file';
    return [...segments, 'thumbnails', thumbnailFile].join('/');
  }

  String _message(FirebaseException error) {
    switch (error.code) {
      case 'unauthorized':
        return 'ليست لديك صلاحية رفع أو حذف هذا الملف.';
      case 'canceled':
        return 'تم إلغاء رفع الملف.';
      default:
        return 'تعذر رفع الملف. تحقق من الاتصال وحاول مرة أخرى.';
    }
  }
}
