class PaginationConfig {
  const PaginationConfig._();

  static const int smallPage = 20;
  static const int defaultPage = 40;
  static const int adminPage = 80;
  static const int maxPage = 100;

  static int safeLimit(int requested, {int fallback = defaultPage}) {
    if (requested <= 0) return fallback;
    if (requested > maxPage) return maxPage;
    return requested;
  }
}
