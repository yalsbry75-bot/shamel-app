import 'dart:async';

class CacheEntry<T> {
  const CacheEntry({required this.value, required this.createdAt, required this.ttl});

  final T value;
  final DateTime createdAt;
  final Duration ttl;

  bool get isExpired => DateTime.now().difference(createdAt) > ttl;
}

class MemoryCache {
  MemoryCache._();

  static final MemoryCache instance = MemoryCache._();

  final Map<String, CacheEntry<Object?>> _store = <String, CacheEntry<Object?>>{};
  Timer? _cleanupTimer;

  T? get<T>(String key) {
    final entry = _store[key];
    if (entry == null) return null;
    if (entry.isExpired) {
      _store.remove(key);
      return null;
    }
    final value = entry.value;
    return value is T ? value : null;
  }

  void set<T>(String key, T value, {Duration ttl = const Duration(minutes: 5)}) {
    _store[key] = CacheEntry<Object?>(value: value, createdAt: DateTime.now(), ttl: ttl);
    _scheduleCleanup();
  }

  void invalidate(String key) => _store.remove(key);

  void invalidateWhere(bool Function(String key) test) {
    _store.removeWhere((key, value) => test(key));
  }

  void clear() => _store.clear();

  int get activeEntries {
    _removeExpired();
    return _store.length;
  }

  void _scheduleCleanup() {
    _cleanupTimer ??= Timer.periodic(const Duration(minutes: 3), (_) => _removeExpired());
  }

  void _removeExpired() {
    _store.removeWhere((key, value) => value.isExpired);
    if (_store.isEmpty) {
      _cleanupTimer?.cancel();
      _cleanupTimer = null;
    }
  }
}
