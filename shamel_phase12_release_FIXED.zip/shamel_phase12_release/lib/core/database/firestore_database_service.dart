import 'package:cloud_firestore/cloud_firestore.dart';

import '../cache/memory_cache.dart';
import '../cache/pagination_config.dart';
import '../config/backend_config.dart';
import '../errors/app_exception.dart';
import '../logger/app_logger.dart';
import '../network/connectivity_guard.dart';
import '../performance/app_performance.dart';
import 'firestore_json.dart';

class FirestoreDatabaseService {
  FirestoreDatabaseService({FirebaseFirestore? firestore, ConnectivityGuard? connectivity})
      : _firestore = firestore ?? FirebaseFirestore.instance,
        _connectivity = connectivity ?? ConnectivityGuard();

  final FirebaseFirestore _firestore;
  final ConnectivityGuard _connectivity;
  final MemoryCache _cache = MemoryCache.instance;

  CollectionReference<Map<String, dynamic>> collection(String name) => _firestore.collection(name);

  Future<void> setDocument({required String collection, required String id, required Map<String, dynamic> data, bool merge = true}) async {
    try {
      await _connectivity.ensureOnline();
      await AppPerformance.trace('firestore_set_$collection', () async {
        await _firestore.collection(collection).doc(id).set(
              FirestoreJson.withServerAudit(data, isCreate: true),
              SetOptions(merge: merge),
            );
      }, attributes: {'collection': collection, 'operation': 'set'});
      _cache.invalidateWhere((key) => key.startsWith('firestore:$collection:'));
    } on FirebaseException catch (error, stack) {
      await AppLogger.instance.error(error, stack, source: 'firestore.setDocument', code: error.code, context: {'collection': collection});
      throw AppException(_message(error), code: error.code);
    }
  }

  Future<Map<String, dynamic>?> getDocument({required String collection, required String id, bool useCache = true}) async {
    final cacheKey = 'firestore:$collection:doc:$id';
    if (useCache) {
      final cached = _cache.get<Map<String, dynamic>?>(cacheKey);
      if (cached != null) return cached;
    }
    try {
      await _connectivity.ensureOnline();
      final result = await AppPerformance.trace('firestore_get_$collection', () async {
        final doc = await _firestore.collection(collection).doc(id).get().timeout(const Duration(seconds: BackendConfig.requestTimeoutSeconds));
        if (!doc.exists || doc.data() == null) return null;
        return FirestoreJson.normalize({...doc.data()!, 'id': doc.id});
      }, attributes: {'collection': collection, 'operation': 'get'});
      if (useCache && result != null) _cache.set(cacheKey, result, ttl: const Duration(minutes: BackendConfig.cacheTtlMinutes));
      return result;
    } on FirebaseException catch (error, stack) {
      await AppLogger.instance.error(error, stack, source: 'firestore.getDocument', code: error.code, context: {'collection': collection});
      throw AppException(_message(error), code: error.code);
    }
  }

  Future<void> deleteDocument({required String collection, required String id}) async {
    try {
      await _connectivity.ensureOnline();
      await AppPerformance.trace('firestore_delete_$collection', () async {
        await _firestore.collection(collection).doc(id).delete();
      }, attributes: {'collection': collection, 'operation': 'delete'});
      _cache.invalidateWhere((key) => key.startsWith('firestore:$collection:'));
    } on FirebaseException catch (error, stack) {
      await AppLogger.instance.error(error, stack, source: 'firestore.deleteDocument', code: error.code, context: {'collection': collection});
      throw AppException(_message(error), code: error.code);
    }
  }

  Future<List<Map<String, dynamic>>> getCollection({
    required String collection,
    String orderBy = 'createdAt',
    bool descending = true,
    int limit = 50,
    bool useCache = true,
  }) async {
    final safeLimit = PaginationConfig.safeLimit(limit);
    final cacheKey = 'firestore:$collection:list:$orderBy:$descending:$safeLimit';
    if (useCache) {
      final cached = _cache.get<List<Map<String, dynamic>>>(cacheKey);
      if (cached != null) return cached;
    }
    try {
      await _connectivity.ensureOnline();
      final result = await AppPerformance.trace('firestore_list_$collection', () async {
        final query = await _firestore.collection(collection).orderBy(orderBy, descending: descending).limit(safeLimit).get();
        return query.docs.map((doc) => FirestoreJson.normalize({...doc.data(), 'id': doc.id})).toList(growable: false);
      }, attributes: {'collection': collection, 'operation': 'list'});
      if (useCache) _cache.set(cacheKey, result, ttl: const Duration(minutes: BackendConfig.cacheTtlMinutes));
      return result;
    } on FirebaseException catch (error, stack) {
      await AppLogger.instance.error(error, stack, source: 'firestore.getCollection', code: error.code, context: {'collection': collection});
      throw AppException(_message(error), code: error.code);
    }
  }

  Future<List<Map<String, dynamic>>> whereEqual({
    required String collection,
    required String field,
    required Object? isEqualTo,
    String? orderBy,
    bool descending = true,
    int limit = 50,
    bool useCache = true,
  }) async {
    final safeLimit = PaginationConfig.safeLimit(limit);
    final cacheKey = 'firestore:$collection:where:$field:$isEqualTo:$orderBy:$descending:$safeLimit';
    if (useCache) {
      final cached = _cache.get<List<Map<String, dynamic>>>(cacheKey);
      if (cached != null) return cached;
    }
    try {
      await _connectivity.ensureOnline();
      final result = await AppPerformance.trace('firestore_where_$collection', () async {
        Query<Map<String, dynamic>> query = _firestore.collection(collection).where(field, isEqualTo: isEqualTo).limit(safeLimit);
        if (orderBy != null) query = query.orderBy(orderBy, descending: descending);
        final snapshot = await query.get();
        return snapshot.docs.map((doc) => FirestoreJson.normalize({...doc.data(), 'id': doc.id})).toList(growable: false);
      }, attributes: {'collection': collection, 'operation': 'where'});
      if (useCache) _cache.set(cacheKey, result, ttl: const Duration(minutes: BackendConfig.cacheTtlMinutes));
      return result;
    } on FirebaseException catch (error, stack) {
      await AppLogger.instance.error(error, stack, source: 'firestore.whereEqual', code: error.code, context: {'collection': collection, 'field': field});
      throw AppException(_message(error), code: error.code);
    }
  }

  String _message(FirebaseException error) {
    switch (error.code) {
      case 'permission-denied':
        return 'ليست لديك صلاحية كافية لتنفيذ العملية.';
      case 'unavailable':
        return 'الخدمة غير متاحة مؤقتًا. تحقق من الاتصال وحاول مرة أخرى.';
      case 'deadline-exceeded':
        return 'انتهت مهلة الاتصال. حاول مرة أخرى.';
      default:
        return 'تعذر الاتصال بقاعدة البيانات. حاول مرة أخرى.';
    }
  }
}
