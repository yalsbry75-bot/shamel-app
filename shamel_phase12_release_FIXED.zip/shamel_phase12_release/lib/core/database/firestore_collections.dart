class FirestoreCollections {
  const FirestoreCollections._();

  static const users = 'users';
  static const providers = 'providers';
  static const services = 'services';
  static const providerGallery = 'providerGallery';
  static const serviceAreas = 'serviceAreas';
  static const orders = 'orders';
  static const ads = 'ads';
  static const ratings = 'ratings';
  static const subscriptions = 'subscriptions';
  static const notifications = 'notifications';
  static const favorites = 'favorites';
  static const reports = 'reports';
  static const admins = 'admins';
  static const adminLogs = 'adminLogs';
  static const appErrorLogs = 'appErrorLogs';
  static const governorates = 'governorates';
  static const categories = 'categories';
  static const userDevices = 'userDevices';
  static const recentSearches = 'recentSearches';
}
