import 'package:cloud_firestore/cloud_firestore.dart';

class FirestoreJson {
  const FirestoreJson._();

  static Map<String, dynamic> normalize(Map<String, dynamic> raw) {
    return raw.map((key, value) => MapEntry(key, _normalizeValue(value)));
  }

  static dynamic _normalizeValue(dynamic value) {
    if (value is Timestamp) return value.toDate().toIso8601String();
    if (value is DateTime) return value.toIso8601String();
    if (value is Map) {
      return value.map((key, nested) => MapEntry(key.toString(), _normalizeValue(nested)));
    }
    if (value is List) return value.map(_normalizeValue).toList(growable: false);
    return value;
  }

  static Map<String, dynamic> withServerAudit(Map<String, dynamic> data, {bool isCreate = false}) {
    return {
      ...data,
      'updatedAtServer': FieldValue.serverTimestamp(),
      if (isCreate) 'createdAtServer': FieldValue.serverTimestamp(),
    };
  }
}
