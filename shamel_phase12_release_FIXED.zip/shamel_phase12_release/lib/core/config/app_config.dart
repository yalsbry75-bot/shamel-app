class AppConfig {
  const AppConfig._();

  static const String appName = 'شامل';
  static const String appTagline = 'كل خدماتك في مكان واحد';
  static const String currentPhase = 'Production Release';
  static const bool backendEnabled = true;
  static const bool firebaseEnabled = true;
  static const Duration defaultAnimationDuration = Duration(milliseconds: 420);
  static const Duration networkTimeout = Duration(seconds: 30);
}
