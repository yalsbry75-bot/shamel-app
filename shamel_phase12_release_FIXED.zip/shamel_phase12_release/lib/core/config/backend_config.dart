class BackendConfig {
  const BackendConfig._();

  static const backendProvider = 'firebase';
  static const appPackageName = 'com.shamel.app';

  /// Reject very large originals before CPU-heavy processing.
  static const maxOriginalImageBytes = 8 * 1024 * 1024;

  /// Final uploaded image size limit after compression.
  static const maxImageBytes = 2 * 1024 * 1024;
  static const imageResizeMaxWidth = 1440;
  static const thumbnailWidth = 360;
  static const imageQuality = 82;
  static const thumbnailQuality = 72;
  static const requestTimeoutSeconds = 20;
  static const cacheTtlMinutes = 5;

  static const supportedImageMimeTypes = <String>{
    'image/jpeg',
    'image/png',
    'image/webp',
  };
}
