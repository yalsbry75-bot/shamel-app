import '../../firebase_options.dart';

class ProductionConfig {
  const ProductionConfig._();

  static const appName = 'شامل';
  static const appTagline = 'كل خدماتك في مكان واحد';
  static const packageName = 'com.shamel.app';
  static const versionName = '1.0.1';
  static const buildNumber = 13;
  static const supportEmail = 'support@shamel.app';
  static const privacyPolicyPath = 'docs/release/PRIVACY_POLICY.md';
  static const termsPath = 'docs/release/TERMS_AND_CONDITIONS.md';

  static bool get isFirebaseConfigured {
    try {
      final options = DefaultFirebaseOptions.currentPlatform;
      return !_isMissing(options.apiKey) &&
          !_isMissing(options.appId) &&
          !_isMissing(options.messagingSenderId) &&
          !_isMissing(options.projectId) &&
          !_isMissing(options.storageBucket);
    } catch (_) {
      return false;
    }
  }

  static List<String> get missingProductionItems {
    final missing = <String>[];
    if (!isFirebaseConfigured) {
      missing.add('توليد lib/firebase_options.dart الحقيقي عبر FlutterFire CLI أو تمرير قيم Firebase عبر dart-define.');
      missing.add('إضافة google-services.json لمنصة Android بعد ربط تطبيق com.shamel.app.');
      missing.add('إضافة GoogleService-Info.plist لمنصة iOS عند إنشاء مجلد iOS الرسمي.');
    }
    return missing;
  }

  static bool _isMissing(String value) {
    return value.trim().isEmpty;
  }
}
