class InputSanitizer {
  const InputSanitizer._();

  static String text(String value, {int maxLength = 500}) {
    final normalized = value
        .replaceAll(RegExp(r'[\u0000-\u001F\u007F]'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
    if (normalized.length <= maxLength) return normalized;
    return normalized.substring(0, maxLength).trim();
  }

  static String phone(String value) {
    final cleaned = value.replaceAll(RegExp(r'[^0-9+]'), '');
    if (cleaned.startsWith('+')) return '+${cleaned.substring(1).replaceAll(RegExp(r'[^0-9]'), '')}';
    return cleaned.replaceAll(RegExp(r'[^0-9]'), '');
  }

  static String id(String value) => value.replaceAll(RegExp(r'[^A-Za-z0-9_-]'), '');
}
