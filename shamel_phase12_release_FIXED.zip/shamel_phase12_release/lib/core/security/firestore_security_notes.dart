class FirestoreSecurityNotes {
  const FirestoreSecurityNotes._();

  static const summary = 'Rules are documented in firebase/firestore.rules and firebase/storage.rules. Deploy them with firebase deploy --only firestore:rules,storage.';
}
