import '../../features/auth/domain/account_type.dart';
import '../../features/auth/domain/user_model.dart';
import '../errors/app_exception.dart';

class AccessControlService {
  const AccessControlService._();

  static void requireActive(UserModel? user) {
    if (user == null) {
      throw const AppException('يجب تسجيل الدخول لتنفيذ هذه العملية.', code: 'AUTH_REQUIRED');
    }
    if (user.isBlocked) {
      throw const AppException('هذا الحساب موقوف مؤقتًا. تواصل مع الدعم.', code: 'ACCOUNT_BLOCKED');
    }
    if (!user.isVerified) {
      throw const AppException('يجب توثيق رقم الهاتف أولًا.', code: 'ACCOUNT_NOT_VERIFIED');
    }
  }

  static void requireProvider(UserModel? user) {
    requireActive(user);
    if (user!.userType != AccountType.provider) {
      throw const AppException('هذه العملية مخصصة لمقدمي الخدمات.', code: 'PROVIDER_REQUIRED');
    }
  }

  static void requireCustomer(UserModel? user) {
    requireActive(user);
    if (user!.userType != AccountType.customer) {
      throw const AppException('هذه العملية مخصصة للعملاء.', code: 'CUSTOMER_REQUIRED');
    }
  }
}
