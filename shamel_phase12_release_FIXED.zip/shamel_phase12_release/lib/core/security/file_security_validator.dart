import 'dart:typed_data';

import '../config/backend_config.dart';
import '../errors/app_exception.dart';

class FileSecurityValidator {
  const FileSecurityValidator._();

  static void validateImage({required Uint8List bytes, required String contentType}) {
    if (!BackendConfig.supportedImageMimeTypes.contains(contentType)) {
      throw const AppException('نوع الصورة غير مدعوم. استخدم JPG أو PNG أو WEBP.', code: 'UNSUPPORTED_FILE_TYPE');
    }
    if (bytes.isEmpty) {
      throw const AppException('ملف الصورة فارغ أو تالف.', code: 'EMPTY_FILE');
    }
    if (bytes.lengthInBytes > BackendConfig.maxOriginalImageBytes) {
      throw const AppException('حجم الصورة كبير جدًا. اختر صورة أصغر.', code: 'IMAGE_TOO_LARGE');
    }
  }
}
