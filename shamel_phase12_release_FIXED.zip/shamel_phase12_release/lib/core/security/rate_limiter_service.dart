import 'dart:convert';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../errors/app_exception.dart';

class RateLimitRule {
  const RateLimitRule({required this.maxAttempts, required this.window});

  final int maxAttempts;
  final Duration window;
}

class RateLimiterService {
  const RateLimiterService({FlutterSecureStorage? storage}) : _storage = storage ?? const FlutterSecureStorage();

  final FlutterSecureStorage _storage;

  static const RateLimitRule otpRule = RateLimitRule(maxAttempts: 5, window: Duration(minutes: 15));
  static const RateLimitRule orderRule = RateLimitRule(maxAttempts: 8, window: Duration(hours: 1));
  static const RateLimitRule adRule = RateLimitRule(maxAttempts: 5, window: Duration(hours: 6));
  static const RateLimitRule uploadRule = RateLimitRule(maxAttempts: 20, window: Duration(hours: 1));

  Future<void> check({required String key, required RateLimitRule rule, String? message}) async {
    final now = DateTime.now();
    final storageKey = 'rate_limit_$key';
    final raw = await _storage.read(key: storageKey);
    final attempts = <DateTime>[];
    if (raw != null && raw.isNotEmpty) {
      try {
        final decoded = jsonDecode(raw) as List<dynamic>;
        attempts.addAll(decoded.map((item) => DateTime.parse(item.toString())));
      } catch (_) {}
    }
    attempts.removeWhere((item) => now.difference(item) > rule.window);
    if (attempts.length >= rule.maxAttempts) {
      throw AppException(
        message ?? 'تم تنفيذ عمليات كثيرة خلال وقت قصير. حاول لاحقًا.',
        code: 'RATE_LIMITED',
      );
    }
    attempts.add(now);
    await _storage.write(key: storageKey, value: jsonEncode(attempts.map((item) => item.toIso8601String()).toList()));
  }
}
