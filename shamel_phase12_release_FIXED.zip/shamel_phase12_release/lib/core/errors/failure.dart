class Failure {
  const Failure({required this.message, this.code});

  final String message;
  final String? code;

  Failure copyWith({String? message, String? code}) {
    return Failure(
      message: message ?? this.message,
      code: code ?? this.code,
    );
  }

  Map<String, dynamic> toJson() => {'message': message, 'code': code};
}
