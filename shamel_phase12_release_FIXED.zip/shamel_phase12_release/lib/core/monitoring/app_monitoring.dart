import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';

import '../logger/app_logger.dart';
import '../performance/app_performance.dart';

class AppMonitoring {
  const AppMonitoring._();

  static bool _crashlyticsReady = false;

  static Future<void> initialize() async {
    await AppPerformance.initialize();
    if (kIsWeb) return;
    try {
      await FirebaseCrashlytics.instance.setCrashlyticsCollectionEnabled(!kDebugMode);
      _crashlyticsReady = true;
    } catch (_) {
      _crashlyticsReady = false;
    }
  }

  static void recordFlutterError(FlutterErrorDetails details) {
    FlutterError.presentError(details);
    final stack = details.stack ?? StackTrace.current;
    recordError(details.exception, stack, fatal: true, source: 'flutter_framework');
  }

  static Future<void> recordError(
    Object error,
    StackTrace stackTrace, {
    bool fatal = false,
    String source = 'app',
    Map<String, String> context = const <String, String>{},
  }) async {
    await AppLogger.instance.error(error, stackTrace, source: source, fatal: fatal, context: context);
    if (!_crashlyticsReady || kIsWeb) return;
    try {
      for (final entry in context.entries) {
        await FirebaseCrashlytics.instance.setCustomKey(entry.key, entry.value);
      }
      await FirebaseCrashlytics.instance.recordError(error, stackTrace, fatal: fatal, reason: source);
    } catch (_) {
      // Crash reporting must never break a user flow.
    }
  }

  static Future<void> setUser({required String userId, String? role}) async {
    if (!_crashlyticsReady || kIsWeb) return;
    try {
      await FirebaseCrashlytics.instance.setUserIdentifier(userId);
      if (role != null) await FirebaseCrashlytics.instance.setCustomKey('role', role);
    } catch (_) {}
  }
}
