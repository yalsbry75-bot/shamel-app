class AppConstants {
  const AppConstants._();

  static const double mobileMaxWidth = 430;
  static const double pageHorizontalPadding = 20;
  static const double cardBorderWidth = 1;
  static const int otpLength = 6;
  static const int otpTimeoutSeconds = 60;
  static const int maxOtpAttempts = 5;
  static const String defaultCountryCode = '+967';
}
