import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/admin_repository.dart';
import '../../domain/admin_auth_state.dart';

final adminAuthControllerProvider = StateNotifierProvider<AdminAuthController, AdminAuthState>((ref) {
  return AdminAuthController(ref.watch(adminRepositoryProvider));
});

class AdminAuthController extends StateNotifier<AdminAuthState> {
  AdminAuthController(this._repository) : super(const AdminAuthState());

  final AdminRepository _repository;

  Future<void> restoreSession() async {
    state = state.copyWith(isLoading: true, clearError: true);
    try {
      final admin = await _repository.restoreSession();
      state = state.copyWith(admin: admin, isLoading: false);
    } catch (_) {
      state = state.copyWith(isLoading: false, errorMessage: 'تعذر استعادة جلسة المدير.');
    }
  }

  Future<bool> login({required String login, required String password}) async {
    state = state.copyWith(isLoading: true, clearError: true);
    try {
      final admin = await _repository.login(login: login, password: password);
      state = state.copyWith(admin: admin, isLoading: false);
      return true;
    } catch (error) {
      state = state.copyWith(isLoading: false, errorMessage: _message(error));
      return false;
    }
  }

  Future<void> logout() async {
    await _repository.logout();
    state = state.copyWith(clearAdmin: true, clearError: true, isLoading: false);
  }

  String _message(Object error) {
    final text = error.toString().replaceFirst('Exception: ', '').trim();
    return text.isEmpty ? 'تعذر تسجيل الدخول.' : text;
  }
}
