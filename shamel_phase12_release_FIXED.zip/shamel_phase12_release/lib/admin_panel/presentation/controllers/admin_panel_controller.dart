import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/utils/ui_state.dart';
import '../../data/admin_repository.dart';
import '../../domain/admin_panel_state.dart';
import '../../domain/admin_records.dart';
import '../../domain/admin_user_model.dart';

final adminPanelControllerProvider = StateNotifierProvider<AdminPanelController, AdminPanelState>((ref) {
  return AdminPanelController(ref.watch(adminRepositoryProvider));
});

class AdminPanelController extends StateNotifier<AdminPanelState> {
  AdminPanelController(this._repository) : super(const AdminPanelState());

  final AdminRepository _repository;
  AdminUserModel? _admin;

  Future<void> load(AdminUserModel admin) async {
    _admin = admin;
    state = state.copyWith(viewState: ViewState.loading, clearError: true, clearMessage: true);
    try {
      final data = await _repository.loadBoardData();
      state = state.copyWith(
        viewState: ViewState.success,
        stats: data.stats,
        users: data.users,
        providers: data.providers,
        orders: data.orders,
        ads: data.ads,
        subscriptions: data.subscriptions,
        reports: data.reports,
        ratings: data.ratings,
        governorates: data.governorates,
        categories: data.categories,
        logs: data.logs,
        appErrors: data.appErrors,
      );
    } catch (_) {
      state = state.copyWith(viewState: ViewState.error, errorMessage: 'تعذر تحميل بيانات لوحة الإدارة.');
    }
  }

  void setSearch(String value) => state = state.copyWith(query: value);
  void setStatusFilter(String value) => state = state.copyWith(statusFilter: value);

  Future<void> updateUserStatus(String id, String status) => _mutate('تعديل حالة مستخدم', id, (s) => s.copyWith(users: _update(s.users, id, status: status)));
  Future<void> deleteUser(String id) => _mutate('حذف حساب مستخدم', id, (s) => s.copyWith(users: _remove(s.users, id)));
  Future<void> updateProviderStatus(String id, String status) => _mutate('تعديل حالة مقدم خدمة', id, (s) => s.copyWith(providers: _update(s.providers, id, status: status)));
  Future<void> updateSubscriptionStatus(String id, String status) => _mutate('تعديل اشتراك', id, (s) => s.copyWith(subscriptions: _update(s.subscriptions, id, status: status)));
  Future<void> updateAdStatus(String id, String status) => _mutate('تعديل إعلان', id, (s) => s.copyWith(ads: _update(s.ads, id, status: status)));
  Future<void> deleteAd(String id) => _mutate('حذف إعلان', id, (s) => s.copyWith(ads: _remove(s.ads, id)));
  Future<void> pinAd(String id) => _mutate('تثبيت إعلان في الأعلى', id, (s) => s.copyWith(ads: _togglePin(s.ads, id)));
  Future<void> updateOrderStatus(String id, String status) => _mutate('متابعة حالة طلب', id, (s) => s.copyWith(orders: _update(s.orders, id, status: status)));
  Future<void> updateReportStatus(String id, String status) => _mutate('مراجعة بلاغ', id, (s) => s.copyWith(reports: _update(s.reports, id, status: status)));
  Future<void> updateRatingStatus(String id, bool hidden) => _mutate(hidden ? 'إخفاء تقييم' : 'إظهار تقييم', id, (s) => s.copyWith(ratings: _toggleHidden(s.ratings, id, hidden)));
  Future<void> deleteRating(String id) => _mutate('حذف تقييم مخالف', id, (s) => s.copyWith(ratings: _remove(s.ratings, id)));
  Future<void> addGovernorate(String title) => _mutate('إضافة محافظة', title, (s) => s.copyWith(governorates: [_newRecord('gov', title, 'محافظة مضافة من الإدارة'), ...s.governorates]));
  Future<void> addCategory(String title) => _mutate('إضافة تصنيف', title, (s) => s.copyWith(categories: [_newRecord('cat', title, 'تصنيف مضاف من الإدارة'), ...s.categories]));

  List<AdminRecord> filtered(List<AdminRecord> records) {
    final q = state.query.trim().toLowerCase();
    final status = state.statusFilter.trim().toLowerCase();
    return records.where((item) {
      final text = '${item.title} ${item.subtitle} ${item.phone} ${item.type} ${item.location} ${item.note}'.toLowerCase();
      final matchesQuery = q.isEmpty || text.contains(q);
      final matchesStatus = status.isEmpty || item.status.toLowerCase() == status;
      return matchesQuery && matchesStatus;
    }).toList(growable: false);
  }

  Future<void> _mutate(String action, String target, AdminPanelState Function(AdminPanelState state) builder) async {
    final admin = _admin;
    if (admin == null) {
      state = state.copyWith(errorMessage: 'جلسة المدير غير متاحة.');
      return;
    }
    final nextState = builder(state);
    final logs = await _repository.appendLog(admin: admin, action: action, target: target);
    state = nextState.copyWith(logs: logs, message: 'تم تنفيذ العملية: $action', clearError: true);
  }

  List<AdminRecord> _update(List<AdminRecord> records, String id, {String? status, String? note}) {
    return records.map((item) => item.id == id ? item.copyWith(status: status, note: note) : item).toList(growable: false);
  }

  List<AdminRecord> _remove(List<AdminRecord> records, String id) {
    return records.where((item) => item.id != id).toList(growable: false);
  }

  List<AdminRecord> _togglePin(List<AdminRecord> records, String id) {
    return records.map((item) => item.id == id ? item.copyWith(isPinned: !item.isPinned, note: item.isPinned ? 'غير مثبت' : 'مثبت في الأعلى') : item).toList(growable: false);
  }

  List<AdminRecord> _toggleHidden(List<AdminRecord> records, String id, bool hidden) {
    return records.map((item) => item.id == id ? item.copyWith(isHidden: hidden, status: hidden ? 'Hidden' : 'Visible') : item).toList(growable: false);
  }

  AdminRecord _newRecord(String prefix, String title, String subtitle) {
    return AdminRecord(
      id: '${prefix}_${DateTime.now().microsecondsSinceEpoch}',
      title: title.trim().isEmpty ? 'عنصر جديد' : title.trim(),
      subtitle: subtitle,
      status: 'Active',
      createdAt: DateTime.now(),
      note: 'جاهز للربط مع Backend لاحقًا',
    );
  }
}
