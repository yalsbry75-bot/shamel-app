import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/widgets/shamel_text_field.dart';
import '../controllers/admin_panel_controller.dart';

class AdminFilterBar extends ConsumerWidget {
  const AdminFilterBar({super.key, this.statuses = const []});

  final List<String> statuses;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(adminPanelControllerProvider);
    final controller = ref.read(adminPanelControllerProvider.notifier);
    final selectedStatus = statuses.contains(state.statusFilter) ? state.statusFilter : '';

    Widget searchField() {
      return ShamelTextField(
        hintText: 'ابحث بالاسم، الهاتف، النوع، الحالة...',
        prefixIcon: Icons.search_rounded,
        onChanged: controller.setSearch,
      );
    }

    Widget statusFilter() {
      return Container(
        height: 56,
        padding: const EdgeInsets.symmetric(horizontal: 14),
        decoration: BoxDecoration(
          color: AppColors.surface.withOpacity(0.7),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppColors.border),
        ),
        child: DropdownButtonHideUnderline(
          child: DropdownButton<String>(
            value: selectedStatus,
            isExpanded: true,
            dropdownColor: AppColors.surfaceHigh,
            items: ['', ...statuses].map((item) => DropdownMenuItem(value: item, child: Text(item.isEmpty ? 'كل الحالات' : item))).toList(growable: false),
            onChanged: (value) => controller.setStatusFilter(value ?? ''),
          ),
        ),
      );
    }

    return LayoutBuilder(
      builder: (context, constraints) {
        final isWide = constraints.maxWidth > 720;
        if (isWide) {
          return Row(
            children: [
              Expanded(flex: 2, child: searchField()),
              const SizedBox(width: 12),
              Expanded(child: statusFilter()),
            ],
          );
        }
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            searchField(),
            const SizedBox(height: 12),
            statusFilter(),
          ],
        );
      },
    );
  }
}
