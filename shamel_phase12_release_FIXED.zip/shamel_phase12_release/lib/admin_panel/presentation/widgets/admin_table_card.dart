import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_radius.dart';
import '../../domain/admin_records.dart';
import 'admin_status_chip.dart';

class AdminTableCard extends StatelessWidget {
  const AdminTableCard({
    super.key,
    required this.title,
    required this.records,
    this.actionsBuilder,
    this.emptyLabel = 'لا توجد بيانات.',
  });

  final String title;
  final List<AdminRecord> records;
  final List<Widget> Function(AdminRecord record)? actionsBuilder;
  final String emptyLabel;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface.withOpacity(0.72),
        borderRadius: BorderRadius.circular(AppRadius.xl),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
          const SizedBox(height: 14),
          if (records.isEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 34),
              child: Center(child: Text(emptyLabel, style: const TextStyle(color: AppColors.textSecondary))),
            )
          else
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: DataTable(
                headingTextStyle: const TextStyle(color: AppColors.textSecondary, fontWeight: FontWeight.w800),
                dataTextStyle: const TextStyle(color: AppColors.textPrimary),
                columns: const [
                  DataColumn(label: Text('الاسم')),
                  DataColumn(label: Text('النوع')),
                  DataColumn(label: Text('الحالة')),
                  DataColumn(label: Text('الموقع/الهاتف')),
                  DataColumn(label: Text('ملاحظات')),
                  DataColumn(label: Text('الإجراءات')),
                ],
                rows: records.map((record) {
                  final actions = actionsBuilder?.call(record) ?? const <Widget>[];
                  return DataRow(
                    cells: [
                      DataCell(SizedBox(width: 170, child: Text(record.title, maxLines: 2, overflow: TextOverflow.ellipsis))),
                      DataCell(SizedBox(width: 130, child: Text(record.type.isEmpty ? record.subtitle : record.type, maxLines: 2, overflow: TextOverflow.ellipsis))),
                      DataCell(AdminStatusChip(status: record.status)),
                      DataCell(SizedBox(width: 160, child: Text([record.location, record.phone].where((item) => item.isNotEmpty).join('\n'), maxLines: 2, overflow: TextOverflow.ellipsis))),
                      DataCell(SizedBox(width: 210, child: Text(record.note.isEmpty ? record.amount : record.note, maxLines: 2, overflow: TextOverflow.ellipsis))),
                      DataCell(SizedBox(width: actions.length * 46.0 + 8, child: Row(children: actions))),
                    ],
                  );
                }).toList(growable: false),
              ),
            ),
        ],
      ),
    );
  }
}

class AdminIconAction extends StatelessWidget {
  const AdminIconAction({super.key, required this.icon, required this.tooltip, required this.onPressed});

  final IconData icon;
  final String tooltip;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return IconButton(
      tooltip: tooltip,
      visualDensity: VisualDensity.compact,
      onPressed: onPressed,
      icon: Icon(icon, size: 20),
    );
  }
}
