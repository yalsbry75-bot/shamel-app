import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';

class AdminStatusChip extends StatelessWidget {
  const AdminStatusChip({super.key, required this.status});

  final String status;

  @override
  Widget build(BuildContext context) {
    final color = _color(status);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.14),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: color.withOpacity(0.35)),
      ),
      child: Text(status, style: TextStyle(color: color, fontWeight: FontWeight.w800, fontSize: 12)),
    );
  }

  Color _color(String value) {
    final text = value.toLowerCase();
    if (text.contains('active') || text.contains('completed') || text.contains('visible') || text.contains('resolved')) return AppColors.success;
    if (text.contains('pending') || text.contains('review') || text.contains('new')) return AppColors.warning;
    if (text.contains('suspended') || text.contains('rejected') || text.contains('cancelled') || text.contains('hidden') || text.contains('expired')) return AppColors.error;
    return AppColors.primary;
  }
}
