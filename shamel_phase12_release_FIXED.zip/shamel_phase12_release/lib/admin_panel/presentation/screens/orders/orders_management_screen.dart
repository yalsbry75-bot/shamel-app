import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_colors.dart';
import '../../controllers/admin_panel_controller.dart';
import '../../widgets/admin_filter_bar.dart';
import '../../widgets/admin_section_header.dart';
import '../../widgets/admin_table_card.dart';

class OrdersManagementScreen extends ConsumerWidget {
  const OrdersManagementScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(adminPanelControllerProvider);
    final controller = ref.read(adminPanelControllerProvider.notifier);
    final records = controller.filtered(state.orders);
    return Container(
      color: AppColors.background,
      child: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              AdminSectionHeader(title: 'إدارة الطلبات', subtitle: 'عرض جميع الطلبات والبحث والفلترة ومتابعة الحالات دون تعديل نظام العميل أو المقدم.', trailing: const SizedBox.shrink()),
              const SizedBox(height: 18),
              const AdminFilterBar(statuses: ['Pending', 'Accepted', 'Completed', 'Cancelled', 'Rejected']),
              const SizedBox(height: 18),
              if (state.message.isNotEmpty) ...[
                Text(state.message, style: const TextStyle(color: AppColors.success, fontWeight: FontWeight.w800)),
                const SizedBox(height: 12),
              ],
              AdminTableCard(
                title: 'الطلبات',
                records: records,
                actionsBuilder: (record) => [
                  AdminIconAction(icon: Icons.check_rounded, tooltip: 'مكتمل', onPressed: () => controller.updateOrderStatus(record.id, 'Completed')),
                  AdminIconAction(icon: Icons.pending_actions_rounded, tooltip: 'قيد الانتظار', onPressed: () => controller.updateOrderStatus(record.id, 'Pending')),
                  AdminIconAction(icon: Icons.cancel_rounded, tooltip: 'ملغى', onPressed: () => controller.updateOrderStatus(record.id, 'Cancelled')),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
