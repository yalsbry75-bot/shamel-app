import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/widgets/shamel_button.dart';
import '../../../../core/widgets/shamel_text_field.dart';
import '../../controllers/admin_panel_controller.dart';
import '../../widgets/admin_section_header.dart';
import '../../widgets/admin_table_card.dart';

class TaxonomyManagementScreen extends ConsumerStatefulWidget {
  const TaxonomyManagementScreen({super.key});

  @override
  ConsumerState<TaxonomyManagementScreen> createState() => _TaxonomyManagementScreenState();
}

class _TaxonomyManagementScreenState extends ConsumerState<TaxonomyManagementScreen> {
  final _governorate = TextEditingController();
  final _category = TextEditingController();

  @override
  void dispose() {
    _governorate.dispose();
    _category.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(adminPanelControllerProvider);
    final controller = ref.read(adminPanelControllerProvider.notifier);
    return Container(
      color: AppColors.background,
      child: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const AdminSectionHeader(title: 'إدارة المحافظات والتصنيفات', subtitle: 'إضافة محافظة أو مديرية مستقبلية وتعديل الخدمات والتصنيفات الأساسية.'),
              const SizedBox(height: 18),
              LayoutBuilder(builder: (context, constraints) {
                final wide = constraints.maxWidth > 850;
                final governorateField = ShamelTextField(hintText: 'محافظة جديدة', controller: _governorate, prefixIcon: Icons.location_city_rounded);
                final categoryField = ShamelTextField(hintText: 'تصنيف جديد', controller: _category, prefixIcon: Icons.category_rounded);
                final addGovernorate = ShamelButton.secondary(label: 'إضافة محافظة', onPressed: () { controller.addGovernorate(_governorate.text); _governorate.clear(); });
                final addCategory = ShamelButton.secondary(label: 'إضافة تصنيف', onPressed: () { controller.addCategory(_category.text); _category.clear(); });
                if (wide) {
                  return Row(children: [
                    Expanded(child: governorateField),
                    const SizedBox(width: 12),
                    SizedBox(width: 180, child: addGovernorate),
                    const SizedBox(width: 12),
                    Expanded(child: categoryField),
                    const SizedBox(width: 12),
                    SizedBox(width: 180, child: addCategory),
                  ]);
                }
                return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                  governorateField,
                  const SizedBox(height: 12),
                  addGovernorate,
                  const SizedBox(height: 12),
                  categoryField,
                  const SizedBox(height: 12),
                  addCategory,
                ]);
              }),
              const SizedBox(height: 18),
              AdminTableCard(title: 'المحافظات والمديريات', records: state.governorates, actionsBuilder: (record) => const []),
              const SizedBox(height: 18),
              AdminTableCard(title: 'تصنيفات الخدمات والسوق', records: state.categories, actionsBuilder: (record) => const []),
            ],
          ),
        ),
      ),
    );
  }
}
