import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_colors.dart';
import '../../controllers/admin_panel_controller.dart';
import '../../widgets/admin_filter_bar.dart';
import '../../widgets/admin_section_header.dart';
import '../../widgets/admin_table_card.dart';

class RatingsManagementScreen extends ConsumerWidget {
  const RatingsManagementScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(adminPanelControllerProvider);
    final controller = ref.read(adminPanelControllerProvider.notifier);
    final records = controller.filtered(state.ratings);
    return Container(
      color: AppColors.background,
      child: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              AdminSectionHeader(title: 'إدارة التقييمات', subtitle: 'عرض التقييمات وحذف المخالف منها وإخفاء التعليقات غير المناسبة.', trailing: const SizedBox.shrink()),
              const SizedBox(height: 18),
              const AdminFilterBar(statuses: ['Visible', 'Hidden']),
              const SizedBox(height: 18),
              if (state.message.isNotEmpty) ...[
                Text(state.message, style: const TextStyle(color: AppColors.success, fontWeight: FontWeight.w800)),
                const SizedBox(height: 12),
              ],
              AdminTableCard(
                title: 'التقييمات',
                records: records,
                actionsBuilder: (record) => [
                  AdminIconAction(icon: Icons.visibility_off_rounded, tooltip: 'إخفاء', onPressed: () => controller.updateRatingStatus(record.id, true)),
                  AdminIconAction(icon: Icons.visibility_rounded, tooltip: 'إظهار', onPressed: () => controller.updateRatingStatus(record.id, false)),
                  AdminIconAction(icon: Icons.delete_outline_rounded, tooltip: 'حذف', onPressed: () => controller.deleteRating(record.id)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
