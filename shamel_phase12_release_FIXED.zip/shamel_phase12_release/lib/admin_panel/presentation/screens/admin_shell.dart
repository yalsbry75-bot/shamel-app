import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_colors.dart';
import '../../../routes/app_routes.dart';
import '../../domain/admin_permission.dart';
import '../../domain/admin_role.dart';
import '../controllers/admin_auth_controller.dart';
import '../controllers/admin_panel_controller.dart';
import '../screens/ads/ads_management_screen.dart';
import '../screens/dashboard/admin_dashboard_screen.dart';
import '../screens/logs/system_logs_screen.dart';
import '../screens/orders/orders_management_screen.dart';
import '../screens/permissions/permissions_screen.dart';
import '../screens/providers/providers_management_screen.dart';
import '../screens/ratings/ratings_management_screen.dart';
import '../screens/reports/reports_management_screen.dart';
import '../screens/subscriptions/subscriptions_management_screen.dart';
import '../screens/taxonomy/taxonomy_management_screen.dart';
import '../screens/users/users_management_screen.dart';

class AdminShell extends ConsumerStatefulWidget {
  const AdminShell({super.key});

  @override
  ConsumerState<AdminShell> createState() => _AdminShellState();
}

class _AdminShellState extends ConsumerState<AdminShell> {
  AdminPermission _selected = AdminPermission.dashboard;

  @override
  void initState() {
    super.initState();
    Future.microtask(() async {
      final auth = ref.read(adminAuthControllerProvider);
      if (auth.admin == null) {
        await ref.read(adminAuthControllerProvider.notifier).restoreSession();
      }
      final admin = ref.read(adminAuthControllerProvider).admin;
      if (admin != null) await ref.read(adminPanelControllerProvider.notifier).load(admin);
    });
  }

  @override
  Widget build(BuildContext context) {
    final auth = ref.watch(adminAuthControllerProvider);
    final admin = auth.admin;
    if (auth.isLoading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (admin == null) {
      Future.microtask(() => Navigator.of(context).pushReplacementNamed(AppRoutes.adminLogin));
      return const Scaffold(body: SizedBox.shrink());
    }
    final permissions = admin.role.permissions;
    if (!permissions.contains(_selected)) _selected = permissions.first;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: LayoutBuilder(
          builder: (context, constraints) {
            final isWide = constraints.maxWidth >= 980;
            final body = Row(
              children: [
                if (isWide) _Sidebar(selected: _selected, permissions: permissions, onSelect: (value) => setState(() => _selected = value)),
                Expanded(child: _AdminBody(permission: _selected)),
              ],
            );
            if (isWide) return body;
            return Column(
              children: [
                _TopTabs(selected: _selected, permissions: permissions, onSelect: (value) => setState(() => _selected = value)),
                Expanded(child: body),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _AdminBody extends StatelessWidget {
  const _AdminBody({required this.permission});

  final AdminPermission permission;

  @override
  Widget build(BuildContext context) {
    switch (permission) {
      case AdminPermission.dashboard:
        return const AdminDashboardScreen();
      case AdminPermission.users:
        return const UsersManagementScreen();
      case AdminPermission.providers:
        return const ProvidersManagementScreen();
      case AdminPermission.orders:
        return const OrdersManagementScreen();
      case AdminPermission.ads:
        return const AdsManagementScreen();
      case AdminPermission.subscriptions:
        return const SubscriptionsManagementScreen();
      case AdminPermission.reports:
        return const ReportsManagementScreen();
      case AdminPermission.ratings:
        return const RatingsManagementScreen();
      case AdminPermission.taxonomy:
        return const TaxonomyManagementScreen();
      case AdminPermission.logs:
        return const SystemLogsScreen();
      case AdminPermission.permissions:
        return const PermissionsScreen();
    }
  }
}

class _Sidebar extends ConsumerWidget {
  const _Sidebar({required this.selected, required this.permissions, required this.onSelect});

  final AdminPermission selected;
  final List<AdminPermission> permissions;
  final ValueChanged<AdminPermission> onSelect;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final admin = ref.watch(adminAuthControllerProvider).admin!;
    return Container(
      width: 286,
      decoration: const BoxDecoration(color: Color(0xF2111114), border: Border(left: BorderSide(color: AppColors.border))),
      padding: const EdgeInsets.fromLTRB(16, 18, 16, 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(children: [
            Container(width: 44, height: 44, alignment: Alignment.center, decoration: const BoxDecoration(shape: BoxShape.circle, color: AppColors.primary), child: const Text('ش', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900))),
            const SizedBox(width: 10),
            const Expanded(child: Text('إدارة شامل', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900))),
          ]),
          const SizedBox(height: 8),
          Text('${admin.name} • ${admin.role.label}', style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
          const SizedBox(height: 20),
          Expanded(
            child: ListView(
              children: [for (final item in permissions) _NavTile(item: item, selected: selected == item, onTap: () => onSelect(item))],
            ),
          ),
          OutlinedButton.icon(
            onPressed: () async {
              await ref.read(adminAuthControllerProvider.notifier).logout();
              if (context.mounted) Navigator.of(context).pushReplacementNamed(AppRoutes.adminLogin);
            },
            icon: const Icon(Icons.logout_rounded),
            label: const Text('تسجيل الخروج'),
          ),
        ],
      ),
    );
  }
}

class _TopTabs extends StatelessWidget {
  const _TopTabs({required this.selected, required this.permissions, required this.onSelect});

  final AdminPermission selected;
  final List<AdminPermission> permissions;
  final ValueChanged<AdminPermission> onSelect;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 72,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      decoration: const BoxDecoration(color: Color(0xF2111114), border: Border(bottom: BorderSide(color: AppColors.border))),
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemBuilder: (_, index) => ChoiceChip(
          selected: selected == permissions[index],
          label: Text(permissions[index].label),
          onSelected: (_) => onSelect(permissions[index]),
        ),
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemCount: permissions.length,
      ),
    );
  }
}

class _NavTile extends StatelessWidget {
  const _NavTile({required this.item, required this.selected, required this.onTap});

  final AdminPermission item;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: ListTile(
        onTap: onTap,
        selected: selected,
        selectedTileColor: AppColors.primary.withOpacity(0.14),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        leading: Icon(_icon(item), color: selected ? AppColors.primary : AppColors.textSecondary),
        title: Text(item.label, style: TextStyle(fontWeight: selected ? FontWeight.w900 : FontWeight.w600)),
      ),
    );
  }

  IconData _icon(AdminPermission permission) {
    switch (permission) {
      case AdminPermission.dashboard:
        return Icons.dashboard_rounded;
      case AdminPermission.users:
        return Icons.people_alt_rounded;
      case AdminPermission.providers:
        return Icons.storefront_rounded;
      case AdminPermission.orders:
        return Icons.receipt_long_rounded;
      case AdminPermission.ads:
        return Icons.campaign_rounded;
      case AdminPermission.subscriptions:
        return Icons.workspace_premium_rounded;
      case AdminPermission.reports:
        return Icons.report_rounded;
      case AdminPermission.ratings:
        return Icons.star_rounded;
      case AdminPermission.taxonomy:
        return Icons.account_tree_rounded;
      case AdminPermission.logs:
        return Icons.history_rounded;
      case AdminPermission.permissions:
        return Icons.verified_user_rounded;
    }
  }
}
