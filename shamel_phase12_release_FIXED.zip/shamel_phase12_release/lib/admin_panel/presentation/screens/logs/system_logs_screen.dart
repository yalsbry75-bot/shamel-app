import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_colors.dart';
import '../../controllers/admin_panel_controller.dart';
import '../../widgets/admin_section_header.dart';

class SystemLogsScreen extends ConsumerWidget {
  const SystemLogsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(adminPanelControllerProvider);
    final logs = state.logs;
    final appErrors = state.appErrors;
    return Container(
      color: AppColors.background,
      child: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const AdminSectionHeader(title: 'سجل النظام', subtitle: 'تسجيل دخول المدير والتعديلات وحذف الإعلانات وإيقاف الحسابات وتغيير الاشتراكات.'),
              const SizedBox(height: 18),
              for (final log in logs)
                Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: AppColors.surface.withOpacity(0.72), borderRadius: BorderRadius.circular(18), border: Border.all(color: AppColors.border)),
                  child: Row(children: [
                    const Icon(Icons.history_rounded, color: AppColors.primary),
                    const SizedBox(width: 12),
                    Expanded(child: Text('${log.action}\n${log.target}', style: const TextStyle(height: 1.5))),
                    Text(_date(log.createdAt), style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                  ]),
                ),
              const SizedBox(height: 22),
              const AdminSectionHeader(title: 'سجل أخطاء التطبيق', subtitle: 'أخطاء الشبكة وقاعدة البيانات وتسجيل الدخول والأعطال المسجلة من طبقة AppLogger.'),
              const SizedBox(height: 14),
              for (final error in appErrors)
                Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: AppColors.surface.withOpacity(0.72), borderRadius: BorderRadius.circular(18), border: Border.all(color: AppColors.border)),
                  child: Row(children: [
                    const Icon(Icons.bug_report_outlined, color: Colors.orangeAccent),
                    const SizedBox(width: 12),
                    Expanded(child: Text('${error.title}\n${error.subtitle}\n${error.note}', style: const TextStyle(height: 1.5))),
                    Text(error.status, style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                  ]),
                ),

            ],
          ),
        ),
      ),
    );
  }

  String _date(DateTime value) => '${value.year}-${value.month.toString().padLeft(2, '0')}-${value.day.toString().padLeft(2, '0')} ${value.hour.toString().padLeft(2, '0')}:${value.minute.toString().padLeft(2, '0')}';
}
