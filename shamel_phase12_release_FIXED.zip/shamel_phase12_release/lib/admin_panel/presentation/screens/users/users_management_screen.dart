import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_colors.dart';
import '../../controllers/admin_panel_controller.dart';
import '../../widgets/admin_filter_bar.dart';
import '../../widgets/admin_section_header.dart';
import '../../widgets/admin_table_card.dart';

class UsersManagementScreen extends ConsumerWidget {
  const UsersManagementScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(adminPanelControllerProvider);
    final controller = ref.read(adminPanelControllerProvider.notifier);
    final records = controller.filtered(state.users);
    return Container(
      color: AppColors.background,
      child: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              AdminSectionHeader(title: 'إدارة المستخدمين', subtitle: 'عرض المستخدمين والبحث والفلترة وتعديل الحالة أو حذف الحساب.', trailing: const SizedBox.shrink()),
              const SizedBox(height: 18),
              const AdminFilterBar(statuses: ['Active', 'Pending', 'Suspended']),
              const SizedBox(height: 18),
              if (state.message.isNotEmpty) ...[
                Text(state.message, style: const TextStyle(color: AppColors.success, fontWeight: FontWeight.w800)),
                const SizedBox(height: 12),
              ],
              AdminTableCard(
                title: 'قائمة المستخدمين',
                records: records,
                actionsBuilder: (record) => [
                  AdminIconAction(icon: Icons.pause_circle_rounded, tooltip: 'إيقاف', onPressed: () => controller.updateUserStatus(record.id, 'Suspended')),
                  AdminIconAction(icon: Icons.check_circle_rounded, tooltip: 'تفعيل', onPressed: () => controller.updateUserStatus(record.id, 'Active')),
                  AdminIconAction(icon: Icons.delete_outline_rounded, tooltip: 'حذف', onPressed: () => controller.deleteUser(record.id)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
