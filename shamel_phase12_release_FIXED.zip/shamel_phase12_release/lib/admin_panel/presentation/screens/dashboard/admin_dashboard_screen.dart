import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../domain/admin_dashboard_stats.dart';
import '../../controllers/admin_panel_controller.dart';
import '../../widgets/admin_chart_card.dart';
import '../../widgets/admin_section_header.dart';
import '../../widgets/admin_stat_tile.dart';

class AdminDashboardScreen extends ConsumerWidget {
  const AdminDashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final stats = ref.watch(adminPanelControllerProvider).stats ??
        const AdminDashboardStats(
          totalUsers: 0,
          totalProviders: 0,
          totalOrders: 0,
          completedOrders: 0,
          cancelledOrders: 0,
          activeAds: 0,
          activeSubscriptions: 0,
          newReports: 0,
          totalRatings: 0,
          usersGrowth: [],
          dailyOrders: [],
          topServices: {},
        );
    return _AdminPage(
      children: [
        const AdminSectionHeader(title: 'لوحة التحكم الرئيسية', subtitle: 'نظرة تنفيذية على التطبيق بدون Backend في هذه المرحلة.'),
        const SizedBox(height: 20),
        LayoutBuilder(
          builder: (context, constraints) {
            final width = constraints.maxWidth;
            final count = width > 1200 ? 4 : width > 760 ? 3 : 1;
            return GridView.count(
              crossAxisCount: count,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              childAspectRatio: count == 1 ? 3.4 : 2.1,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              children: [
                AdminStatTile(title: 'إجمالي المستخدمين', value: '${stats.totalUsers}', icon: Icons.people_alt_rounded),
                AdminStatTile(title: 'مقدمو الخدمات', value: '${stats.totalProviders}', icon: Icons.storefront_rounded),
                AdminStatTile(title: 'عدد الطلبات', value: '${stats.totalOrders}', icon: Icons.receipt_long_rounded),
                AdminStatTile(title: 'طلبات مكتملة', value: '${stats.completedOrders}', icon: Icons.check_circle_rounded),
                AdminStatTile(title: 'طلبات ملغاة', value: '${stats.cancelledOrders}', icon: Icons.cancel_rounded),
                AdminStatTile(title: 'إعلانات نشطة', value: '${stats.activeAds}', icon: Icons.campaign_rounded),
                AdminStatTile(title: 'اشتراكات فعالة', value: '${stats.activeSubscriptions}', icon: Icons.workspace_premium_rounded),
                AdminStatTile(title: 'بلاغات جديدة', value: '${stats.newReports}', icon: Icons.report_rounded),
                AdminStatTile(title: 'عدد التقييمات', value: '${stats.totalRatings}', icon: Icons.star_rounded),
              ],
            );
          },
        ),
        const SizedBox(height: 18),
        LayoutBuilder(
          builder: (context, constraints) {
            final wide = constraints.maxWidth > 880;
            final usersChart = AdminChartCard(title: 'نمو المستخدمين', values: stats.usersGrowth, labels: const ['س', 'ح', 'ن', 'ث', 'ر', 'خ', 'ج']);
            final ordersChart = AdminChartCard(title: 'عدد الطلبات يوميًا', values: stats.dailyOrders, labels: const ['س', 'ح', 'ن', 'ث', 'ر', 'خ', 'ج']);
            if (wide) {
              return Row(children: [Expanded(child: usersChart), const SizedBox(width: 12), Expanded(child: ordersChart)]);
            }
            return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [usersChart, const SizedBox(height: 12), ordersChart]);
          },
        ),
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(color: AppColors.surface.withOpacity(0.72), borderRadius: BorderRadius.circular(24), border: Border.all(color: AppColors.border)),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('أكثر الخدمات استخدامًا', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
              const SizedBox(height: 14),
              for (final entry in stats.topServices.entries)
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Row(children: [
                    SizedBox(width: 120, child: Text(entry.key, style: const TextStyle(fontWeight: FontWeight.w800))),
                    Expanded(child: LinearProgressIndicator(value: entry.value / 40, minHeight: 8, borderRadius: BorderRadius.circular(999))),
                    const SizedBox(width: 12),
                    Text('${entry.value}', style: const TextStyle(color: AppColors.textSecondary)),
                  ]),
                ),
            ],
          ),
        ),
      ],
    );
  }
}

class _AdminPage extends StatelessWidget {
  const _AdminPage({required this.children});

  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.background,
      child: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: children),
        ),
      ),
    );
  }
}
