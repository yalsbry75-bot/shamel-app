import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_colors.dart';
import '../../controllers/admin_panel_controller.dart';
import '../../widgets/admin_filter_bar.dart';
import '../../widgets/admin_section_header.dart';
import '../../widgets/admin_table_card.dart';

class ReportsManagementScreen extends ConsumerWidget {
  const ReportsManagementScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(adminPanelControllerProvider);
    final controller = ref.read(adminPanelControllerProvider.notifier);
    final records = controller.filtered(state.reports);
    return Container(
      color: AppColors.background,
      child: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              AdminSectionHeader(title: 'إدارة البلاغات', subtitle: 'عرض البلاغ ومعرفة المبلّغ والمبلّغ عليه ثم قبول أو رفض البلاغ.', trailing: const SizedBox.shrink()),
              const SizedBox(height: 18),
              const AdminFilterBar(statuses: ['New', 'Under Review', 'Resolved', 'Rejected']),
              const SizedBox(height: 18),
              if (state.message.isNotEmpty) ...[
                Text(state.message, style: const TextStyle(color: AppColors.success, fontWeight: FontWeight.w800)),
                const SizedBox(height: 12),
              ],
              AdminTableCard(
                title: 'البلاغات',
                records: records,
                actionsBuilder: (record) => [
                  AdminIconAction(icon: Icons.visibility_rounded, tooltip: 'قيد المراجعة', onPressed: () => controller.updateReportStatus(record.id, 'Under Review')),
                  AdminIconAction(icon: Icons.check_circle_rounded, tooltip: 'قبول/حل', onPressed: () => controller.updateReportStatus(record.id, 'Resolved')),
                  AdminIconAction(icon: Icons.cancel_rounded, tooltip: 'رفض', onPressed: () => controller.updateReportStatus(record.id, 'Rejected')),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
