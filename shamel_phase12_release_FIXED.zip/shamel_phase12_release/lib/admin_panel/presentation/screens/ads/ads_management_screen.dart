import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_colors.dart';
import '../../controllers/admin_panel_controller.dart';
import '../../widgets/admin_filter_bar.dart';
import '../../widgets/admin_section_header.dart';
import '../../widgets/admin_table_card.dart';

class AdsManagementScreen extends ConsumerWidget {
  const AdsManagementScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(adminPanelControllerProvider);
    final controller = ref.read(adminPanelControllerProvider.notifier);
    final records = controller.filtered(state.ads);
    return Container(
      color: AppColors.background,
      child: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              AdminSectionHeader(title: 'إدارة الإعلانات', subtitle: 'قبول الإعلانات ورفضها وحذفها وتثبيتها وتحديد حالتها ضمن السوق.', trailing: const SizedBox.shrink()),
              const SizedBox(height: 18),
              const AdminFilterBar(statuses: ['Active', 'Pending', 'Rejected', 'Expired']),
              const SizedBox(height: 18),
              if (state.message.isNotEmpty) ...[
                Text(state.message, style: const TextStyle(color: AppColors.success, fontWeight: FontWeight.w800)),
                const SizedBox(height: 12),
              ],
              AdminTableCard(
                title: 'الإعلانات',
                records: records,
                actionsBuilder: (record) => [
                  AdminIconAction(icon: Icons.check_circle_rounded, tooltip: 'قبول', onPressed: () => controller.updateAdStatus(record.id, 'Active')),
                  AdminIconAction(icon: Icons.cancel_rounded, tooltip: 'رفض', onPressed: () => controller.updateAdStatus(record.id, 'Rejected')),
                  AdminIconAction(icon: record.isPinned ? Icons.vertical_align_bottom_rounded : Icons.vertical_align_top_rounded, tooltip: 'تثبيت/إلغاء تثبيت', onPressed: () => controller.pinAd(record.id)),
                  AdminIconAction(icon: Icons.delete_outline_rounded, tooltip: 'حذف', onPressed: () => controller.deleteAd(record.id)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
