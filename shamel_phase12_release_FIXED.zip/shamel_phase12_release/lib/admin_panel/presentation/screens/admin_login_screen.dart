import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/widgets/premium_scaffold.dart';
import '../../../core/widgets/shamel_button.dart';
import '../../../core/widgets/shamel_text_field.dart';
import '../../../routes/app_routes.dart';
import '../controllers/admin_auth_controller.dart';

class AdminLoginScreen extends ConsumerStatefulWidget {
  const AdminLoginScreen({super.key});

  @override
  ConsumerState<AdminLoginScreen> createState() => _AdminLoginScreenState();
}

class _AdminLoginScreenState extends ConsumerState<AdminLoginScreen> {
  final _login = TextEditingController();
  final _password = TextEditingController();
  bool _obscure = true;

  @override
  void dispose() {
    _login.dispose();
    _password.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final auth = ref.watch(adminAuthControllerProvider);
    ref.listen(adminAuthControllerProvider, (previous, next) {
      if (next.isAuthenticated && mounted) {
        Navigator.of(context).pushReplacementNamed(AppRoutes.adminShell);
      }
    });
    return PremiumScaffold(
      padding: const EdgeInsets.all(24),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 460),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Container(
                  width: 82,
                  height: 82,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const LinearGradient(colors: [AppColors.primary, Color(0xFF53A7FF)]),
                    boxShadow: [BoxShadow(color: AppColors.primary.withOpacity(0.24), blurRadius: 30)],
                  ),
                  child: const Text('ش', style: TextStyle(fontSize: 42, fontWeight: FontWeight.w900)),
                ),
                const SizedBox(height: 24),
                const Text('دخول الإدارة', textAlign: TextAlign.center, style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
                const SizedBox(height: 8),
                const Text('لوحة تحكم شاملة لإدارة المستخدمين ومقدمي الخدمات والطلبات والإعلانات.', textAlign: TextAlign.center, style: TextStyle(color: AppColors.textSecondary)),
                const SizedBox(height: 28),
                ShamelTextField(hintText: 'بريد/هاتف المدير', controller: _login, prefixIcon: Icons.admin_panel_settings_rounded),
                const SizedBox(height: 14),
                ShamelTextField(
                  hintText: 'كلمة المرور',
                  controller: _password,
                  prefixIcon: Icons.lock_outline_rounded,
                  obscureText: _obscure,
                  suffixIcon: IconButton(
                    onPressed: () => setState(() => _obscure = !_obscure),
                    icon: Icon(_obscure ? Icons.visibility_off_rounded : Icons.visibility_rounded),
                  ),
                ),
                if (auth.errorMessage.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  Text(auth.errorMessage, style: const TextStyle(color: AppColors.error, fontWeight: FontWeight.w800)),
                ],
                const SizedBox(height: 22),
                ShamelButton.primary(
                  label: 'تسجيل الدخول',
                  isLoading: auth.isLoading,
                  icon: Icons.login_rounded,
                  onPressed: () => ref.read(adminAuthControllerProvider.notifier).login(login: _login.text, password: _password.text),
                ),
                const SizedBox(height: 14),
                const Text('يتم إنشاء حساب المدير من Firebase Auth وربطه بوثيقة admins/{uid}.', textAlign: TextAlign.center, style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
