import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_colors.dart';
import '../../controllers/admin_panel_controller.dart';
import '../../widgets/admin_filter_bar.dart';
import '../../widgets/admin_section_header.dart';
import '../../widgets/admin_table_card.dart';

class ProvidersManagementScreen extends ConsumerWidget {
  const ProvidersManagementScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(adminPanelControllerProvider);
    final controller = ref.read(adminPanelControllerProvider.notifier);
    final records = controller.filtered(state.providers);
    return Container(
      color: AppColors.background,
      child: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              AdminSectionHeader(title: 'إدارة مقدمي الخدمات', subtitle: 'مراجعة الملفات التجارية، تفعيل الحساب، إيقاف الحساب، ومراجعة الصور والتقييمات.', trailing: const SizedBox.shrink()),
              const SizedBox(height: 18),
              const AdminFilterBar(statuses: ['Active', 'Pending', 'Suspended', 'Expired']),
              const SizedBox(height: 18),
              if (state.message.isNotEmpty) ...[
                Text(state.message, style: const TextStyle(color: AppColors.success, fontWeight: FontWeight.w800)),
                const SizedBox(height: 12),
              ],
              AdminTableCard(
                title: 'ملفات مقدمي الخدمات',
                records: records,
                actionsBuilder: (record) => [
                  AdminIconAction(icon: Icons.verified_rounded, tooltip: 'تفعيل', onPressed: () => controller.updateProviderStatus(record.id, 'Active')),
                  AdminIconAction(icon: Icons.pause_rounded, tooltip: 'إيقاف', onPressed: () => controller.updateProviderStatus(record.id, 'Suspended')),
                  AdminIconAction(icon: Icons.rate_review_rounded, tooltip: 'قيد المراجعة', onPressed: () => controller.updateProviderStatus(record.id, 'Pending')),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
