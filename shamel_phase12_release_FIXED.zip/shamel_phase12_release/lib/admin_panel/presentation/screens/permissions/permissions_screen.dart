import 'package:flutter/material.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../domain/admin_role.dart';
import '../../widgets/admin_section_header.dart';

class PermissionsScreen extends StatelessWidget {
  const PermissionsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.background,
      child: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const AdminSectionHeader(title: 'نظام الصلاحيات', subtitle: 'أدوار إدارية منفصلة: مدير رئيسي، مدير محتوى، مدير اشتراكات، مدير دعم.'),
              const SizedBox(height: 18),
              Wrap(
                spacing: 12,
                runSpacing: 12,
                children: [
                  for (final role in AdminRole.values)
                    Container(
                      width: 320,
                      padding: const EdgeInsets.all(18),
                      decoration: BoxDecoration(color: AppColors.surface.withOpacity(0.72), borderRadius: BorderRadius.circular(24), border: Border.all(color: AppColors.border)),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(role.label, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                          const SizedBox(height: 14),
                          for (final permission in role.permissions)
                            Padding(
                              padding: const EdgeInsets.only(bottom: 8),
                              child: Row(children: [
                                const Icon(Icons.check_circle_rounded, color: AppColors.success, size: 18),
                                const SizedBox(width: 8),
                                Expanded(child: Text(permission.label)),
                              ]),
                            ),
                        ],
                      ),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
