import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../domain/admin_dashboard_stats.dart';
import '../domain/admin_records.dart';
import '../domain/admin_role.dart';
import '../domain/admin_user_model.dart';
import '../domain/system_log_model.dart';
import 'admin_service.dart';

final adminServiceProvider = Provider<AdminService>((ref) => FirebaseAdminService());

final adminRepositoryProvider = Provider<AdminRepository>((ref) {
  return AdminRepository(ref.watch(adminServiceProvider));
});

class AdminRepository {
  const AdminRepository(this._service);

  final AdminService _service;

  Future<AdminUserModel?> restoreSession() => _service.restoreSession();
  Future<AdminUserModel> login({required String login, required String password}) => _service.login(login: login, password: password);
  Future<void> logout() => _service.logout();
  Future<AdminDashboardStats> loadStats() => _service.loadStats();

  Future<AdminBoardData> loadBoardData() async {
    final result = await Future.wait<dynamic>([
      _service.loadStats(),
      _service.loadUsers(),
      _service.loadProviders(),
      _service.loadOrders(),
      _service.loadAds(),
      _service.loadSubscriptions(),
      _service.loadReports(),
      _service.loadRatings(),
      _service.loadGovernorates(),
      _service.loadCategories(),
      _service.loadLogs(),
      _service.loadAppErrors(),
    ]);
    return AdminBoardData(
      stats: result[0] as AdminDashboardStats,
      users: result[1] as List<AdminRecord>,
      providers: result[2] as List<AdminRecord>,
      orders: result[3] as List<AdminRecord>,
      ads: result[4] as List<AdminRecord>,
      subscriptions: result[5] as List<AdminRecord>,
      reports: result[6] as List<AdminRecord>,
      ratings: result[7] as List<AdminRecord>,
      governorates: result[8] as List<AdminRecord>,
      categories: result[9] as List<AdminRecord>,
      logs: result[10] as List<SystemLogModel>,
      appErrors: result[11] as List<AdminRecord>,
    );
  }

  Future<List<SystemLogModel>> appendLog({required AdminUserModel admin, required String action, required String target}) async {
    final logs = await _service.loadLogs();
    final next = [
      SystemLogModel(
        logId: 'log_${DateTime.now().microsecondsSinceEpoch}',
        adminId: admin.adminId,
        action: action,
        target: target,
        createdAt: DateTime.now(),
      ),
      ...logs,
    ];
    await _service.saveLogs(next);
    return next;
  }

  bool hasPermission(AdminUserModel admin, AdminRole role) => admin.role == AdminRole.superAdmin || admin.role == role;
}

class AdminBoardData {
  const AdminBoardData({
    required this.stats,
    required this.users,
    required this.providers,
    required this.orders,
    required this.ads,
    required this.subscriptions,
    required this.reports,
    required this.ratings,
    required this.governorates,
    required this.categories,
    required this.logs,
    required this.appErrors,
  });

  final AdminDashboardStats stats;
  final List<AdminRecord> users;
  final List<AdminRecord> providers;
  final List<AdminRecord> orders;
  final List<AdminRecord> ads;
  final List<AdminRecord> subscriptions;
  final List<AdminRecord> reports;
  final List<AdminRecord> ratings;
  final List<AdminRecord> governorates;
  final List<AdminRecord> categories;
  final List<SystemLogModel> logs;
  final List<AdminRecord> appErrors;
}
