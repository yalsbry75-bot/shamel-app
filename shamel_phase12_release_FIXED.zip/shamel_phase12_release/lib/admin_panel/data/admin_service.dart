import '../domain/admin_dashboard_stats.dart';
import '../domain/admin_records.dart';
import '../domain/admin_user_model.dart';
import '../domain/system_log_model.dart';

import '../../core/database/firestore_json.dart';
import '../../core/database/firestore_collections.dart';
import 'package:firebase_auth/firebase_auth.dart' as fb;
import 'package:cloud_firestore/cloud_firestore.dart';
abstract class AdminService {
  Future<AdminUserModel?> restoreSession();
  Future<AdminUserModel> login({required String login, required String password});
  Future<void> logout();
  Future<AdminDashboardStats> loadStats();
  Future<List<AdminRecord>> loadUsers();
  Future<List<AdminRecord>> loadProviders();
  Future<List<AdminRecord>> loadOrders();
  Future<List<AdminRecord>> loadAds();
  Future<List<AdminRecord>> loadSubscriptions();
  Future<List<AdminRecord>> loadReports();
  Future<List<AdminRecord>> loadRatings();
  Future<List<AdminRecord>> loadGovernorates();
  Future<List<AdminRecord>> loadCategories();
  Future<List<SystemLogModel>> loadLogs();
  Future<List<AdminRecord>> loadAppErrors();
  Future<void> saveLogs(List<SystemLogModel> logs);
}

class FirebaseAdminService implements AdminService {
  FirebaseAdminService({fb.FirebaseAuth? auth, FirebaseFirestore? firestore})
      : _auth = auth ?? fb.FirebaseAuth.instance,
        _firestore = firestore ?? FirebaseFirestore.instance;

  final fb.FirebaseAuth _auth;
  final FirebaseFirestore _firestore;

  @override
  Future<AdminUserModel?> restoreSession() async {
    final user = _auth.currentUser;
    if (user == null) return null;
    final doc = await _firestore.collection(FirestoreCollections.admins).doc(user.uid).get();
    if (!doc.exists || doc.data() == null) return null;
    final admin = AdminUserModel.fromJson(FirestoreJson.normalize(doc.data()!));
    return admin.isActive ? admin : null;
  }

  @override
  Future<AdminUserModel> login({required String login, required String password}) async {
    final result = await _auth.signInWithEmailAndPassword(email: login.trim(), password: password);
    final user = result.user;
    if (user == null) throw Exception('بيانات دخول المدير غير صحيحة.');
    final doc = await _firestore.collection(FirestoreCollections.admins).doc(user.uid).get();
    if (!doc.exists || doc.data() == null) throw Exception('هذا الحساب غير مسجل كمدير.');
    final admin = AdminUserModel.fromJson(FirestoreJson.normalize(doc.data()!)).copyWith(lastLoginAt: DateTime.now());
    if (!admin.isActive) throw Exception('حساب المدير غير مفعل.');
    await _firestore.collection(FirestoreCollections.admins).doc(user.uid).set(FirestoreJson.withServerAudit(admin.toJson()), SetOptions(merge: true));
    await _appendLog(admin.adminId, 'تسجيل دخول المدير', 'Admin Panel');
    return admin;
  }

  @override
  Future<void> logout() async {
    await _auth.signOut();
  }

  @override
  Future<AdminDashboardStats> loadStats() async {
    final users = await _firestore.collection(FirestoreCollections.users).limit(500).get();
    final providers = await _firestore.collection(FirestoreCollections.providers).limit(500).get();
    final orders = await _firestore.collection(FirestoreCollections.orders).limit(500).get();
    final ads = await _firestore.collection(FirestoreCollections.ads).limit(500).get();
    final subscriptions = await _firestore.collection(FirestoreCollections.subscriptions).limit(500).get();
    final reports = await _firestore.collection(FirestoreCollections.reports).limit(500).get();
    final ratings = await _firestore.collection(FirestoreCollections.ratings).limit(500).get();

    final orderDocs = orders.docs.map((doc) => doc.data()).toList(growable: false);
    return AdminDashboardStats(
      totalUsers: users.size,
      totalProviders: providers.size,
      totalOrders: orders.size,
      completedOrders: orderDocs.where((item) => item['status'] == 'completed').length,
      cancelledOrders: orderDocs.where((item) => item['status'] == 'cancelled').length,
      activeAds: ads.docs.where((doc) => doc.data()['status'] == 'active').length,
      activeSubscriptions: subscriptions.docs.where((doc) => doc.data()['status'] == 'active').length,
      newReports: reports.docs.where((doc) => (doc.data()['status'] ?? 'new') == 'new').length,
      totalRatings: ratings.size,
      usersGrowth: _weeklyCounts(users.docs.map((doc) => doc.data()).toList()),
      dailyOrders: _weeklyCounts(orderDocs),
      topServices: _topServices(orderDocs),
    );
  }

  @override
  Future<List<AdminRecord>> loadUsers() => _loadAsRecords(FirestoreCollections.users, titleField: 'name', subtitleField: 'phoneNumber', typeField: 'userType');
  @override
  Future<List<AdminRecord>> loadProviders() => _loadAsRecords(FirestoreCollections.providers, titleField: 'businessName', subtitleField: 'serviceType', phoneField: 'phoneNumber', locationField: 'governorate');
  @override
  Future<List<AdminRecord>> loadOrders() => _loadAsRecords(FirestoreCollections.orders, titleField: 'serviceType', subtitleField: 'description', phoneField: 'phoneNumber', locationField: 'locationText');
  @override
  Future<List<AdminRecord>> loadAds() => _loadAsRecords(FirestoreCollections.ads, titleField: 'title', subtitleField: 'description', phoneField: 'phoneNumber', locationField: 'locationText');
  @override
  Future<List<AdminRecord>> loadSubscriptions() => _loadAsRecords(FirestoreCollections.subscriptions, titleField: 'providerId', subtitleField: 'planType', typeField: 'paymentStatus');
  @override
  Future<List<AdminRecord>> loadReports() => _loadAsRecords(FirestoreCollections.reports, titleField: 'title', subtitleField: 'description', typeField: 'targetType');
  @override
  Future<List<AdminRecord>> loadRatings() => _loadAsRecords(FirestoreCollections.ratings, titleField: 'providerId', subtitleField: 'comment', typeField: 'stars');
  @override
  Future<List<AdminRecord>> loadGovernorates() => _loadAsRecords(FirestoreCollections.governorates, titleField: 'name', subtitleField: 'description');
  @override
  Future<List<AdminRecord>> loadCategories() => _loadAsRecords(FirestoreCollections.categories, titleField: 'name', subtitleField: 'description');

  @override
  Future<List<SystemLogModel>> loadLogs() async {
    final snapshot = await _firestore.collection(FirestoreCollections.adminLogs).orderBy('createdAt', descending: true).limit(100).get();
    return snapshot.docs.map((doc) => SystemLogModel.fromJson(FirestoreJson.normalize(doc.data()))).toList(growable: false);
  }

  @override
  Future<List<AdminRecord>> loadAppErrors() => _loadAsRecords(FirestoreCollections.appErrorLogs, titleField: 'message', subtitleField: 'source', statusField: 'level', typeField: 'code');

  @override
  Future<void> saveLogs(List<SystemLogModel> logs) async {
    final batch = _firestore.batch();
    for (final log in logs.take(100)) {
      batch.set(_firestore.collection(FirestoreCollections.adminLogs).doc(log.logId), FirestoreJson.withServerAudit(log.toJson(), isCreate: true), SetOptions(merge: true));
    }
    await batch.commit();
  }

  Future<List<AdminRecord>> _loadAsRecords(String collection, {required String titleField, required String subtitleField, String statusField = 'status', String phoneField = 'phoneNumber', String typeField = 'type', String locationField = 'locationText'}) async {
    final snapshot = await _firestore.collection(collection).limit(100).get();
    return snapshot.docs.map((doc) {
      final data = FirestoreJson.normalize(doc.data());
      return AdminRecord(
        id: doc.id,
        title: (data[titleField] ?? doc.id).toString(),
        subtitle: (data[subtitleField] ?? '').toString(),
        status: (data[statusField] ?? 'active').toString(),
        createdAt: DateTime.tryParse((data['createdAt'] ?? '').toString()) ?? DateTime.now(),
        phone: (data[phoneField] ?? '').toString(),
        type: (data[typeField] ?? '').toString(),
        location: (data[locationField] ?? data['governorate'] ?? '').toString(),
        note: collection,
        amount: (data['priceAfter'] ?? data['price'] ?? '').toString(),
        isPinned: data['isPinned'] == true,
        isHidden: data['isHidden'] == true,
      );
    }).toList(growable: false);
  }

  List<int> _weeklyCounts(List<Map<String, dynamic>> docs) {
    final now = DateTime.now();
    return List<int>.generate(7, (index) {
      final target = DateTime(now.year, now.month, now.day).subtract(Duration(days: 6 - index));
      return docs.where((data) {
        final createdAt = DateTime.tryParse((FirestoreJson.normalize(data)['createdAt'] ?? '').toString());
        if (createdAt == null) return false;
        return createdAt.year == target.year && createdAt.month == target.month && createdAt.day == target.day;
      }).length;
    }, growable: false);
  }

  Map<String, int> _topServices(List<Map<String, dynamic>> docs) {
    final map = <String, int>{};
    for (final data in docs) {
      final key = (data['serviceType'] ?? data['category'] ?? 'غير محدد').toString();
      map[key] = (map[key] ?? 0) + 1;
    }
    final entries = map.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    return Map<String, int>.fromEntries(entries.take(5));
  }

  Future<void> _appendLog(String adminId, String action, String target) async {
    final log = SystemLogModel(logId: 'log_${DateTime.now().microsecondsSinceEpoch}', adminId: adminId, action: action, target: target, createdAt: DateTime.now());
    await _firestore.collection(FirestoreCollections.adminLogs).doc(log.logId).set(FirestoreJson.withServerAudit(log.toJson(), isCreate: true), SetOptions(merge: true));
  }
}
