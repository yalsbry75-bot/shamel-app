class AdminRecord {
  const AdminRecord({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.status,
    required this.createdAt,
    this.phone = '',
    this.type = '',
    this.location = '',
    this.note = '',
    this.amount = '',
    this.isPinned = false,
    this.isHidden = false,
    this.metadata = const {},
  });

  final String id;
  final String title;
  final String subtitle;
  final String status;
  final DateTime createdAt;
  final String phone;
  final String type;
  final String location;
  final String note;
  final String amount;
  final bool isPinned;
  final bool isHidden;
  final Map<String, String> metadata;

  factory AdminRecord.fromJson(Map<String, dynamic> json) {
    return AdminRecord(
      id: json['id'] as String? ?? '',
      title: json['title'] as String? ?? '',
      subtitle: json['subtitle'] as String? ?? '',
      status: json['status'] as String? ?? '',
      createdAt: DateTime.tryParse(json['createdAt'] as String? ?? '') ?? DateTime.now(),
      phone: json['phone'] as String? ?? '',
      type: json['type'] as String? ?? '',
      location: json['location'] as String? ?? '',
      note: json['note'] as String? ?? '',
      amount: json['amount'] as String? ?? '',
      isPinned: json['isPinned'] as bool? ?? false,
      isHidden: json['isHidden'] as bool? ?? false,
      metadata: Map<String, String>.from(json['metadata'] as Map? ?? const {}),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'subtitle': subtitle,
      'status': status,
      'createdAt': createdAt.toIso8601String(),
      'phone': phone,
      'type': type,
      'location': location,
      'note': note,
      'amount': amount,
      'isPinned': isPinned,
      'isHidden': isHidden,
      'metadata': metadata,
    };
  }

  AdminRecord copyWith({
    String? id,
    String? title,
    String? subtitle,
    String? status,
    DateTime? createdAt,
    String? phone,
    String? type,
    String? location,
    String? note,
    String? amount,
    bool? isPinned,
    bool? isHidden,
    Map<String, String>? metadata,
  }) {
    return AdminRecord(
      id: id ?? this.id,
      title: title ?? this.title,
      subtitle: subtitle ?? this.subtitle,
      status: status ?? this.status,
      createdAt: createdAt ?? this.createdAt,
      phone: phone ?? this.phone,
      type: type ?? this.type,
      location: location ?? this.location,
      note: note ?? this.note,
      amount: amount ?? this.amount,
      isPinned: isPinned ?? this.isPinned,
      isHidden: isHidden ?? this.isHidden,
      metadata: metadata ?? this.metadata,
    );
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        other is AdminRecord &&
            id == other.id &&
            title == other.title &&
            subtitle == other.subtitle &&
            status == other.status &&
            createdAt == other.createdAt &&
            phone == other.phone &&
            type == other.type &&
            location == other.location &&
            note == other.note &&
            amount == other.amount &&
            isPinned == other.isPinned &&
            isHidden == other.isHidden;
  }

  @override
  int get hashCode => Object.hash(id, title, subtitle, status, createdAt, phone, type, location, note, amount, isPinned, isHidden);
}
