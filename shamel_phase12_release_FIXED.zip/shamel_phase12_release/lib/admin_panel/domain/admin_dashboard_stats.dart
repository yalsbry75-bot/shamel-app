class AdminDashboardStats {
  const AdminDashboardStats({
    required this.totalUsers,
    required this.totalProviders,
    required this.totalOrders,
    required this.completedOrders,
    required this.cancelledOrders,
    required this.activeAds,
    required this.activeSubscriptions,
    required this.newReports,
    required this.totalRatings,
    required this.usersGrowth,
    required this.dailyOrders,
    required this.topServices,
  });

  final int totalUsers;
  final int totalProviders;
  final int totalOrders;
  final int completedOrders;
  final int cancelledOrders;
  final int activeAds;
  final int activeSubscriptions;
  final int newReports;
  final int totalRatings;
  final List<int> usersGrowth;
  final List<int> dailyOrders;
  final Map<String, int> topServices;

  factory AdminDashboardStats.fromJson(Map<String, dynamic> json) {
    return AdminDashboardStats(
      totalUsers: json['totalUsers'] as int? ?? 0,
      totalProviders: json['totalProviders'] as int? ?? 0,
      totalOrders: json['totalOrders'] as int? ?? 0,
      completedOrders: json['completedOrders'] as int? ?? 0,
      cancelledOrders: json['cancelledOrders'] as int? ?? 0,
      activeAds: json['activeAds'] as int? ?? 0,
      activeSubscriptions: json['activeSubscriptions'] as int? ?? 0,
      newReports: json['newReports'] as int? ?? 0,
      totalRatings: json['totalRatings'] as int? ?? 0,
      usersGrowth: (json['usersGrowth'] as List<dynamic>? ?? const []).map((item) => item as int? ?? 0).toList(growable: false),
      dailyOrders: (json['dailyOrders'] as List<dynamic>? ?? const []).map((item) => item as int? ?? 0).toList(growable: false),
      topServices: Map<String, int>.from(json['topServices'] as Map? ?? const {}),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'totalUsers': totalUsers,
      'totalProviders': totalProviders,
      'totalOrders': totalOrders,
      'completedOrders': completedOrders,
      'cancelledOrders': cancelledOrders,
      'activeAds': activeAds,
      'activeSubscriptions': activeSubscriptions,
      'newReports': newReports,
      'totalRatings': totalRatings,
      'usersGrowth': usersGrowth,
      'dailyOrders': dailyOrders,
      'topServices': topServices,
    };
  }

  AdminDashboardStats copyWith({
    int? totalUsers,
    int? totalProviders,
    int? totalOrders,
    int? completedOrders,
    int? cancelledOrders,
    int? activeAds,
    int? activeSubscriptions,
    int? newReports,
    int? totalRatings,
    List<int>? usersGrowth,
    List<int>? dailyOrders,
    Map<String, int>? topServices,
  }) {
    return AdminDashboardStats(
      totalUsers: totalUsers ?? this.totalUsers,
      totalProviders: totalProviders ?? this.totalProviders,
      totalOrders: totalOrders ?? this.totalOrders,
      completedOrders: completedOrders ?? this.completedOrders,
      cancelledOrders: cancelledOrders ?? this.cancelledOrders,
      activeAds: activeAds ?? this.activeAds,
      activeSubscriptions: activeSubscriptions ?? this.activeSubscriptions,
      newReports: newReports ?? this.newReports,
      totalRatings: totalRatings ?? this.totalRatings,
      usersGrowth: usersGrowth ?? this.usersGrowth,
      dailyOrders: dailyOrders ?? this.dailyOrders,
      topServices: topServices ?? this.topServices,
    );
  }
}
