import '../../core/utils/ui_state.dart';
import 'admin_dashboard_stats.dart';
import 'admin_records.dart';
import 'system_log_model.dart';

class AdminPanelState {
  const AdminPanelState({
    this.viewState = ViewState.idle,
    this.stats,
    this.users = const [],
    this.providers = const [],
    this.orders = const [],
    this.ads = const [],
    this.subscriptions = const [],
    this.reports = const [],
    this.ratings = const [],
    this.governorates = const [],
    this.categories = const [],
    this.logs = const [],
    this.appErrors = const [],
    this.query = '',
    this.statusFilter = '',
    this.message = '',
    this.errorMessage = '',
  });

  final ViewState viewState;
  final AdminDashboardStats? stats;
  final List<AdminRecord> users;
  final List<AdminRecord> providers;
  final List<AdminRecord> orders;
  final List<AdminRecord> ads;
  final List<AdminRecord> subscriptions;
  final List<AdminRecord> reports;
  final List<AdminRecord> ratings;
  final List<AdminRecord> governorates;
  final List<AdminRecord> categories;
  final List<SystemLogModel> logs;
  final List<AdminRecord> appErrors;
  final String query;
  final String statusFilter;
  final String message;
  final String errorMessage;

  AdminPanelState copyWith({
    ViewState? viewState,
    AdminDashboardStats? stats,
    List<AdminRecord>? users,
    List<AdminRecord>? providers,
    List<AdminRecord>? orders,
    List<AdminRecord>? ads,
    List<AdminRecord>? subscriptions,
    List<AdminRecord>? reports,
    List<AdminRecord>? ratings,
    List<AdminRecord>? governorates,
    List<AdminRecord>? categories,
    List<SystemLogModel>? logs,
    List<AdminRecord>? appErrors,
    String? query,
    String? statusFilter,
    String? message,
    String? errorMessage,
    bool clearMessage = false,
    bool clearError = false,
  }) {
    return AdminPanelState(
      viewState: viewState ?? this.viewState,
      stats: stats ?? this.stats,
      users: users ?? this.users,
      providers: providers ?? this.providers,
      orders: orders ?? this.orders,
      ads: ads ?? this.ads,
      subscriptions: subscriptions ?? this.subscriptions,
      reports: reports ?? this.reports,
      ratings: ratings ?? this.ratings,
      governorates: governorates ?? this.governorates,
      categories: categories ?? this.categories,
      logs: logs ?? this.logs,
      appErrors: appErrors ?? this.appErrors,
      query: query ?? this.query,
      statusFilter: statusFilter ?? this.statusFilter,
      message: clearMessage ? '' : message ?? this.message,
      errorMessage: clearError ? '' : errorMessage ?? this.errorMessage,
    );
  }
}
