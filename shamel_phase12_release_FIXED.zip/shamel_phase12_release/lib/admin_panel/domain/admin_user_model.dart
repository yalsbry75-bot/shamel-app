import 'admin_role.dart';

class AdminUserModel {
  const AdminUserModel({
    required this.adminId,
    required this.name,
    required this.login,
    required this.role,
    required this.createdAt,
    this.isActive = true,
    this.lastLoginAt,
  });

  final String adminId;
  final String name;
  final String login;
  final AdminRole role;
  final DateTime createdAt;
  final bool isActive;
  final DateTime? lastLoginAt;

  factory AdminUserModel.fromJson(Map<String, dynamic> json) {
    return AdminUserModel(
      adminId: json['adminId'] as String? ?? '',
      name: json['name'] as String? ?? '',
      login: json['login'] as String? ?? '',
      role: AdminRoleX.fromValue(json['role'] as String? ?? 'support_manager'),
      createdAt: DateTime.tryParse(json['createdAt'] as String? ?? '') ?? DateTime.now(),
      isActive: json['isActive'] as bool? ?? true,
      lastLoginAt: _date(json['lastLoginAt']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'adminId': adminId,
      'name': name,
      'login': login,
      'role': role.value,
      'createdAt': createdAt.toIso8601String(),
      'isActive': isActive,
      'lastLoginAt': lastLoginAt?.toIso8601String(),
    };
  }

  AdminUserModel copyWith({
    String? adminId,
    String? name,
    String? login,
    AdminRole? role,
    DateTime? createdAt,
    bool? isActive,
    DateTime? lastLoginAt,
  }) {
    return AdminUserModel(
      adminId: adminId ?? this.adminId,
      name: name ?? this.name,
      login: login ?? this.login,
      role: role ?? this.role,
      createdAt: createdAt ?? this.createdAt,
      isActive: isActive ?? this.isActive,
      lastLoginAt: lastLoginAt ?? this.lastLoginAt,
    );
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        other is AdminUserModel &&
            adminId == other.adminId &&
            name == other.name &&
            login == other.login &&
            role == other.role &&
            createdAt == other.createdAt &&
            isActive == other.isActive &&
            lastLoginAt == other.lastLoginAt;
  }

  @override
  int get hashCode => Object.hash(adminId, name, login, role, createdAt, isActive, lastLoginAt);

  static DateTime? _date(dynamic value) {
    if (value == null || value.toString().isEmpty) return null;
    return DateTime.tryParse(value.toString());
  }
}
