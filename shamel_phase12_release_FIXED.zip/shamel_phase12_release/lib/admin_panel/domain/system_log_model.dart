class SystemLogModel {
  const SystemLogModel({
    required this.logId,
    required this.adminId,
    required this.action,
    required this.target,
    required this.createdAt,
  });

  final String logId;
  final String adminId;
  final String action;
  final String target;
  final DateTime createdAt;

  factory SystemLogModel.fromJson(Map<String, dynamic> json) {
    return SystemLogModel(
      logId: json['logId'] as String? ?? '',
      adminId: json['adminId'] as String? ?? '',
      action: json['action'] as String? ?? '',
      target: json['target'] as String? ?? '',
      createdAt: DateTime.tryParse(json['createdAt'] as String? ?? '') ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'logId': logId,
      'adminId': adminId,
      'action': action,
      'target': target,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  SystemLogModel copyWith({String? logId, String? adminId, String? action, String? target, DateTime? createdAt}) {
    return SystemLogModel(
      logId: logId ?? this.logId,
      adminId: adminId ?? this.adminId,
      action: action ?? this.action,
      target: target ?? this.target,
      createdAt: createdAt ?? this.createdAt,
    );
  }
}
