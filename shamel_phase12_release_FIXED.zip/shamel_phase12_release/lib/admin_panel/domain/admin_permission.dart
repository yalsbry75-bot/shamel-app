enum AdminPermission {
  dashboard,
  users,
  providers,
  orders,
  ads,
  subscriptions,
  reports,
  ratings,
  taxonomy,
  logs,
  permissions,
}

extension AdminPermissionX on AdminPermission {
  String get label {
    switch (this) {
      case AdminPermission.dashboard:
        return 'لوحة التحكم';
      case AdminPermission.users:
        return 'المستخدمون';
      case AdminPermission.providers:
        return 'مقدمو الخدمات';
      case AdminPermission.orders:
        return 'الطلبات';
      case AdminPermission.ads:
        return 'الإعلانات';
      case AdminPermission.subscriptions:
        return 'الاشتراكات';
      case AdminPermission.reports:
        return 'البلاغات';
      case AdminPermission.ratings:
        return 'التقييمات';
      case AdminPermission.taxonomy:
        return 'المحافظات والتصنيفات';
      case AdminPermission.logs:
        return 'سجل العمليات';
      case AdminPermission.permissions:
        return 'الصلاحيات';
    }
  }

  String get key => name;

  static AdminPermission fromKey(String key) {
    return AdminPermission.values.firstWhere(
      (item) => item.key == key,
      orElse: () => AdminPermission.dashboard,
    );
  }
}
