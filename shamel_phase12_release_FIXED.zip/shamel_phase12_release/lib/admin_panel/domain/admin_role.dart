import 'admin_permission.dart';

enum AdminRole {
  superAdmin,
  contentManager,
  subscriptionManager,
  supportManager,
}

extension AdminRoleX on AdminRole {
  String get value {
    switch (this) {
      case AdminRole.superAdmin:
        return 'super_admin';
      case AdminRole.contentManager:
        return 'content_manager';
      case AdminRole.subscriptionManager:
        return 'subscription_manager';
      case AdminRole.supportManager:
        return 'support_manager';
    }
  }

  String get label {
    switch (this) {
      case AdminRole.superAdmin:
        return 'مدير رئيسي';
      case AdminRole.contentManager:
        return 'مدير محتوى';
      case AdminRole.subscriptionManager:
        return 'مدير اشتراكات';
      case AdminRole.supportManager:
        return 'مدير دعم';
    }
  }

  List<AdminPermission> get permissions {
    switch (this) {
      case AdminRole.superAdmin:
        return AdminPermission.values;
      case AdminRole.contentManager:
        return const [
          AdminPermission.dashboard,
          AdminPermission.providers,
          AdminPermission.ads,
          AdminPermission.ratings,
          AdminPermission.taxonomy,
          AdminPermission.logs,
        ];
      case AdminRole.subscriptionManager:
        return const [
          AdminPermission.dashboard,
          AdminPermission.providers,
          AdminPermission.subscriptions,
          AdminPermission.logs,
        ];
      case AdminRole.supportManager:
        return const [
          AdminPermission.dashboard,
          AdminPermission.users,
          AdminPermission.orders,
          AdminPermission.reports,
          AdminPermission.ratings,
          AdminPermission.logs,
        ];
    }
  }

  bool can(AdminPermission permission) => permissions.contains(permission);

  static AdminRole fromValue(String value) {
    return AdminRole.values.firstWhere(
      (item) => item.value == value,
      orElse: () => AdminRole.supportManager,
    );
  }
}
