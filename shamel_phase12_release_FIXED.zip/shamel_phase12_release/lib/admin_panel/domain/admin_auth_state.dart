import 'admin_user_model.dart';

class AdminAuthState {
  const AdminAuthState({
    this.admin,
    this.isLoading = false,
    this.errorMessage = '',
  });

  final AdminUserModel? admin;
  final bool isLoading;
  final String errorMessage;

  bool get isAuthenticated => admin != null;

  AdminAuthState copyWith({
    AdminUserModel? admin,
    bool? isLoading,
    String? errorMessage,
    bool clearAdmin = false,
    bool clearError = false,
  }) {
    return AdminAuthState(
      admin: clearAdmin ? null : admin ?? this.admin,
      isLoading: isLoading ?? this.isLoading,
      errorMessage: clearError ? '' : errorMessage ?? this.errorMessage,
    );
  }
}
