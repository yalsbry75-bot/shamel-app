import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'core/api/firebase_backend_initializer.dart';
import 'core/config/production_config.dart';
import 'core/monitoring/app_monitoring.dart';
import 'core/theme/app_theme.dart';
import 'core/widgets/offline_banner.dart';
import 'routes/app_routes.dart';

Future<void> main() async {
  await runZonedGuarded<Future<void>>(() async {
    WidgetsFlutterBinding.ensureInitialized();
    FlutterError.onError = AppMonitoring.recordFlutterError;
    final backendReady = await FirebaseBackendInitializer.initialize();
    runApp(ProviderScope(child: ShamelApp(backendReady: backendReady)));
  }, (error, stackTrace) async {
    await AppMonitoring.recordError(error, stackTrace, fatal: true, source: 'runZonedGuarded');
  });
}

class ShamelApp extends StatelessWidget {
  const ShamelApp({super.key, required this.backendReady});

  final bool backendReady;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: ProductionConfig.appName,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: AppTheme.darkTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: ThemeMode.dark,
      initialRoute: backendReady ? AppRoutes.splash : AppRoutes.productionSetup,
      onGenerateRoute: AppRoutes.onGenerateRoute,
      builder: (context, child) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: OfflineBanner(child: child ?? const SizedBox.shrink()),
        );
      },
    );
  }
}
