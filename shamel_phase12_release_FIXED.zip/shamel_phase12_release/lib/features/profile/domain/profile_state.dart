import '../../../core/utils/ui_state.dart';

class ProfileState {
  const ProfileState({this.viewState = ViewState.success, this.message});

  final ViewState viewState;
  final String? message;

  ProfileState copyWith({ViewState? viewState, String? message}) {
    return ProfileState(
      viewState: viewState ?? this.viewState,
      message: message ?? this.message,
    );
  }
}
