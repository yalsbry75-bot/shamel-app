import '../../../core/errors/app_exception.dart';

class ProfileService {
  const ProfileService();

  Future<void> load() {
    throw const AppException('Profile service is prepared but disabled until its dedicated phase.');
  }
}
