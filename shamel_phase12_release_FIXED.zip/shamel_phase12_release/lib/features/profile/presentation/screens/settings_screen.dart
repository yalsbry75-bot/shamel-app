import 'package:flutter/material.dart';

import '../../../../core/widgets/glass_container.dart';
import '../../../../core/widgets/premium_app_bar.dart';
import '../../../../core/widgets/premium_scaffold.dart';
import '../../../../routes/app_routes.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _notificationsEnabled = true;

  @override
  Widget build(BuildContext context) {
    return PremiumScaffold(
      appBar: const PremiumAppBar(title: 'الإعدادات', showBack: true),
      child: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          _section(
            title: 'التطبيق',
            children: [
              _tile(icon: Icons.dark_mode_outlined, title: 'الوضع الليلي', subtitle: 'مفعل دائمًا في الإصدار الحالي', trailing: const Icon(Icons.lock_outline, color: Colors.white54)),
              _tile(icon: Icons.language_outlined, title: 'اللغة', subtitle: 'العربية الآن، الإنجليزية جاهزة لاحقًا'),
              _tile(
                icon: Icons.notifications_active_outlined,
                title: 'الإشعارات',
                subtitle: _notificationsEnabled ? 'مفعلة' : 'موقفة',
                trailing: Switch.adaptive(
                  value: _notificationsEnabled,
                  onChanged: (value) => setState(() => _notificationsEnabled = value),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          _section(
            title: 'الأمان والخصوصية',
            children: [
              _tile(icon: Icons.privacy_tip_outlined, title: 'سياسة الخصوصية', subtitle: 'سيتم ربطها بصفحة قانونية عند النشر'),
              _tile(icon: Icons.description_outlined, title: 'الشروط والأحكام', subtitle: 'إطار جاهز للمراجعة القانونية'),
              _tile(icon: Icons.security_outlined, title: 'حماية الحساب', subtitle: 'OTP، جلسة آمنة، وصلاحيات حسب الدور'),
            ],
          ),
          const SizedBox(height: 16),
          _section(
            title: 'الدعم',
            children: [
              _tile(
                icon: Icons.support_agent_outlined,
                title: 'التواصل مع الدعم',
                subtitle: 'فتح صفحة الدعم داخل التطبيق',
                onTap: () => Navigator.of(context).pushNamed(AppRoutes.support),
              ),
              _tile(icon: Icons.info_outline, title: 'إصدار التطبيق', subtitle: 'Phase 10 — Production Optimization'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _section({required String title, required List<Widget> children}) {
    return GlassContainer(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          ...children,
        ],
      ),
    );
  }

  Widget _tile({required IconData icon, required String title, required String subtitle, Widget? trailing, VoidCallback? onTap}) {
    return ListTile(
      onTap: onTap,
      contentPadding: EdgeInsets.zero,
      leading: Icon(icon, color: Colors.white70),
      title: Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
      subtitle: Text(subtitle, style: const TextStyle(color: Colors.white54, height: 1.5)),
      trailing: trailing ?? const Icon(Icons.chevron_left_rounded, color: Colors.white38),
    );
  }
}
