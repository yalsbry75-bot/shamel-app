import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/utils/ui_state.dart';
import '../../../../core/utils/validators.dart';
import '../../../../core/widgets/empty_state.dart';
import '../../../../core/widgets/glass_container.dart';
import '../../../../core/widgets/premium_app_bar.dart';
import '../../../../core/widgets/premium_scaffold.dart';
import '../../../../core/widgets/shamel_button.dart';
import '../../../../core/widgets/shamel_text_field.dart';
import '../../../../routes/app_routes.dart';
import '../../../auth/domain/account_type.dart';
import '../../../auth/presentation/controllers/auth_controller.dart';

class ProfileScreen extends ConsumerStatefulWidget {
  const ProfileScreen({super.key, this.isEmbedded = false});

  final bool isEmbedded;

  @override
  ConsumerState<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends ConsumerState<ProfileScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _governorateController = TextEditingController();
  final _districtController = TextEditingController();
  bool _hydrated = false;

  @override
  void dispose() {
    _nameController.dispose();
    _governorateController.dispose();
    _districtController.dispose();
    super.dispose();
  }

  void _hydrate() {
    if (_hydrated) return;
    final user = ref.read(authControllerProvider).user;
    if (user == null) return;
    _nameController.text = user.name;
    _governorateController.text = user.governorate;
    _districtController.text = user.district;
    _hydrated = true;
  }

  @override
  Widget build(BuildContext context) {
    _hydrate();
    final auth = ref.watch(authControllerProvider);
    final user = auth.user;
    final isLoading = auth.viewState == ViewState.loading;

    ref.listen(authControllerProvider, (previous, next) {
      final message = next.errorMessage ?? next.message;
      if (message != null && message != previous?.message && message != previous?.errorMessage) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
      }
    });

    if (user == null) {
      return PremiumScaffold(
        appBar: widget.isEmbedded ? const PremiumAppBar(title: 'حسابي') : const PremiumAppBar(title: 'حسابي', showBack: true),
        child: const Center(
          child: EmptyState(
            title: 'لا توجد جلسة نشطة',
            message: 'سجّل الدخول للوصول إلى بيانات الملف الشخصي.',
            icon: Icons.lock_outline_rounded,
          ),
        ),
      );
    }

    return PremiumScaffold(
      appBar: widget.isEmbedded ? const PremiumAppBar(title: 'حسابي') : const PremiumAppBar(title: 'حسابي', showBack: true),
      child: Form(
        key: _formKey,
        child: ListView(
          children: [
            GlassContainer(
              child: Row(
                children: [
                  const CircleAvatar(
                    radius: 34,
                    backgroundColor: AppColors.surfaceHigh,
                    child: Icon(Icons.person_outline_rounded, color: AppColors.textPrimary, size: 32),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(user.name.isEmpty ? 'مستخدم شامل' : user.name, style: AppTextStyles.section),
                        const SizedBox(height: 4),
                        Text(user.phoneNumber, style: AppTextStyles.caption),
                        const SizedBox(height: 6),
                        _StatusPill(
                          label: user.profileCompleted ? 'الملف مكتمل' : 'الملف غير مكتمل',
                          isSuccess: user.profileCompleted,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            GlassContainer(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('بيانات الحساب', style: AppTextStyles.section),
                  const SizedBox(height: 14),
                  ShamelTextField(
                    controller: _nameController,
                    hintText: 'الاسم',
                    prefixIcon: Icons.badge_outlined,
                    textInputAction: TextInputAction.next,
                    validator: (value) => Validators.requiredText(value, 'الاسم'),
                  ),
                  const SizedBox(height: 12),
                  ShamelTextField(
                    initialValue: user.phoneNumber,
                    hintText: 'رقم الهاتف',
                    prefixIcon: Icons.phone_iphone_rounded,
                    readOnly: true,
                  ),
                  const SizedBox(height: 12),
                  ShamelTextField(
                    initialValue: user.userType?.label ?? 'غير محدد',
                    hintText: 'نوع الحساب',
                    prefixIcon: Icons.verified_user_outlined,
                    readOnly: true,
                  ),
                  const SizedBox(height: 12),
                  ShamelTextField(
                    controller: _governorateController,
                    hintText: 'المحافظة',
                    prefixIcon: Icons.location_city_outlined,
                    textInputAction: TextInputAction.next,
                    validator: (value) => Validators.requiredText(value, 'المحافظة'),
                  ),
                  const SizedBox(height: 12),
                  ShamelTextField(
                    controller: _districtController,
                    hintText: 'المديرية',
                    prefixIcon: Icons.place_outlined,
                    textInputAction: TextInputAction.done,
                    validator: (value) => Validators.requiredText(value, 'المديرية'),
                  ),
                  const SizedBox(height: 18),
                  ShamelButton.primary(
                    label: 'حفظ البيانات',
                    isLoading: isLoading,
                    onPressed: isLoading
                        ? null
                        : () async {
                            if (!(_formKey.currentState?.validate() ?? false)) return;
                            await ref.read(authControllerProvider.notifier).updateProfile(
                                  name: _nameController.text,
                                  governorate: _governorateController.text,
                                  district: _districtController.text,
                                );
                          },
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            _ProfileTile(label: 'الإشعارات', icon: Icons.notifications_none_rounded, route: AppRoutes.notifications),
            _ProfileTile(label: 'الإعلانات', icon: Icons.campaign_outlined, route: AppRoutes.ads),
            _ProfileTile(label: 'الإعدادات', icon: Icons.settings_outlined, route: AppRoutes.settings),
            _ProfileTile(label: 'الدعم', icon: Icons.support_agent_rounded, route: AppRoutes.support),
            const SizedBox(height: 8),
            ShamelButton.secondary(
              label: 'تسجيل الخروج',
              icon: Icons.logout_rounded,
              onPressed: isLoading
                  ? null
                  : () async {
                      await ref.read(authControllerProvider.notifier).signOut();
                      if (context.mounted) {
                        Navigator.of(context).pushNamedAndRemoveUntil(AppRoutes.login, (_) => false);
                      }
                    },
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}

class _StatusPill extends StatelessWidget {
  const _StatusPill({required this.label, required this.isSuccess});

  final String label;
  final bool isSuccess;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: (isSuccess ? AppColors.success : AppColors.warning).withOpacity(0.14),
        borderRadius: BorderRadius.circular(99),
        border: Border.all(color: (isSuccess ? AppColors.success : AppColors.warning).withOpacity(0.5)),
      ),
      child: Text(
        label,
        style: AppTextStyles.caption.copyWith(color: isSuccess ? AppColors.success : AppColors.warning),
      ),
    );
  }
}

class _ProfileTile extends StatelessWidget {
  const _ProfileTile({required this.label, required this.icon, required this.route});

  final String label;
  final IconData icon;
  final String route;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: GlassContainer(
        onTap: () => Navigator.of(context).pushNamed(route),
        child: Row(
          children: [
            Icon(icon, color: AppColors.primary),
            const SizedBox(width: 12),
            Expanded(child: Text(label, style: AppTextStyles.body)),
            const Icon(Icons.arrow_forward_ios_rounded, size: 16, color: AppColors.textSecondary),
          ],
        ),
      ),
    );
  }
}
