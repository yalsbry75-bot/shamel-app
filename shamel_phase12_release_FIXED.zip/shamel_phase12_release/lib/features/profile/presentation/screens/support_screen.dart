import 'package:flutter/material.dart';

import '../../../../core/widgets/empty_state.dart';
import '../../../../core/widgets/premium_app_bar.dart';
import '../../../../core/widgets/premium_scaffold.dart';

class SupportScreen extends StatelessWidget {
  const SupportScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const PremiumScaffold(
      appBar: PremiumAppBar(title: 'الدعم', showBack: true),
      child: Center(
        child: EmptyState(
          title: 'الدعم',
          message: 'واجهة الدعم جاهزة للربط لاحقًا.',
          icon: Icons.support_agent_rounded,
        ),
      ),
    );
  }
}
