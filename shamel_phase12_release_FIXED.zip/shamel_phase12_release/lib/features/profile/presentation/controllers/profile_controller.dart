import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../domain/profile_state.dart';

final profileControllerProvider = StateNotifierProvider<ProfileController, ProfileState>((ref) {
  return ProfileController();
});

class ProfileController extends StateNotifier<ProfileState> {
  ProfileController() : super(const ProfileState());
}
