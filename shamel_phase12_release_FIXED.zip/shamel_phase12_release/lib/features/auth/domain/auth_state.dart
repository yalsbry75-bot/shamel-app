import '../../../core/utils/ui_state.dart';
import 'account_type.dart';
import 'user_model.dart';

class AuthState {
  const AuthState({
    this.phone = '',
    this.otp = '',
    this.accountType,
    this.user,
    this.viewState = ViewState.initial,
    this.message,
    this.errorMessage,
    this.sessionChecked = false,
    this.remainingAttempts = 5,
    this.canResendAt,
  });

  final String phone;
  final String otp;
  final AccountType? accountType;
  final UserModel? user;
  final ViewState viewState;
  final String? message;
  final String? errorMessage;
  final bool sessionChecked;
  final int remainingAttempts;
  final DateTime? canResendAt;

  bool get isLoading => viewState == ViewState.loading;
  bool get isAuthenticated => user != null && user!.isVerified && !user!.isBlocked;
  bool get needsAccountType => isAuthenticated && user!.userType == null;
  bool get hasCompletedAccount => isAuthenticated && user!.userType != null;

  AuthState copyWith({
    String? phone,
    String? otp,
    AccountType? accountType,
    bool clearAccountType = false,
    UserModel? user,
    bool clearUser = false,
    ViewState? viewState,
    String? message,
    bool clearMessage = false,
    String? errorMessage,
    bool clearError = false,
    bool? sessionChecked,
    int? remainingAttempts,
    DateTime? canResendAt,
    bool clearCanResendAt = false,
  }) {
    return AuthState(
      phone: phone ?? this.phone,
      otp: otp ?? this.otp,
      accountType: clearAccountType ? null : accountType ?? this.accountType,
      user: clearUser ? null : user ?? this.user,
      viewState: viewState ?? this.viewState,
      message: clearMessage ? null : message ?? this.message,
      errorMessage: clearError ? null : errorMessage ?? this.errorMessage,
      sessionChecked: sessionChecked ?? this.sessionChecked,
      remainingAttempts: remainingAttempts ?? this.remainingAttempts,
      canResendAt: clearCanResendAt ? null : canResendAt ?? this.canResendAt,
    );
  }

  factory AuthState.signedOut() {
    return const AuthState(sessionChecked: true, viewState: ViewState.success);
  }
}
