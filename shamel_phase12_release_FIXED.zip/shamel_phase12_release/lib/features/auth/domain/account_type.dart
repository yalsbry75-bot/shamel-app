enum AccountType { customer, provider }

extension AccountTypeX on AccountType {
  String get value {
    switch (this) {
      case AccountType.customer:
        return 'customer';
      case AccountType.provider:
        return 'provider';
    }
  }

  String get label {
    switch (this) {
      case AccountType.customer:
        return 'عميل';
      case AccountType.provider:
        return 'مقدم خدمة';
    }
  }

  static AccountType fromValue(String value) {
    switch (value) {
      case 'provider':
        return AccountType.provider;
      case 'customer':
      default:
        return AccountType.customer;
    }
  }
}
