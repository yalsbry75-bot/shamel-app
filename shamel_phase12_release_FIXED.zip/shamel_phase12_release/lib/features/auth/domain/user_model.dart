import 'account_type.dart';

class UserModel {
  const UserModel({
    required this.userId,
    required this.phoneNumber,
    required this.createdAt,
    this.name = '',
    this.userType,
    this.governorate = '',
    this.district = '',
    this.isVerified = false,
    this.isBlocked = false,
    this.profileCompleted = false,
  });

  final String userId;
  final String phoneNumber;
  final String name;
  final AccountType? userType;
  final String governorate;
  final String district;
  final DateTime createdAt;
  final bool isVerified;
  final bool isBlocked;
  final bool profileCompleted;

  bool get hasUserType => userType != null;

  factory UserModel.fromJson(Map<String, dynamic> json) {
    final rawType = json['userType'] as String?;
    return UserModel(
      userId: json['userId'] as String,
      phoneNumber: json['phoneNumber'] as String,
      name: json['name'] as String? ?? '',
      userType: rawType == null || rawType.isEmpty ? null : AccountTypeX.fromValue(rawType),
      governorate: json['governorate'] as String? ?? '',
      district: json['district'] as String? ?? '',
      createdAt: DateTime.parse(json['createdAt'] as String),
      isVerified: json['isVerified'] as bool? ?? false,
      isBlocked: json['isBlocked'] as bool? ?? false,
      profileCompleted: json['profileCompleted'] as bool? ?? false,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'userId': userId,
      'phoneNumber': phoneNumber,
      'name': name,
      'userType': userType?.value,
      'governorate': governorate,
      'district': district,
      'createdAt': createdAt.toIso8601String(),
      'isVerified': isVerified,
      'isBlocked': isBlocked,
      'profileCompleted': profileCompleted,
    };
  }

  UserModel copyWith({
    String? userId,
    String? phoneNumber,
    String? name,
    AccountType? userType,
    bool clearUserType = false,
    String? governorate,
    String? district,
    DateTime? createdAt,
    bool? isVerified,
    bool? isBlocked,
    bool? profileCompleted,
  }) {
    return UserModel(
      userId: userId ?? this.userId,
      phoneNumber: phoneNumber ?? this.phoneNumber,
      name: name ?? this.name,
      userType: clearUserType ? null : userType ?? this.userType,
      governorate: governorate ?? this.governorate,
      district: district ?? this.district,
      createdAt: createdAt ?? this.createdAt,
      isVerified: isVerified ?? this.isVerified,
      isBlocked: isBlocked ?? this.isBlocked,
      profileCompleted: profileCompleted ?? this.profileCompleted,
    );
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        other is UserModel &&
            runtimeType == other.runtimeType &&
            userId == other.userId &&
            phoneNumber == other.phoneNumber &&
            name == other.name &&
            userType == other.userType &&
            governorate == other.governorate &&
            district == other.district &&
            createdAt == other.createdAt &&
            isVerified == other.isVerified &&
            isBlocked == other.isBlocked &&
            profileCompleted == other.profileCompleted;
  }

  @override
  int get hashCode => Object.hash(
        userId,
        phoneNumber,
        name,
        userType,
        governorate,
        district,
        createdAt,
        isVerified,
        isBlocked,
        profileCompleted,
      );
}
