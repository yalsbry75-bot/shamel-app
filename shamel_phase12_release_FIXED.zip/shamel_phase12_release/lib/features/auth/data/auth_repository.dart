import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../domain/account_type.dart';
import '../domain/user_model.dart';
import 'auth_service.dart';

final authServiceProvider = Provider<AuthService>((ref) => FirebaseAuthService());

final authRepositoryProvider = Provider<AuthRepository>((ref) {
  return AuthRepository(ref.watch(authServiceProvider));
});

class AuthRepository {
  const AuthRepository(this._service);

  final AuthService _service;

  Future<OtpRequestResult> requestOtp(String phoneNumber) {
    return _service.requestOtp(phoneNumber);
  }

  Future<UserModel> verifyOtp({required String phoneNumber, required String otp}) {
    return _service.verifyOtp(phoneNumber: phoneNumber, otp: otp);
  }

  Future<UserModel?> getCurrentUser() {
    return _service.getCurrentUser();
  }

  Future<UserModel> selectAccountType({required UserModel user, required AccountType type}) async {
    if (user.userType != null && user.userType != type) {
      return user;
    }
    final updated = user.copyWith(userType: type, profileCompleted: _isProfileComplete(user.copyWith(userType: type)));
    await _service.saveUser(updated);
    await _service.saveSession(updated);
    return updated;
  }

  Future<UserModel> updateProfile({
    required UserModel user,
    required String name,
    required String governorate,
    required String district,
  }) async {
    final updated = user.copyWith(
      name: name.trim(),
      governorate: governorate.trim(),
      district: district.trim(),
      profileCompleted: name.trim().isNotEmpty && governorate.trim().isNotEmpty && district.trim().isNotEmpty && user.userType != null,
    );
    await _service.saveUser(updated);
    await _service.saveSession(updated);
    return updated;
  }

  Future<void> signOut() {
    return _service.clearSession();
  }

  bool _isProfileComplete(UserModel user) {
    return user.userType != null && user.name.trim().isNotEmpty && user.governorate.trim().isNotEmpty && user.district.trim().isNotEmpty;
  }
}
