import 'dart:convert';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../domain/user_model.dart';

class SecureSessionStorage {
  SecureSessionStorage({FlutterSecureStorage? storage}) : _storage = storage ?? _defaultStorage;

  static const FlutterSecureStorage _defaultStorage = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
    iOptions: IOSOptions(accessibility: KeychainAccessibility.first_unlock_this_device),
  );

  static const String _usersKey = 'shamel_users_v1';
  static const String _currentUserKey = 'shamel_current_user_id_v1';
  static const String _sessionStatusKey = 'shamel_session_status_v1';
  static const String _currentUserTypeKey = 'shamel_current_user_type_v1';

  final FlutterSecureStorage _storage;

  Future<List<UserModel>> readUsers() async {
    final raw = await _storage.read(key: _usersKey);
    if (raw == null || raw.trim().isEmpty) return const [];
    final decoded = jsonDecode(raw) as List<dynamic>;
    return decoded
        .whereType<Map<String, dynamic>>()
        .map(UserModel.fromJson)
        .toList(growable: false);
  }

  Future<void> saveUsers(List<UserModel> users) async {
    final encoded = jsonEncode(users.map((user) => user.toJson()).toList());
    await _storage.write(key: _usersKey, value: encoded);
  }

  Future<UserModel?> readCurrentUser() async {
    final userId = await _storage.read(key: _currentUserKey);
    if (userId == null || userId.isEmpty) return null;
    final users = await readUsers();
    for (final user in users) {
      if (user.userId == userId) return user;
    }
    return null;
  }

  Future<void> saveSession(UserModel user) async {
    await _storage.write(key: _currentUserKey, value: user.userId);
    await _storage.write(key: _sessionStatusKey, value: 'active');
    await _storage.write(key: _currentUserTypeKey, value: user.userType?.value ?? '');
  }

  Future<bool> hasActiveSession() async {
    final status = await _storage.read(key: _sessionStatusKey);
    final userId = await _storage.read(key: _currentUserKey);
    return status == 'active' && userId != null && userId.isNotEmpty;
  }

  Future<void> clearSession() async {
    await _storage.delete(key: _currentUserKey);
    await _storage.delete(key: _sessionStatusKey);
    await _storage.delete(key: _currentUserTypeKey);
  }

  Future<void> resetAllLocalAuthData() async {
    await _storage.delete(key: _usersKey);
    await clearSession();
  }
}
