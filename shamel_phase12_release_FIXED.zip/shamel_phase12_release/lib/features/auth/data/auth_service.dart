import 'dart:async';

import '../../../core/constants/app_constants.dart';
import '../../../core/errors/app_exception.dart';
import '../../../core/monitoring/app_monitoring.dart';
import '../../../core/security/rate_limiter_service.dart';
import '../../../core/validators/production_validators.dart';
import '../domain/user_model.dart';
import 'secure_session_storage.dart';

import '../../../core/notifications/push_notification_service.dart';
import '../../../core/database/firestore_json.dart';
import '../../../core/database/firestore_collections.dart';
import 'package:firebase_auth/firebase_auth.dart' as fb;
import 'package:cloud_firestore/cloud_firestore.dart';
class OtpRequestResult {
  const OtpRequestResult({
    required this.phoneNumber,
    required this.canResendAt,
    required this.remainingAttempts,
    required this.maskedPhone,
  });

  final String phoneNumber;
  final DateTime canResendAt;
  final int remainingAttempts;
  final String maskedPhone;
}

abstract class AuthService {
  Future<OtpRequestResult> requestOtp(String phoneNumber);
  Future<UserModel> verifyOtp({required String phoneNumber, required String otp});
  Future<UserModel?> getCurrentUser();
  Future<UserModel> saveUser(UserModel user);
  Future<void> saveSession(UserModel user);
  Future<void> clearSession();
}

class FirebaseAuthService implements AuthService {
  FirebaseAuthService({
    fb.FirebaseAuth? auth,
    FirebaseFirestore? firestore,
    SecureSessionStorage? storage,
    PushNotificationService? pushNotifications,
    RateLimiterService? rateLimiter,
  })  : _auth = auth ?? fb.FirebaseAuth.instance,
        _firestore = firestore ?? FirebaseFirestore.instance,
        _storage = storage ?? SecureSessionStorage(),
        _pushNotifications = pushNotifications ?? PushNotificationService(),
        _rateLimiter = rateLimiter ?? const RateLimiterService();

  final fb.FirebaseAuth _auth;
  final FirebaseFirestore _firestore;
  final SecureSessionStorage _storage;
  final PushNotificationService _pushNotifications;
  final RateLimiterService _rateLimiter;
  final Map<String, String> _verificationIds = <String, String>{};
  final Map<String, int> _resendTokens = <String, int>{};
  final Map<String, int> _attemptsByPhone = <String, int>{};
  final Map<String, DateTime> _lastOtpRequestByPhone = <String, DateTime>{};

  @override
  Future<OtpRequestResult> requestOtp(String phoneNumber) async {
    final normalizedPhone = _normalizePhone(phoneNumber);
    await _rateLimiter.check(key: 'otp_$normalizedPhone', rule: RateLimiterService.otpRule, message: 'محاولات كثيرة لإرسال رمز التحقق. حاول لاحقًا.');
    final now = DateTime.now();
    final lastRequest = _lastOtpRequestByPhone[normalizedPhone];
    if (lastRequest != null) {
      final nextAllowed = lastRequest.add(const Duration(seconds: AppConstants.otpTimeoutSeconds));
      if (now.isBefore(nextAllowed)) {
        final remaining = nextAllowed.difference(now).inSeconds;
        throw AppException('يمكن إعادة إرسال الرمز بعد $remaining ثانية.', code: 'OTP_RATE_LIMIT');
      }
    }

    final completer = Completer<void>();
    await _auth.verifyPhoneNumber(
      phoneNumber: normalizedPhone,
      timeout: const Duration(seconds: AppConstants.otpTimeoutSeconds),
      forceResendingToken: _resendTokens[normalizedPhone],
      verificationCompleted: (credential) async {
        // Keep manual OTP UX stable; Android may auto-resolve later through verifyOtp if needed.
      },
      verificationFailed: (error) {
        if (!completer.isCompleted) completer.completeError(_mapAuthError(error));
      },
      codeSent: (verificationId, resendToken) {
        _verificationIds[normalizedPhone] = verificationId;
        if (resendToken != null) _resendTokens[normalizedPhone] = resendToken;
        _lastOtpRequestByPhone[normalizedPhone] = now;
        _attemptsByPhone[normalizedPhone] = 0;
        if (!completer.isCompleted) completer.complete();
      },
      codeAutoRetrievalTimeout: (verificationId) {
        _verificationIds[normalizedPhone] = verificationId;
      },
    );

    await completer.future.timeout(const Duration(seconds: 35));
    return OtpRequestResult(
      phoneNumber: normalizedPhone,
      canResendAt: now.add(const Duration(seconds: AppConstants.otpTimeoutSeconds)),
      remainingAttempts: AppConstants.maxOtpAttempts,
      maskedPhone: _maskPhone(normalizedPhone),
    );
  }

  @override
  Future<UserModel> verifyOtp({required String phoneNumber, required String otp}) async {
    final normalizedPhone = _normalizePhone(phoneNumber);
    final attempts = _attemptsByPhone[normalizedPhone] ?? 0;
    if (attempts >= AppConstants.maxOtpAttempts) {
      throw const AppException('تم تجاوز عدد محاولات التحقق. أعد إرسال الرمز وحاول مرة أخرى.', code: 'OTP_ATTEMPTS_EXCEEDED');
    }
    final verificationId = _verificationIds[normalizedPhone];
    if (verificationId == null || verificationId.isEmpty) {
      throw const AppException('انتهت صلاحية رمز التحقق. أعد إرسال الرمز.', code: 'OTP_SESSION_EXPIRED');
    }

    try {
      final credential = fb.PhoneAuthProvider.credential(verificationId: verificationId, smsCode: otp);
      final result = await _auth.signInWithCredential(credential);
      final firebaseUser = result.user;
      if (firebaseUser == null) {
        throw const AppException('تعذر إكمال تسجيل الدخول.', code: 'AUTH_USER_MISSING');
      }
      final user = await _ensureUserDocument(firebaseUser, normalizedPhone);
      if (user.isBlocked) {
        await _auth.signOut();
        throw const AppException('لا يمكن الدخول لهذا الحساب حاليًا.', code: 'ACCOUNT_BLOCKED');
      }
      await saveSession(user);
      await AppMonitoring.setUser(userId: user.userId, role: user.userType?.value);
      await _pushNotifications.registerDeviceToken(user.userId);
      _attemptsByPhone.remove(normalizedPhone);
      return user;
    } on fb.FirebaseAuthException catch (error) {
      _attemptsByPhone[normalizedPhone] = attempts + 1;
      throw _mapAuthError(error);
    }
  }

  @override
  Future<UserModel?> getCurrentUser() async {
    final firebaseUser = _auth.currentUser;
    if (firebaseUser == null) return null;
    final doc = await _firestore.collection(FirestoreCollections.users).doc(firebaseUser.uid).get();
    if (!doc.exists || doc.data() == null) return null;
    final user = UserModel.fromJson(FirestoreJson.normalize(doc.data()!));
    await saveSession(user);
    return user;
  }

  @override
  Future<UserModel> saveUser(UserModel user) async {
    await _firestore.collection(FirestoreCollections.users).doc(user.userId).set(
          FirestoreJson.withServerAudit(user.toJson(), isCreate: true),
          SetOptions(merge: true),
        );
    return user;
  }

  @override
  Future<void> saveSession(UserModel user) => _storage.saveSession(user);

  @override
  Future<void> clearSession() async {
    await _auth.signOut();
    await _storage.clearSession();
  }

  Future<UserModel> _ensureUserDocument(fb.User firebaseUser, String normalizedPhone) async {
    final ref = _firestore.collection(FirestoreCollections.users).doc(firebaseUser.uid);
    final doc = await ref.get();
    if (doc.exists && doc.data() != null) {
      final user = UserModel.fromJson(FirestoreJson.normalize(doc.data()!));
      final verified = user.copyWith(isVerified: true, phoneNumber: normalizedPhone);
      await saveUser(verified);
      return verified;
    }

    final user = UserModel(
      userId: firebaseUser.uid,
      phoneNumber: normalizedPhone,
      createdAt: DateTime.now(),
      isVerified: true,
    );
    await saveUser(user);
    return user;
  }

  AppException _mapAuthError(fb.FirebaseAuthException error) {
    switch (error.code) {
      case 'invalid-phone-number':
        return const AppException('رقم الهاتف غير صحيح.', code: 'INVALID_PHONE');
      case 'invalid-verification-code':
        return const AppException('رمز التحقق غير صحيح.', code: 'INVALID_OTP');
      case 'quota-exceeded':
        return const AppException('تم تجاوز حد إرسال الرسائل. حاول لاحقًا.', code: 'OTP_QUOTA_EXCEEDED');
      case 'network-request-failed':
        return const AppException('تعذر الاتصال بالإنترنت. حاول مرة أخرى.', code: 'NETWORK_FAILED');
      case 'too-many-requests':
        return const AppException('محاولات كثيرة خلال وقت قصير. حاول لاحقًا.', code: 'TOO_MANY_REQUESTS');
      default:
        return const AppException('تعذر إكمال المصادقة. حاول مرة أخرى.', code: 'AUTH_FAILED');
    }
  }

  String _normalizePhone(String phone) {
    return ProductionValidators.yemeniPhone(phone);
  }

  String _maskPhone(String phone) {
    if (phone.length <= 6) return phone;
    final suffix = phone.substring(phone.length - 3);
    return '${AppConstants.defaultCountryCode} ••• ••• $suffix';
  }
}
