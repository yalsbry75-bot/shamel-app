import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../../../core/constants/app_constants.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_radius.dart';
import '../../../../core/theme/app_text_styles.dart';

class OtpCodeField extends StatelessWidget {
  const OtpCodeField({
    super.key,
    required this.controller,
    required this.onChanged,
    this.validator,
    this.enabled = true,
  });

  final TextEditingController controller;
  final ValueChanged<String> onChanged;
  final String? Function(String?)? validator;
  final bool enabled;

  @override
  Widget build(BuildContext context) {
    return FormField<String>(
      validator: (_) => validator?.call(controller.text),
      builder: (field) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              alignment: Alignment.center,
              children: [
                Row(
                  children: List.generate(AppConstants.otpLength, (index) {
                    final value = controller.text.length > index ? controller.text[index] : '';
                    final isFocused = controller.text.length == index;
                    return Expanded(
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 180),
                        margin: EdgeInsetsDirectional.only(end: index == AppConstants.otpLength - 1 ? 0 : 8),
                        height: 58,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: AppColors.surface.withOpacity(0.72),
                          borderRadius: BorderRadius.circular(AppRadius.md),
                          border: Border.all(
                            color: field.hasError
                                ? AppColors.error
                                : isFocused
                                    ? AppColors.primary
                                    : AppColors.border,
                            width: isFocused ? 1.5 : 1,
                          ),
                        ),
                        child: Text(
                          value,
                          style: AppTextStyles.title.copyWith(fontWeight: FontWeight.w900),
                        ),
                      ),
                    );
                  }),
                ),
                TextField(
                  controller: controller,
                  enabled: enabled,
                  autofocus: true,
                  keyboardType: TextInputType.number,
                  textInputAction: TextInputAction.done,
                  maxLength: AppConstants.otpLength,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  onChanged: (value) {
                    field.didChange(value);
                    onChanged(value);
                  },
                  style: const TextStyle(color: Colors.transparent, fontSize: 1),
                  cursorColor: Colors.transparent,
                  decoration: const InputDecoration(
                    counterText: '',
                    border: InputBorder.none,
                    enabledBorder: InputBorder.none,
                    focusedBorder: InputBorder.none,
                    errorBorder: InputBorder.none,
                    focusedErrorBorder: InputBorder.none,
                    fillColor: Colors.transparent,
                    contentPadding: EdgeInsets.zero,
                  ),
                ),
              ],
            ),
            if (field.hasError) ...[
              const SizedBox(height: 8),
              Text(field.errorText ?? '', style: AppTextStyles.caption.copyWith(color: AppColors.error)),
            ],
          ],
        );
      },
    );
  }
}
