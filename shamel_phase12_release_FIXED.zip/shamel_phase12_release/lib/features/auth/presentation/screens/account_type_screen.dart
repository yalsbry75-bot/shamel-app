import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/utils/ui_state.dart';
import '../../../../core/widgets/glass_container.dart';
import '../../../../core/widgets/premium_app_bar.dart';
import '../../../../core/widgets/premium_scaffold.dart';
import '../../../../core/widgets/shamel_button.dart';
import '../../../../routes/app_routes.dart';
import '../../../provider/presentation/controllers/provider_controller.dart';
import '../../domain/account_type.dart';
import '../controllers/auth_controller.dart';

class AccountTypeScreen extends ConsumerWidget {
  const AccountTypeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final auth = ref.watch(authControllerProvider);
    final isLoading = auth.viewState == ViewState.loading;

    ref.listen(authControllerProvider, (previous, next) {
      final message = next.errorMessage ?? next.message;
      if (message != null && message != previous?.message && message != previous?.errorMessage) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
      }
    });

    return PremiumScaffold(
      appBar: const PremiumAppBar(title: 'نوع الحساب', showBack: false),
      child: ListView(
        children: [
          const SizedBox(height: 30),
          Text('اختر نوع حسابك', style: AppTextStyles.display),
          const SizedBox(height: 10),
          Text('اختر المسار المناسب. لا يمكن تغيير نوع الحساب بعد الحفظ إلا بصلاحية خاصة.', style: AppTextStyles.caption),
          const SizedBox(height: 28),
          _AccountTypeCard(
            icon: Icons.person_outline_rounded,
            title: 'عميل',
            message: 'استعراض الخدمات، حفظ المفضلة، وإنشاء الطلبات لاحقًا.',
            isLoading: isLoading,
            onTap: () async {
              final success = await ref.read(authControllerProvider.notifier).selectAccountType(AccountType.customer);
              if (success && context.mounted) {
                Navigator.of(context).pushNamedAndRemoveUntil(AppRoutes.customerShell, (_) => false);
              }
            },
          ),
          const SizedBox(height: 14),
          _AccountTypeCard(
            icon: Icons.business_center_outlined,
            title: 'مقدم خدمة',
            message: 'إدارة لوحة الأعمال والخدمات والاشتراك في المراحل القادمة.',
            isLoading: isLoading,
            onTap: () async {
              final success = await ref.read(authControllerProvider.notifier).selectAccountType(AccountType.provider);
              final user = ref.read(authControllerProvider).user;
              if (success && user != null) {
                await ref.read(providerControllerProvider.notifier).ensureProviderProfile(user);
              }
              if (success && context.mounted) {
                Navigator.of(context).pushNamedAndRemoveUntil(AppRoutes.providerShell, (_) => false);
              }
            },
          ),
          const SizedBox(height: 24),
          if (isLoading) const LinearProgressIndicator(minHeight: 2),
          const SizedBox(height: 24),
          ShamelButton.secondary(
            label: 'تسجيل الخروج',
            icon: Icons.logout_rounded,
            onPressed: isLoading
                ? null
                : () async {
                    await ref.read(authControllerProvider.notifier).signOut();
                    if (context.mounted) {
                      Navigator.of(context).pushNamedAndRemoveUntil(AppRoutes.login, (_) => false);
                    }
                  },
          ),
        ],
      ),
    );
  }
}

class _AccountTypeCard extends StatelessWidget {
  const _AccountTypeCard({
    required this.icon,
    required this.title,
    required this.message,
    required this.onTap,
    required this.isLoading,
  });

  final IconData icon;
  final String title;
  final String message;
  final VoidCallback onTap;
  final bool isLoading;

  @override
  Widget build(BuildContext context) {
    return GlassContainer(
      onTap: isLoading ? null : onTap,
      child: Row(
        children: [
          Container(
            width: 54,
            height: 54,
            decoration: BoxDecoration(
              color: AppColors.primary.withOpacity(0.16),
              borderRadius: BorderRadius.circular(18),
            ),
            child: Icon(icon, color: AppColors.primary),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: AppTextStyles.section),
                const SizedBox(height: 4),
                Text(message, style: AppTextStyles.caption),
              ],
            ),
          ),
          const Icon(Icons.arrow_forward_ios_rounded, size: 18, color: AppColors.textSecondary),
        ],
      ),
    );
  }
}
