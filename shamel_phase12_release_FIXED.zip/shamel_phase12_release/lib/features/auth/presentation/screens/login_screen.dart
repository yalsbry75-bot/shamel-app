import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/config/app_config.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/utils/ui_state.dart';
import '../../../../core/utils/validators.dart';
import '../../../../core/widgets/glass_container.dart';
import '../../../../core/widgets/premium_scaffold.dart';
import '../../../../core/widgets/shamel_button.dart';
import '../../../../core/widgets/shamel_text_field.dart';
import '../../../../routes/app_routes.dart';
import '../controllers/auth_controller.dart';

class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({super.key});

  @override
  ConsumerState<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends ConsumerState<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _phoneController = TextEditingController();

  @override
  void dispose() {
    _phoneController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final auth = ref.watch(authControllerProvider);
    final isLoading = auth.viewState == ViewState.loading;

    ref.listen(authControllerProvider, (previous, next) {
      final message = next.errorMessage ?? next.message;
      if (message != null && message != previous?.message && message != previous?.errorMessage) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
      }
    });

    return PremiumScaffold(
      child: Form(
        key: _formKey,
        child: ListView(
          children: [
            const SizedBox(height: 74),
            Center(
              child: Container(
                width: 86,
                height: 86,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(colors: [AppColors.primary, Color(0xFF53A7FF)]),
                ),
                child: const Center(
                  child: Text('ش', style: TextStyle(fontSize: 42, fontWeight: FontWeight.w900)),
                ),
              ),
            ),
            const SizedBox(height: 24),
            Text('أدخل رقم هاتفك', style: AppTextStyles.display, textAlign: TextAlign.center),
            const SizedBox(height: 8),
            Text(AppConfig.appTagline, style: AppTextStyles.caption, textAlign: TextAlign.center),
            const SizedBox(height: 32),
            GlassContainer(
              child: Row(
                children: [
                  Container(
                    height: 54,
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    decoration: BoxDecoration(
                      color: AppColors.surfaceHigh.withOpacity(0.72),
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text('🇾🇪', style: TextStyle(fontSize: 20)),
                        SizedBox(width: 8),
                        Text(AppConstants.defaultCountryCode, style: TextStyle(fontWeight: FontWeight.w800)),
                      ],
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: ShamelTextField(
                      controller: _phoneController,
                      hintText: 'رقم الهاتف',
                      keyboardType: TextInputType.phone,
                      textInputAction: TextInputAction.done,
                      prefixIcon: Icons.phone_iphone_rounded,
                      maxLength: 9,
                      inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                      validator: Validators.phone,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            ShamelButton.primary(
              label: 'إرسال رمز التحقق',
              isLoading: isLoading,
              onPressed: isLoading
                  ? null
                  : () async {
                      if (!(_formKey.currentState?.validate() ?? false)) return;
                      final success = await ref.read(authControllerProvider.notifier).requestOtp(_phoneController.text);
                      if (!mounted || !success) return;
                      Navigator.of(context).pushNamed(AppRoutes.otp);
                    },
            ),
            const SizedBox(height: 20),
            GlassContainer(
              opacity: 0.46,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.shield_outlined, color: AppColors.accentGold),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'سيتم إرسال رمز تحقق حقيقي عبر Firebase Authentication بعد تفعيل إعدادات المشروع.',
                      style: AppTextStyles.caption,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
