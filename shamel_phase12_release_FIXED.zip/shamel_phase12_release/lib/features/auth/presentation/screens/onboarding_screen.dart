import 'package:flutter/material.dart';

import '../../../../core/config/app_config.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/widgets/glass_container.dart';
import '../../../../core/widgets/premium_scaffold.dart';
import '../../../../core/widgets/shamel_button.dart';
import '../../../../routes/app_routes.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _controller = PageController();
  int _index = 0;

  static const pages = [
    ('خدماتك في مكان واحد', 'اطلب الخدمات اليومية من واجهة موحدة وسهلة.'),
    ('تجربة فاخرة وبسيطة', 'تصميم داكن، واضح، وسريع الوصول بدون تعقيد.'),
    ('جاهز للنمو', 'هيكل قابل للتوسع لربط الطلبات والمقدمين لاحقًا.'),
  ];

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return PremiumScaffold(
      child: Column(
        children: [
          Align(
            alignment: AlignmentDirectional.centerEnd,
            child: TextButton(
              onPressed: () => Navigator.of(context).pushReplacementNamed(AppRoutes.login),
              child: const Text('تخطي'),
            ),
          ),
          Expanded(
            child: PageView.builder(
              controller: _controller,
              itemCount: pages.length,
              onPageChanged: (value) => setState(() => _index = value),
              itemBuilder: (context, index) {
                final page = pages[index];
                return Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    GlassContainer(
                      padding: const EdgeInsets.all(34),
                      borderRadius: 32,
                      child: Icon(
                        index == 0 ? Icons.grid_view_rounded : index == 1 ? Icons.auto_awesome_rounded : Icons.layers_rounded,
                        size: 82,
                        color: AppColors.primary,
                      ),
                    ),
                    const SizedBox(height: 34),
                    Text(page.$1, style: AppTextStyles.title, textAlign: TextAlign.center),
                    const SizedBox(height: 12),
                    Text(page.$2, style: AppTextStyles.caption, textAlign: TextAlign.center),
                  ],
                );
              },
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(pages.length, (index) {
              final selected = index == _index;
              return AnimatedContainer(
                duration: AppConfig.defaultAnimationDuration,
                margin: const EdgeInsets.symmetric(horizontal: 4),
                width: selected ? 24 : 8,
                height: 8,
                decoration: BoxDecoration(
                  color: selected ? AppColors.primary : AppColors.surfaceHigh,
                  borderRadius: BorderRadius.circular(999),
                ),
              );
            }),
          ),
          const SizedBox(height: 24),
          ShamelButton.primary(
            label: _index == pages.length - 1 ? 'ابدأ الآن' : 'التالي',
            onPressed: () {
              if (_index == pages.length - 1) {
                Navigator.of(context).pushReplacementNamed(AppRoutes.login);
              } else {
                _controller.nextPage(duration: AppConfig.defaultAnimationDuration, curve: Curves.easeOutCubic);
              }
            },
          ),
          const SizedBox(height: 18),
        ],
      ),
    );
  }
}
