import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/constants/app_constants.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/utils/ui_state.dart';
import '../../../../core/utils/validators.dart';
import '../../../../core/widgets/glass_container.dart';
import '../../../../core/widgets/premium_app_bar.dart';
import '../../../../core/widgets/premium_scaffold.dart';
import '../../../../core/widgets/shamel_button.dart';
import '../../../../routes/app_routes.dart';
import '../../domain/account_type.dart';
import '../controllers/auth_controller.dart';
import '../widgets/otp_code_field.dart';

class OtpScreen extends ConsumerStatefulWidget {
  const OtpScreen({super.key});

  @override
  ConsumerState<OtpScreen> createState() => _OtpScreenState();
}

class _OtpScreenState extends ConsumerState<OtpScreen> {
  final _formKey = GlobalKey<FormState>();
  final _otpController = TextEditingController();
  Timer? _timer;
  int _remainingSeconds = AppConstants.otpTimeoutSeconds;

  @override
  void initState() {
    super.initState();
    _startTimer();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _otpController.dispose();
    super.dispose();
  }

  void _startTimer() {
    _timer?.cancel();
    setState(() => _remainingSeconds = AppConstants.otpTimeoutSeconds);
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_remainingSeconds <= 1) {
        timer.cancel();
        if (mounted) setState(() => _remainingSeconds = 0);
      } else {
        if (mounted) setState(() => _remainingSeconds--);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final auth = ref.watch(authControllerProvider);
    final isLoading = auth.viewState == ViewState.loading;
    final phone = auth.phone.isEmpty ? 'رقم الهاتف' : auth.phone;

    ref.listen(authControllerProvider, (previous, next) {
      final message = next.errorMessage ?? next.message;
      if (message != null && message != previous?.message && message != previous?.errorMessage) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
      }
    });

    return PremiumScaffold(
      appBar: const PremiumAppBar(title: 'رمز التحقق', showBack: true),
      child: Form(
        key: _formKey,
        child: ListView(
          children: [
            const SizedBox(height: 34),
            Text('أدخل رمز التحقق', style: AppTextStyles.display),
            const SizedBox(height: 8),
            Text('أرسلنا رمزًا مكونًا من 6 أرقام إلى $phone', style: AppTextStyles.caption),
            const SizedBox(height: 28),
            OtpCodeField(
              controller: _otpController,
              enabled: !isLoading,
              validator: Validators.otp,
              onChanged: (value) async {
                if (value.length == AppConstants.otpLength) {
                  FocusScope.of(context).unfocus();
                }
              },
            ),
            const SizedBox(height: 18),
            ShamelButton.primary(
              label: 'تحقق',
              isLoading: isLoading,
              onPressed: isLoading
                  ? null
                  : () async {
                      if (!(_formKey.currentState?.validate() ?? false)) return;
                      final success = await ref.read(authControllerProvider.notifier).verifyOtp(_otpController.text);
                      if (!mounted || !success) return;
                      final next = ref.read(authControllerProvider);
                      if (next.needsAccountType) {
                        Navigator.of(context).pushNamedAndRemoveUntil(AppRoutes.accountType, (_) => false);
                      } else if (next.user?.userType == AccountType.provider) {
                        Navigator.of(context).pushNamedAndRemoveUntil(AppRoutes.providerShell, (_) => false);
                      } else {
                        Navigator.of(context).pushNamedAndRemoveUntil(AppRoutes.customerShell, (_) => false);
                      }
                    },
            ),
            const SizedBox(height: 16),
            GlassContainer(
              opacity: 0.52,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.timer_outlined, color: AppColors.primary),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          _remainingSeconds > 0
                              ? 'يمكنك إعادة إرسال الرمز بعد $_remainingSeconds ثانية'
                              : 'يمكنك الآن إعادة إرسال رمز التحقق',
                          style: AppTextStyles.body,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  ShamelButton.secondary(
                    label: 'إعادة الإرسال',
                    onPressed: _remainingSeconds > 0 || isLoading
                        ? null
                        : () async {
                            final success = await ref.read(authControllerProvider.notifier).requestOtp(phone);
                            if (success) _startTimer();
                          },
                  ),
                  const SizedBox(height: 12),
                  Text('محاولات التحقق المتبقية: ${auth.remainingAttempts}', style: AppTextStyles.caption),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
