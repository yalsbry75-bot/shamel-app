import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/errors/app_exception.dart';
import '../../../../core/utils/ui_state.dart';
import '../../data/auth_repository.dart';
import '../../domain/account_type.dart';
import '../../domain/auth_state.dart';

final authControllerProvider = StateNotifierProvider<AuthController, AuthState>((ref) {
  return AuthController(ref.watch(authRepositoryProvider));
});

class AuthController extends StateNotifier<AuthState> {
  AuthController(this._repository) : super(const AuthState());

  final AuthRepository _repository;

  Future<void> initializeSession() async {
    state = state.copyWith(viewState: ViewState.loading, clearError: true, clearMessage: true);
    try {
      final user = await _repository.getCurrentUser();
      state = state.copyWith(
        user: user,
        clearUser: user == null,
        phone: user?.phoneNumber ?? '',
        accountType: user?.userType,
        clearAccountType: user?.userType == null,
        sessionChecked: true,
        viewState: ViewState.success,
      );
    } catch (_) {
      state = AuthState.signedOut().copyWith(errorMessage: 'تعذر قراءة الجلسة المحفوظة. أعد تسجيل الدخول.');
    }
  }

  Future<bool> requestOtp(String phone) async {
    state = state.copyWith(
      phone: phone.trim(),
      viewState: ViewState.loading,
      clearError: true,
      clearMessage: true,
    );
    try {
      final result = await _repository.requestOtp(phone.trim());
      state = state.copyWith(
        phone: result.phoneNumber,
        viewState: ViewState.success,
        message: 'تم إرسال رمز التحقق إلى ${result.maskedPhone}',
        remainingAttempts: result.remainingAttempts,
        canResendAt: result.canResendAt,
      );
      return true;
    } catch (error) {
      state = state.copyWith(
        viewState: ViewState.error,
        errorMessage: _safeMessage(error),
      );
      return false;
    }
  }

  Future<bool> verifyOtp(String otp) async {
    state = state.copyWith(otp: otp.trim(), viewState: ViewState.loading, clearError: true, clearMessage: true);
    try {
      final user = await _repository.verifyOtp(phoneNumber: state.phone, otp: otp.trim());
      state = state.copyWith(
        user: user,
        accountType: user.userType,
        viewState: ViewState.success,
        message: 'تم التحقق بنجاح',
      );
      return true;
    } catch (error) {
      final currentAttempts = state.remainingAttempts;
      state = state.copyWith(
        viewState: ViewState.error,
        errorMessage: _safeMessage(error),
        remainingAttempts: currentAttempts > 0 ? currentAttempts - 1 : 0,
      );
      return false;
    }
  }

  Future<bool> selectAccountType(AccountType accountType) async {
    final user = state.user;
    if (user == null) {
      state = state.copyWith(viewState: ViewState.error, errorMessage: 'الجلسة غير متاحة. أعد تسجيل الدخول.');
      return false;
    }

    if (user.userType != null && user.userType != accountType) {
      state = state.copyWith(
        viewState: ViewState.error,
        errorMessage: 'لا يمكن تغيير نوع الحساب بعد الحفظ إلا بصلاحية خاصة.',
      );
      return false;
    }

    state = state.copyWith(viewState: ViewState.loading, clearError: true, clearMessage: true);
    try {
      final updated = await _repository.selectAccountType(user: user, type: accountType);
      state = state.copyWith(
        user: updated,
        accountType: updated.userType,
        viewState: ViewState.success,
        message: 'تم حفظ نوع الحساب',
      );
      return true;
    } catch (error) {
      state = state.copyWith(viewState: ViewState.error, errorMessage: _safeMessage(error));
      return false;
    }
  }

  Future<bool> updateProfile({
    required String name,
    required String governorate,
    required String district,
  }) async {
    final user = state.user;
    if (user == null) {
      state = state.copyWith(viewState: ViewState.error, errorMessage: 'الجلسة غير متاحة. أعد تسجيل الدخول.');
      return false;
    }

    state = state.copyWith(viewState: ViewState.loading, clearError: true, clearMessage: true);
    try {
      final updated = await _repository.updateProfile(
        user: user,
        name: name,
        governorate: governorate,
        district: district,
      );
      state = state.copyWith(
        user: updated,
        accountType: updated.userType,
        viewState: ViewState.success,
        message: 'تم حفظ بيانات الملف الشخصي',
      );
      return true;
    } catch (error) {
      state = state.copyWith(viewState: ViewState.error, errorMessage: _safeMessage(error));
      return false;
    }
  }

  Future<void> signOut() async {
    state = state.copyWith(viewState: ViewState.loading, clearError: true, clearMessage: true);
    await _repository.signOut();
    state = AuthState.signedOut();
  }

  void clearMessages() {
    state = state.copyWith(clearError: true, clearMessage: true);
  }

  String _safeMessage(Object error) {
    if (error is AppException) return error.message;
    return 'تعذر إكمال العملية. حاول مرة أخرى.';
  }
}
