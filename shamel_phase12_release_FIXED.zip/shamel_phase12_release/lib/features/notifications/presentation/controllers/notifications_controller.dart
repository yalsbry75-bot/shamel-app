import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/errors/app_exception.dart';
import '../../../../core/utils/ui_state.dart';
import '../../data/notification_repository.dart';
import '../../domain/notifications_state.dart';

final notificationsControllerProvider = StateNotifierProvider<NotificationsController, NotificationsState>((ref) {
  return NotificationsController(ref.watch(notificationRepositoryProvider));
});

class NotificationsController extends StateNotifier<NotificationsState> {
  NotificationsController(this._repository) : super(const NotificationsState());

  final NotificationRepository _repository;

  Future<void> load(String userId) async {
    if (userId.trim().isEmpty) return;
    state = state.copyWith(viewState: ViewState.loading, clearError: true, clearMessage: true);
    try {
      final items = await _repository.loadForUser(userId);
      state = state.copyWith(
        viewState: items.isEmpty ? ViewState.empty : ViewState.success,
        notifications: items,
      );
    } catch (error) {
      state = state.copyWith(viewState: ViewState.error, errorMessage: _safeMessage(error));
    }
  }

  Future<void> markAsRead(String userId, String notificationId) async {
    await _repository.markAsRead(notificationId);
    await load(userId);
  }

  Future<void> markAllAsRead(String userId) async {
    await _repository.markAllAsRead(userId);
    await load(userId);
  }

  Future<void> clear(String userId) async {
    await _repository.clearForUser(userId);
    await load(userId);
  }

  String _safeMessage(Object error) {
    if (error is AppException) return error.message;
    return 'تعذر إكمال العملية. حاول مرة أخرى.';
  }
}
