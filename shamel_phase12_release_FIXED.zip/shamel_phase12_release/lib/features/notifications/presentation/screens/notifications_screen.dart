import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/utils/ui_state.dart';
import '../../../../core/widgets/empty_state.dart';
import '../../../../core/widgets/error_state.dart';
import '../../../../core/widgets/glass_container.dart';
import '../../../../core/widgets/premium_app_bar.dart';
import '../../../../core/widgets/premium_scaffold.dart';
import '../../../../routes/app_routes.dart';
import '../../../auth/presentation/controllers/auth_controller.dart';
import '../controllers/notifications_controller.dart';

class NotificationsScreen extends ConsumerStatefulWidget {
  const NotificationsScreen({super.key});

  @override
  ConsumerState<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends ConsumerState<NotificationsScreen> {
  String? _loadedForUser;

  void _bootstrap(String? userId) {
    if (userId == null || userId.isEmpty || _loadedForUser == userId) return;
    _loadedForUser = userId;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      ref.read(notificationsControllerProvider.notifier).load(userId);
    });
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authControllerProvider).user;
    _bootstrap(user?.userId);
    final state = ref.watch(notificationsControllerProvider);

    return PremiumScaffold(
      appBar: PremiumAppBar(
        title: 'الإشعارات',
        showBack: true,
        actions: [
          if (user != null && state.notifications.isNotEmpty)
            IconButton(
              tooltip: 'تعليم الكل كمقروء',
              onPressed: () => ref.read(notificationsControllerProvider.notifier).markAllAsRead(user.userId),
              icon: const Icon(Icons.done_all_rounded),
            ),
        ],
      ),
      child: Builder(
        builder: (context) {
          if (user == null) {
            return const Center(
              child: EmptyState(
                title: 'لا توجد جلسة نشطة',
                message: 'سجّل الدخول لعرض إشعارات الحساب.',
                icon: Icons.lock_outline_rounded,
              ),
            );
          }
          if (state.viewState == ViewState.loading) {
            return const Center(child: CircularProgressIndicator());
          }
          if (state.viewState == ViewState.error) {
            return Center(
              child: ErrorState(
                message: state.errorMessage ?? 'حدث خطأ غير متوقع.',
                onRetry: () => ref.read(notificationsControllerProvider.notifier).load(user.userId),
              ),
            );
          }
          if (state.notifications.isEmpty) {
            return const Center(
              child: EmptyState(
                title: 'لا توجد إشعارات',
                message: 'ستظهر هنا تحديثات الطلبات وحالاتها.',
                icon: Icons.notifications_none_rounded,
              ),
            );
          }
          return RefreshIndicator(
            onRefresh: () => ref.read(notificationsControllerProvider.notifier).load(user.userId),
            child: ListView.separated(
              itemCount: state.notifications.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, index) {
                final item = state.notifications[index];
                return GlassContainer(
                  onTap: () async {
                    await ref.read(notificationsControllerProvider.notifier).markAsRead(user.userId, item.notificationId);
                    if (context.mounted && item.orderId.isNotEmpty) {
                      Navigator.of(context).pushNamed(AppRoutes.orderDetails, arguments: item.orderId);
                    }
                  },
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: 42,
                        height: 42,
                        decoration: BoxDecoration(
                          color: (item.isRead ? AppColors.surfaceHigh : AppColors.primary).withOpacity(0.18),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Icon(
                          item.isRead ? Icons.notifications_none_rounded : Icons.notifications_active_outlined,
                          color: item.isRead ? AppColors.textSecondary : AppColors.primary,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Expanded(child: Text(item.title, style: AppTextStyles.section)),
                                if (!item.isRead)
                                  Container(
                                    width: 8,
                                    height: 8,
                                    decoration: const BoxDecoration(color: AppColors.primary, shape: BoxShape.circle),
                                  ),
                              ],
                            ),
                            const SizedBox(height: 6),
                            Text(item.message, style: AppTextStyles.caption),
                            const SizedBox(height: 8),
                            Text(_formatDate(item.createdAt), style: AppTextStyles.caption.copyWith(color: AppColors.textSecondary)),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }

  String _formatDate(DateTime date) {
    final hour = date.hour.toString().padLeft(2, '0');
    final minute = date.minute.toString().padLeft(2, '0');
    return '${date.year}/${date.month.toString().padLeft(2, '0')}/${date.day.toString().padLeft(2, '0')} - $hour:$minute';
  }
}
