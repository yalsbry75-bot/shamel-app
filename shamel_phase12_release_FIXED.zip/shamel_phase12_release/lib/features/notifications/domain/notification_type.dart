enum NotificationType { orderCreated, orderAccepted, orderRejected, orderStatusChanged, orderCancelled, general }

extension NotificationTypeX on NotificationType {
  String get value {
    return switch (this) {
      NotificationType.orderCreated => 'order_created',
      NotificationType.orderAccepted => 'order_accepted',
      NotificationType.orderRejected => 'order_rejected',
      NotificationType.orderStatusChanged => 'order_status_changed',
      NotificationType.orderCancelled => 'order_cancelled',
      NotificationType.general => 'general',
    };
  }

  String get label {
    return switch (this) {
      NotificationType.orderCreated => 'طلب جديد',
      NotificationType.orderAccepted => 'قبول طلب',
      NotificationType.orderRejected => 'رفض طلب',
      NotificationType.orderStatusChanged => 'تحديث حالة',
      NotificationType.orderCancelled => 'إلغاء طلب',
      NotificationType.general => 'إشعار عام',
    };
  }

  static NotificationType fromValue(String value) {
    return NotificationType.values.firstWhere(
      (item) => item.value == value,
      orElse: () => NotificationType.general,
    );
  }
}
