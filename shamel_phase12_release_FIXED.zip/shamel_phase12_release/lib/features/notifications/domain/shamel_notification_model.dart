import 'notification_type.dart';

class ShamelNotificationModel {
  const ShamelNotificationModel({
    required this.notificationId,
    required this.userId,
    required this.title,
    required this.message,
    required this.type,
    required this.createdAt,
    this.isRead = false,
    this.orderId = '',
  });

  final String notificationId;
  final String userId;
  final String title;
  final String message;
  final NotificationType type;
  final DateTime createdAt;
  final bool isRead;
  final String orderId;

  factory ShamelNotificationModel.fromJson(Map<String, dynamic> json) {
    return ShamelNotificationModel(
      notificationId: json['notificationId'] as String? ?? '',
      userId: json['userId'] as String? ?? '',
      title: json['title'] as String? ?? '',
      message: json['message'] as String? ?? '',
      type: NotificationTypeX.fromValue(json['type'] as String? ?? 'general'),
      createdAt: DateTime.parse(json['createdAt'] as String),
      isRead: json['isRead'] as bool? ?? false,
      orderId: json['orderId'] as String? ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'notificationId': notificationId,
      'userId': userId,
      'title': title,
      'message': message,
      'type': type.value,
      'createdAt': createdAt.toIso8601String(),
      'isRead': isRead,
      'orderId': orderId,
    };
  }

  ShamelNotificationModel copyWith({
    String? notificationId,
    String? userId,
    String? title,
    String? message,
    NotificationType? type,
    DateTime? createdAt,
    bool? isRead,
    String? orderId,
  }) {
    return ShamelNotificationModel(
      notificationId: notificationId ?? this.notificationId,
      userId: userId ?? this.userId,
      title: title ?? this.title,
      message: message ?? this.message,
      type: type ?? this.type,
      createdAt: createdAt ?? this.createdAt,
      isRead: isRead ?? this.isRead,
      orderId: orderId ?? this.orderId,
    );
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        other is ShamelNotificationModel &&
            runtimeType == other.runtimeType &&
            notificationId == other.notificationId &&
            userId == other.userId &&
            title == other.title &&
            message == other.message &&
            type == other.type &&
            createdAt == other.createdAt &&
            isRead == other.isRead &&
            orderId == other.orderId;
  }

  @override
  int get hashCode => Object.hash(notificationId, userId, title, message, type, createdAt, isRead, orderId);
}
