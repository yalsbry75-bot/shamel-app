import '../../../core/utils/ui_state.dart';
import 'shamel_notification_model.dart';

class NotificationsState {
  const NotificationsState({
    this.notifications = const [],
    this.viewState = ViewState.initial,
    this.message,
    this.errorMessage,
  });

  final List<ShamelNotificationModel> notifications;
  final ViewState viewState;
  final String? message;
  final String? errorMessage;

  int get unreadCount => notifications.where((item) => !item.isRead).length;
  bool get isLoading => viewState == ViewState.loading;

  NotificationsState copyWith({
    List<ShamelNotificationModel>? notifications,
    ViewState? viewState,
    String? message,
    bool clearMessage = false,
    String? errorMessage,
    bool clearError = false,
  }) {
    return NotificationsState(
      notifications: notifications ?? this.notifications,
      viewState: viewState ?? this.viewState,
      message: clearMessage ? null : message ?? this.message,
      errorMessage: clearError ? null : errorMessage ?? this.errorMessage,
    );
  }
}
