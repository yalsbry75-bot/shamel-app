import '../domain/shamel_notification_model.dart';

import '../../../core/database/firestore_json.dart';
import '../../../core/database/firestore_collections.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
abstract class NotificationService {
  Future<List<ShamelNotificationModel>> loadForUser(String userId);
  Future<ShamelNotificationModel> add(ShamelNotificationModel notification);
  Future<void> markAsRead(String notificationId);
  Future<void> markAllAsRead(String userId);
  Future<void> clearForUser(String userId);
}

class FirebaseNotificationService implements NotificationService {
  FirebaseNotificationService({FirebaseFirestore? firestore}) : _firestore = firestore ?? FirebaseFirestore.instance;
  final FirebaseFirestore _firestore;

  @override
  Future<List<ShamelNotificationModel>> loadForUser(String userId) async {
    final snapshot = await _firestore.collection(FirestoreCollections.notifications).where('userId', isEqualTo: userId).orderBy('createdAt', descending: true).limit(80).get();
    return snapshot.docs.map((doc) => ShamelNotificationModel.fromJson(FirestoreJson.normalize(doc.data()))).toList(growable: false);
  }

  @override
  Future<ShamelNotificationModel> add(ShamelNotificationModel notification) async {
    if (notification.userId.trim().isEmpty) return notification;
    await _firestore.collection(FirestoreCollections.notifications).doc(notification.notificationId).set(FirestoreJson.withServerAudit(notification.toJson(), isCreate: true), SetOptions(merge: true));
    return notification;
  }

  @override
  Future<void> markAsRead(String notificationId) async {
    await _firestore.collection(FirestoreCollections.notifications).doc(notificationId).set({'isRead': true, 'updatedAtServer': FieldValue.serverTimestamp()}, SetOptions(merge: true));
  }

  @override
  Future<void> markAllAsRead(String userId) async {
    final snapshot = await _firestore.collection(FirestoreCollections.notifications).where('userId', isEqualTo: userId).where('isRead', isEqualTo: false).limit(100).get();
    final batch = _firestore.batch();
    for (final doc in snapshot.docs) {
      batch.set(doc.reference, {'isRead': true, 'updatedAtServer': FieldValue.serverTimestamp()}, SetOptions(merge: true));
    }
    await batch.commit();
  }

  @override
  Future<void> clearForUser(String userId) async {
    final snapshot = await _firestore.collection(FirestoreCollections.notifications).where('userId', isEqualTo: userId).limit(100).get();
    final batch = _firestore.batch();
    for (final doc in snapshot.docs) {
      batch.delete(doc.reference);
    }
    await batch.commit();
  }
}
