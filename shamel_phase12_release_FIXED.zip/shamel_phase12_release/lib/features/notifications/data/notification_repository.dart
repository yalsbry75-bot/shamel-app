import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../domain/notification_type.dart';
import '../domain/shamel_notification_model.dart';
import 'notification_service.dart';

final notificationServiceProvider = Provider<NotificationService>((ref) => FirebaseNotificationService());

final notificationRepositoryProvider = Provider<NotificationRepository>((ref) {
  return NotificationRepository(ref.watch(notificationServiceProvider));
});

class NotificationRepository {
  const NotificationRepository(this._service);

  final NotificationService _service;

  Future<List<ShamelNotificationModel>> loadForUser(String userId) => _service.loadForUser(userId);

  Future<ShamelNotificationModel> create({
    required String userId,
    required String title,
    required String message,
    required NotificationType type,
    String orderId = '',
  }) {
    final notification = ShamelNotificationModel(
      notificationId: _id('ntf', userId),
      userId: userId,
      title: title.trim(),
      message: message.trim(),
      type: type,
      createdAt: DateTime.now(),
      orderId: orderId,
    );
    return _service.add(notification);
  }

  Future<void> markAsRead(String notificationId) => _service.markAsRead(notificationId);
  Future<void> markAllAsRead(String userId) => _service.markAllAsRead(userId);
  Future<void> clearForUser(String userId) => _service.clearForUser(userId);

  String _id(String prefix, String ownerId) {
    final safeOwner = ownerId.replaceAll(RegExp(r'[^A-Za-z0-9_]'), '');
    return '${prefix}_${safeOwner}_${DateTime.now().microsecondsSinceEpoch}';
  }
}
