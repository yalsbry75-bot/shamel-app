import '../../../core/utils/ui_state.dart';

class HomeState {
  const HomeState({this.viewState = ViewState.success, this.message});

  final ViewState viewState;
  final String? message;

  HomeState copyWith({ViewState? viewState, String? message}) {
    return HomeState(
      viewState: viewState ?? this.viewState,
      message: message ?? this.message,
    );
  }
}
