import '../../../core/errors/app_exception.dart';

class HomeService {
  const HomeService();

  Future<void> load() {
    throw const AppException('Home service is prepared but disabled until its dedicated phase.');
  }
}
