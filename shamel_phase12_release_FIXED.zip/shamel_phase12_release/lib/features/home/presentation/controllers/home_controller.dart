import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../domain/home_state.dart';

final homeControllerProvider = StateNotifierProvider<HomeController, HomeState>((ref) {
  return HomeController();
});

class HomeController extends StateNotifier<HomeState> {
  HomeController() : super(const HomeState());
}
