import 'package:flutter/material.dart';

import '../../../../core/config/app_config.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/widgets/glass_container.dart';
import '../../../../core/widgets/premium_app_bar.dart';
import '../../../../core/widgets/premium_scaffold.dart';
import '../../../../routes/app_routes.dart';
import '../../../../shared/components/section_header.dart';
import '../../../ads/presentation/widgets/top_banner_slider.dart';
import '../../../search/presentation/widgets/discovery_suggestions_section.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return PremiumScaffold(
      appBar: PremiumAppBar(
        title: 'مرحبًا بك في شامل',
        subtitle: AppConfig.appTagline,
        actions: [
          IconButton(
            onPressed: () => Navigator.of(context).pushNamed(AppRoutes.notifications),
            icon: const Icon(Icons.notifications_none_rounded),
          ),
        ],
      ),
      child: ListView(
        children: [
          GlassContainer(
            child: InkWell(
              onTap: () => Navigator.of(context).pushNamed(AppRoutes.search),
              child: Row(
                children: [
                  const Icon(Icons.search_rounded, color: AppColors.textSecondary),
                  const SizedBox(width: 12),
                  Expanded(child: Text('ابحث عن خدمة، مقدم خدمة، إعلان، سيارة أو عقار...', style: AppTextStyles.caption)),
                  const Icon(Icons.tune_rounded, color: AppColors.textSecondary, size: 18),
                ],
              ),
            ),
          ),
          const SizedBox(height: 18),
          SectionHeader(
            title: 'عروض وإعلانات مميزة',
            actionLabel: 'Marketplace',
            onAction: () => Navigator.of(context).pushNamed(AppRoutes.ads),
          ),
          const SizedBox(height: 12),
          const TopBannerSlider(),
          const SizedBox(height: 22),
          SectionHeader(
            title: 'اكتشف حسب التصنيف',
            actionLabel: 'عرض الكل',
            onAction: () => Navigator.of(context).pushNamed(AppRoutes.categories),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: const [
              _CategoryShortcut(label: 'مطاعم', categoryId: 'restaurants', icon: Icons.restaurant_outlined),
              _CategoryShortcut(label: 'عقارات', categoryId: 'real_estate', icon: Icons.home_work_outlined),
              _CategoryShortcut(label: 'سيارات', categoryId: 'cars', icon: Icons.directions_car_outlined),
              _CategoryShortcut(label: 'حرفيين', categoryId: 'craftsmen', icon: Icons.handyman_outlined),
              _CategoryShortcut(label: 'تكاسي', categoryId: 'taxi', icon: Icons.local_taxi_outlined),
            ],
          ),
          const SizedBox(height: 24),
          const DiscoverySuggestionsSection(),
          const SizedBox(height: 120),
        ],
      ),
    );
  }
}

class _CategoryShortcut extends StatelessWidget {
  const _CategoryShortcut({required this.label, required this.categoryId, required this.icon});

  final String label;
  final String categoryId;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return ActionChip(
      avatar: Icon(icon, size: 17, color: AppColors.primary),
      label: Text(label),
      onPressed: () => Navigator.of(context).pushNamed(AppRoutes.search, arguments: {'categoryId': categoryId, 'query': label}),
      side: const BorderSide(color: AppColors.border),
      backgroundColor: AppColors.surface.withOpacity(0.72),
    );
  }
}
