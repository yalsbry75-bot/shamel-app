import 'package:flutter/material.dart';

import '../../../../core/widgets/premium_bottom_nav.dart';
import '../../../categories/presentation/screens/categories_screen.dart';
import '../../../orders/presentation/screens/orders_screen.dart';
import '../../../profile/presentation/screens/profile_screen.dart';
import 'favorites_screen.dart';
import 'home_screen.dart';

class CustomerShell extends StatefulWidget {
  const CustomerShell({super.key});

  @override
  State<CustomerShell> createState() => _CustomerShellState();
}

class _CustomerShellState extends State<CustomerShell> {
  int _index = 0;

  final _pages = const [
    HomeScreen(),
    CategoriesScreen(isEmbedded: true),
    OrdersScreen(isEmbedded: true),
    FavoritesScreen(),
    ProfileScreen(isEmbedded: true),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: _index, children: _pages),
      bottomNavigationBar: PremiumBottomNav(
        currentIndex: _index,
        onTap: (value) => setState(() => _index = value),
        items: const [
          PremiumNavItem(label: 'الرئيسية', icon: Icons.home_rounded),
          PremiumNavItem(label: 'الأقسام', icon: Icons.grid_view_rounded),
          PremiumNavItem(label: 'طلباتي', icon: Icons.receipt_long_rounded),
          PremiumNavItem(label: 'المفضلة', icon: Icons.favorite_border_rounded),
          PremiumNavItem(label: 'حسابي', icon: Icons.person_outline_rounded),
        ],
      ),
    );
  }
}
