import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/utils/ui_state.dart';
import '../../../../core/widgets/empty_state.dart';
import '../../../../core/widgets/error_state.dart';
import '../../../../core/widgets/glass_container.dart';
import '../../../../core/widgets/loading_skeleton.dart';
import '../../../../core/widgets/premium_app_bar.dart';
import '../../../../core/widgets/premium_scaffold.dart';
import '../../../../routes/app_routes.dart';
import '../../../auth/presentation/controllers/auth_controller.dart';
import '../../../favorites/domain/favorite_item_type.dart';
import '../../../favorites/domain/favorite_model.dart';
import '../../../favorites/presentation/controllers/favorites_controller.dart';

class FavoritesScreen extends ConsumerStatefulWidget {
  const FavoritesScreen({super.key});

  @override
  ConsumerState<FavoritesScreen> createState() => _FavoritesScreenState();
}

class _FavoritesScreenState extends ConsumerState<FavoritesScreen> with SingleTickerProviderStateMixin {
  late final TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    Future.microtask(() {
      final userId = ref.read(authControllerProvider).user?.userId ?? '';
      ref.read(favoritesControllerProvider.notifier).load(userId);
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final userId = ref.watch(authControllerProvider).user?.userId ?? '';
    final state = ref.watch(favoritesControllerProvider);
    return PremiumScaffold(
      appBar: PremiumAppBar(
        title: 'المفضلة',
        subtitle: 'مقدمو الخدمات والإعلانات المحفوظة',
        actions: [IconButton(onPressed: () => ref.read(favoritesControllerProvider.notifier).load(userId), icon: const Icon(Icons.refresh_rounded))],
      ),
      child: Column(
        children: [
          Container(
            decoration: BoxDecoration(color: AppColors.surface.withOpacity(0.7), borderRadius: BorderRadius.circular(18), border: Border.all(color: AppColors.border)),
            child: TabBar(
              controller: _tabController,
              tabs: const [Tab(text: 'مقدمو الخدمات'), Tab(text: 'الإعلانات')],
            ),
          ),
          const SizedBox(height: 14),
          Expanded(
            child: state.viewState == ViewState.loading
                ? const LoadingSkeleton(height: 160)
                : state.viewState == ViewState.error
                    ? ErrorState(message: state.errorMessage ?? 'تعذر تحميل المفضلة.', onRetry: () => ref.read(favoritesControllerProvider.notifier).load(userId))
                    : TabBarView(
                        controller: _tabController,
                        children: [
                          _FavoriteList(items: state.providers, emptyTitle: 'لا يوجد مقدمو خدمات محفوظون', onRemove: (item) => ref.read(favoritesControllerProvider.notifier).remove(userId: userId, itemId: item.itemId, itemType: item.itemType)),
                          _FavoriteList(items: state.ads, emptyTitle: 'لا توجد إعلانات محفوظة', onRemove: (item) => ref.read(favoritesControllerProvider.notifier).remove(userId: userId, itemId: item.itemId, itemType: item.itemType)),
                        ],
                      ),
          ),
        ],
      ),
    );
  }
}

class _FavoriteList extends StatelessWidget {
  const _FavoriteList({required this.items, required this.emptyTitle, required this.onRemove});

  final List<FavoriteModel> items;
  final String emptyTitle;
  final ValueChanged<FavoriteModel> onRemove;

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) {
      return Center(child: EmptyState(title: emptyTitle, message: 'استخدم زر القلب من نتائج البحث أو التفاصيل للحفظ هنا.', icon: Icons.favorite_border_rounded));
    }
    return ListView.builder(
      itemCount: items.length,
      itemBuilder: (context, index) {
        final item = items[index];
        return Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: GlassContainer(
            onTap: () {
              if (item.itemType == FavoriteItemType.ad) {
                Navigator.of(context).pushNamed(AppRoutes.adDetails, arguments: item.itemId);
              } else {
                Navigator.of(context).pushNamed(AppRoutes.serviceDetails);
              }
            },
            child: Row(
              children: [
                Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(color: AppColors.primary.withOpacity(0.15), borderRadius: BorderRadius.circular(18)),
                  child: Icon(item.itemType == FavoriteItemType.ad ? Icons.campaign_outlined : Icons.storefront_outlined, color: AppColors.primary),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(item.title.isEmpty ? item.itemType.label : item.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTextStyles.body.copyWith(fontWeight: FontWeight.w900)),
                      const SizedBox(height: 5),
                      Text(item.subtitle.isEmpty ? item.locationText : item.subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTextStyles.caption),
                    ],
                  ),
                ),
                IconButton(onPressed: () => onRemove(item), icon: const Icon(Icons.delete_outline_rounded, color: AppColors.textSecondary)),
              ],
            ),
          ),
        );
      },
    );
  }
}
