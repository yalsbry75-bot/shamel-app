import 'package:flutter/material.dart';

import '../../../../core/config/app_config.dart';
import '../../../../core/config/production_config.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_spacing.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/widgets/premium_scaffold.dart';
import '../../../../core/widgets/glass_container.dart';

class ProductionSetupRequiredScreen extends StatelessWidget {
  const ProductionSetupRequiredScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final missing = ProductionConfig.missingProductionItems;
    return PremiumScaffold(
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(AppSpacing.xl),
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 620),
              child: GlassContainer(
                padding: const EdgeInsets.all(AppSpacing.xl),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Container(
                      width: 84,
                      height: 84,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: const LinearGradient(colors: [AppColors.primary, Color(0xFF53A7FF)]),
                        boxShadow: [
                          BoxShadow(
                            color: AppColors.primary.withOpacity(0.24),
                            blurRadius: 34,
                            offset: const Offset(0, 18),
                          ),
                        ],
                      ),
                      child: const Text('ش', style: TextStyle(fontSize: 42, fontWeight: FontWeight.w900)),
                    ),
                    const SizedBox(height: AppSpacing.lg),
                    Text(
                      AppConfig.appName,
                      textAlign: TextAlign.center,
                      style: AppTextStyles.display,
                    ),
                    const SizedBox(height: AppSpacing.xs),
                    Text(
                      AppConfig.appTagline,
                      textAlign: TextAlign.center,
                      style: AppTextStyles.caption,
                    ),
                    const SizedBox(height: AppSpacing.xl),
                    Text(
                      'إعداد الإنتاج غير مكتمل',
                      textAlign: TextAlign.right,
                      style: AppTextStyles.title,
                    ),
                    const SizedBox(height: AppSpacing.sm),
                    Text(
                      'تم تجهيز التطبيق للإطلاق، لكن إعدادات Firebase الحقيقية غير موجودة داخل المشروع. أضف ملفات Firebase ثم أعد البناء لتفعيل تسجيل الدخول وقاعدة البيانات والتخزين والإشعارات.',
                      textAlign: TextAlign.right,
                      style: AppTextStyles.body,
                    ),
                    const SizedBox(height: AppSpacing.lg),
                    ...missing.map(
                      (item) => Padding(
                        padding: const EdgeInsets.only(bottom: AppSpacing.sm),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('• ', style: TextStyle(color: AppColors.accentGold, fontSize: 18)),
                            Expanded(child: Text(item, textAlign: TextAlign.right, style: AppTextStyles.caption)),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: AppSpacing.md),
                    Text(
                      'راجع docs/FINAL_DOCUMENTATION.md و docs/release/BUILD_RELEASE_GUIDE.md.',
                      textAlign: TextAlign.right,
                      style: AppTextStyles.caption.copyWith(color: AppColors.accentGold),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
