import 'order_status.dart';

class ServiceOrderModel {
  const ServiceOrderModel({
    required this.orderId,
    required this.userId,
    required this.providerId,
    required this.serviceType,
    required this.description,
    required this.phoneNumber,
    required this.locationText,
    required this.createdAt,
    required this.status,
    this.customerName = '',
    this.providerUserId = '',
    this.providerName = '',
    this.governorate = '',
    this.district = '',
    this.neighborhood = '',
    this.landmark = '',
    this.acceptedAt,
    this.rejectedAt,
    this.rejectionReason = '',
    this.cancelledAt,
    this.completedAt,
    this.updatedAt,
  });

  static const publicPoolProviderId = 'public_provider_pool';

  final String orderId;
  final String userId;
  final String customerName;
  final String providerId;
  final String providerUserId;
  final String providerName;
  final String serviceType;
  final String description;
  final String phoneNumber;
  final String governorate;
  final String district;
  final String neighborhood;
  final String landmark;
  final String locationText;
  final DateTime createdAt;
  final OrderStatus status;
  final DateTime? acceptedAt;
  final DateTime? rejectedAt;
  final String rejectionReason;
  final DateTime? cancelledAt;
  final DateTime? completedAt;
  final DateTime? updatedAt;

  bool get isPublicPool => providerId == publicPoolProviderId;

  factory ServiceOrderModel.fromJson(Map<String, dynamic> json) {
    return ServiceOrderModel(
      orderId: json['orderId'] as String? ?? '',
      userId: json['userId'] as String? ?? '',
      customerName: json['customerName'] as String? ?? '',
      providerId: json['providerId'] as String? ?? publicPoolProviderId,
      providerUserId: json['providerUserId'] as String? ?? '',
      providerName: json['providerName'] as String? ?? '',
      serviceType: json['serviceType'] as String? ?? '',
      description: json['description'] as String? ?? '',
      phoneNumber: json['phoneNumber'] as String? ?? '',
      governorate: json['governorate'] as String? ?? '',
      district: json['district'] as String? ?? '',
      neighborhood: json['neighborhood'] as String? ?? '',
      landmark: json['landmark'] as String? ?? '',
      locationText: json['locationText'] as String? ?? '',
      createdAt: DateTime.parse(json['createdAt'] as String),
      status: OrderStatusX.fromValue(json['status'] as String? ?? 'pending'),
      acceptedAt: _date(json['acceptedAt']),
      rejectedAt: _date(json['rejectedAt']),
      rejectionReason: json['rejectionReason'] as String? ?? '',
      cancelledAt: _date(json['cancelledAt']),
      completedAt: _date(json['completedAt']),
      updatedAt: _date(json['updatedAt']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'orderId': orderId,
      'userId': userId,
      'customerName': customerName,
      'providerId': providerId,
      'providerUserId': providerUserId,
      'providerName': providerName,
      'serviceType': serviceType,
      'description': description,
      'phoneNumber': phoneNumber,
      'governorate': governorate,
      'district': district,
      'neighborhood': neighborhood,
      'landmark': landmark,
      'locationText': locationText,
      'createdAt': createdAt.toIso8601String(),
      'status': status.value,
      'acceptedAt': acceptedAt?.toIso8601String(),
      'rejectedAt': rejectedAt?.toIso8601String(),
      'rejectionReason': rejectionReason,
      'cancelledAt': cancelledAt?.toIso8601String(),
      'completedAt': completedAt?.toIso8601String(),
      'updatedAt': updatedAt?.toIso8601String(),
    };
  }

  ServiceOrderModel copyWith({
    String? orderId,
    String? userId,
    String? customerName,
    String? providerId,
    String? providerUserId,
    String? providerName,
    String? serviceType,
    String? description,
    String? phoneNumber,
    String? governorate,
    String? district,
    String? neighborhood,
    String? landmark,
    String? locationText,
    DateTime? createdAt,
    OrderStatus? status,
    DateTime? acceptedAt,
    DateTime? rejectedAt,
    String? rejectionReason,
    DateTime? cancelledAt,
    DateTime? completedAt,
    DateTime? updatedAt,
  }) {
    return ServiceOrderModel(
      orderId: orderId ?? this.orderId,
      userId: userId ?? this.userId,
      customerName: customerName ?? this.customerName,
      providerId: providerId ?? this.providerId,
      providerUserId: providerUserId ?? this.providerUserId,
      providerName: providerName ?? this.providerName,
      serviceType: serviceType ?? this.serviceType,
      description: description ?? this.description,
      phoneNumber: phoneNumber ?? this.phoneNumber,
      governorate: governorate ?? this.governorate,
      district: district ?? this.district,
      neighborhood: neighborhood ?? this.neighborhood,
      landmark: landmark ?? this.landmark,
      locationText: locationText ?? this.locationText,
      createdAt: createdAt ?? this.createdAt,
      status: status ?? this.status,
      acceptedAt: acceptedAt ?? this.acceptedAt,
      rejectedAt: rejectedAt ?? this.rejectedAt,
      rejectionReason: rejectionReason ?? this.rejectionReason,
      cancelledAt: cancelledAt ?? this.cancelledAt,
      completedAt: completedAt ?? this.completedAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        other is ServiceOrderModel &&
            runtimeType == other.runtimeType &&
            orderId == other.orderId &&
            userId == other.userId &&
            customerName == other.customerName &&
            providerId == other.providerId &&
            providerUserId == other.providerUserId &&
            providerName == other.providerName &&
            serviceType == other.serviceType &&
            description == other.description &&
            phoneNumber == other.phoneNumber &&
            governorate == other.governorate &&
            district == other.district &&
            neighborhood == other.neighborhood &&
            landmark == other.landmark &&
            locationText == other.locationText &&
            createdAt == other.createdAt &&
            status == other.status &&
            acceptedAt == other.acceptedAt &&
            rejectedAt == other.rejectedAt &&
            rejectionReason == other.rejectionReason &&
            cancelledAt == other.cancelledAt &&
            completedAt == other.completedAt &&
            updatedAt == other.updatedAt;
  }

  @override
  int get hashCode => Object.hashAll([
        orderId,
        userId,
        customerName,
        providerId,
        providerUserId,
        providerName,
        serviceType,
        description,
        phoneNumber,
        governorate,
        district,
        neighborhood,
        landmark,
        locationText,
        createdAt,
        status,
        acceptedAt,
        rejectedAt,
        rejectionReason,
        cancelledAt,
        completedAt,
        updatedAt,
      ]);

  static DateTime? _date(dynamic value) {
    if (value == null || value.toString().isEmpty) return null;
    return DateTime.tryParse(value.toString());
  }
}
