import '../../../core/utils/ui_state.dart';
import 'order_status.dart';
import 'service_order_model.dart';

class OrdersState {
  const OrdersState({
    this.orders = const [],
    this.viewState = ViewState.initial,
    this.message,
    this.errorMessage,
  });

  final List<ServiceOrderModel> orders;
  final ViewState viewState;
  final String? message;
  final String? errorMessage;

  bool get isLoading => viewState == ViewState.loading;
  List<ServiceOrderModel> get currentOrders => orders.where((item) => item.status.isOpen).toList(growable: false);
  List<ServiceOrderModel> get previousOrders => orders.where((item) => item.status.isClosed).toList(growable: false);
  List<ServiceOrderModel> get pendingOrders => orders.where((item) => item.status == OrderStatus.pending).toList(growable: false);
  List<ServiceOrderModel> get acceptedOrders => orders.where((item) => item.status == OrderStatus.accepted || item.status == OrderStatus.onTheWay).toList(growable: false);
  List<ServiceOrderModel> get completedOrders => orders.where((item) => item.status == OrderStatus.completed).toList(growable: false);
  List<ServiceOrderModel> get rejectedOrders => orders.where((item) => item.status == OrderStatus.rejected || item.status == OrderStatus.cancelled).toList(growable: false);

  ServiceOrderModel? byId(String orderId) {
    for (final item in orders) {
      if (item.orderId == orderId) return item;
    }
    return null;
  }

  OrdersState copyWith({
    List<ServiceOrderModel>? orders,
    ViewState? viewState,
    String? message,
    bool clearMessage = false,
    String? errorMessage,
    bool clearError = false,
  }) {
    return OrdersState(
      orders: orders ?? this.orders,
      viewState: viewState ?? this.viewState,
      message: clearMessage ? null : message ?? this.message,
      errorMessage: clearError ? null : errorMessage ?? this.errorMessage,
    );
  }
}
