enum OrderStatus { pending, accepted, onTheWay, completed, rejected, cancelled }

extension OrderStatusX on OrderStatus {
  String get value {
    return switch (this) {
      OrderStatus.pending => 'pending',
      OrderStatus.accepted => 'accepted',
      OrderStatus.onTheWay => 'on_the_way',
      OrderStatus.completed => 'completed',
      OrderStatus.rejected => 'rejected',
      OrderStatus.cancelled => 'cancelled',
    };
  }

  String get label {
    return switch (this) {
      OrderStatus.pending => 'قيد الانتظار',
      OrderStatus.accepted => 'تم القبول',
      OrderStatus.onTheWay => 'في الطريق',
      OrderStatus.completed => 'تم الإنجاز',
      OrderStatus.rejected => 'مرفوض',
      OrderStatus.cancelled => 'ملغي',
    };
  }

  bool get isOpen => this == OrderStatus.pending || this == OrderStatus.accepted || this == OrderStatus.onTheWay;
  bool get isClosed => this == OrderStatus.completed || this == OrderStatus.rejected || this == OrderStatus.cancelled;

  static OrderStatus fromValue(String value) {
    return OrderStatus.values.firstWhere(
      (item) => item.value == value,
      orElse: () => OrderStatus.pending,
    );
  }
}
