import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/utils/ui_state.dart';
import '../../../../core/widgets/glass_container.dart';
import '../../../../core/widgets/premium_app_bar.dart';
import '../../../../core/widgets/premium_scaffold.dart';
import '../../../../core/widgets/shamel_button.dart';
import '../../../../core/widgets/shamel_text_field.dart';
import '../../../auth/presentation/controllers/auth_controller.dart';
import '../controllers/orders_controller.dart';

class CreateOrderScreen extends ConsumerStatefulWidget {
  const CreateOrderScreen({super.key});

  @override
  ConsumerState<CreateOrderScreen> createState() => _CreateOrderScreenState();
}

class _CreateOrderScreenState extends ConsumerState<CreateOrderScreen> {
  final _formKey = GlobalKey<FormState>();
  final _serviceTypeController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _governorateController = TextEditingController();
  final _districtController = TextEditingController();
  final _neighborhoodController = TextEditingController();
  final _landmarkController = TextEditingController();
  final _phoneController = TextEditingController();
  bool _hydrated = false;

  @override
  void dispose() {
    _serviceTypeController.dispose();
    _descriptionController.dispose();
    _governorateController.dispose();
    _districtController.dispose();
    _neighborhoodController.dispose();
    _landmarkController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  void _hydrate() {
    if (_hydrated) return;
    final user = ref.read(authControllerProvider).user;
    _phoneController.text = user?.phoneNumber.replaceAll('+967', '') ?? '';
    _governorateController.text = user?.governorate ?? '';
    _districtController.text = user?.district ?? '';
    _hydrated = true;
  }

  @override
  Widget build(BuildContext context) {
    _hydrate();
    final auth = ref.watch(authControllerProvider);
    final orders = ref.watch(ordersControllerProvider);
    final isLoading = orders.viewState == ViewState.loading;

    ref.listen(ordersControllerProvider, (previous, next) {
      final message = next.errorMessage ?? next.message;
      if (message != null && message != previous?.message && message != previous?.errorMessage) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
      }
    });

    return PremiumScaffold(
      appBar: const PremiumAppBar(title: 'إنشاء طلب خدمة', showBack: true),
      child: Form(
        key: _formKey,
        child: ListView(
          children: [
            GlassContainer(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('تفاصيل الطلب', style: AppTextStyles.title),
                  const SizedBox(height: 8),
                  Text('أرسل طلبك لمقدم خدمة متاح. في حال عدم وجود مقدم محدد، سيظهر الطلب في قائمة الطلبات العامة لمقدمي الخدمة.', style: AppTextStyles.caption),
                ],
              ),
            ),
            const SizedBox(height: 14),
            ShamelTextField(
              controller: _serviceTypeController,
              hintText: 'نوع الخدمة',
              prefixIcon: Icons.design_services_outlined,
              textInputAction: TextInputAction.next,
              validator: _required,
            ),
            const SizedBox(height: 12),
            ShamelTextField(
              controller: _descriptionController,
              hintText: 'وصف المشكلة أو الطلب',
              prefixIcon: Icons.notes_rounded,
              maxLines: 4,
              textInputAction: TextInputAction.newline,
              validator: (value) {
                final base = _required(value);
                if (base != null) return base;
                if (value!.trim().length < 10) return 'اكتب وصفًا أوضح لا يقل عن 10 أحرف';
                return null;
              },
            ),
            const SizedBox(height: 12),
            ShamelTextField(
              controller: _governorateController,
              hintText: 'المحافظة',
              prefixIcon: Icons.location_city_outlined,
              textInputAction: TextInputAction.next,
              validator: _required,
            ),
            const SizedBox(height: 12),
            ShamelTextField(
              controller: _districtController,
              hintText: 'المديرية',
              prefixIcon: Icons.place_outlined,
              textInputAction: TextInputAction.next,
              validator: _required,
            ),
            const SizedBox(height: 12),
            ShamelTextField(
              controller: _neighborhoodController,
              hintText: 'الحي',
              prefixIcon: Icons.home_work_outlined,
              textInputAction: TextInputAction.next,
              validator: _required,
            ),
            const SizedBox(height: 12),
            ShamelTextField(
              controller: _landmarkController,
              hintText: 'أقرب معلم',
              prefixIcon: Icons.flag_outlined,
              textInputAction: TextInputAction.next,
            ),
            const SizedBox(height: 12),
            ShamelTextField(
              controller: _phoneController,
              hintText: 'رقم التواصل',
              prefixIcon: Icons.phone_iphone_rounded,
              keyboardType: TextInputType.phone,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              maxLength: 9,
              validator: (value) {
                final text = value?.trim() ?? '';
                if (text.isEmpty) return 'رقم التواصل مطلوب';
                if (text.length < 7) return 'رقم التواصل قصير';
                return null;
              },
            ),
            const SizedBox(height: 22),
            ShamelButton.primary(
              label: 'إرسال الطلب',
              icon: Icons.send_rounded,
              isLoading: isLoading,
              onPressed: isLoading
                  ? null
                  : () async {
                      if (!(_formKey.currentState?.validate() ?? false)) return;
                      final user = auth.user;
                      if (user == null) {
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('سجّل الدخول أولًا لإنشاء الطلب.')));
                        return;
                      }
                      final ok = await ref.read(ordersControllerProvider.notifier).createOrder(
                            user: user,
                            serviceType: _serviceTypeController.text,
                            description: _descriptionController.text,
                            phoneNumber: _phoneController.text,
                            governorate: _governorateController.text,
                            district: _districtController.text,
                            neighborhood: _neighborhoodController.text,
                            landmark: _landmarkController.text,
                          );
                      if (ok && context.mounted) Navigator.of(context).pop();
                    },
            ),
          ],
        ),
      ),
    );
  }

  String? _required(String? value) {
    if (value == null || value.trim().isEmpty) return 'هذا الحقل مطلوب';
    return null;
  }
}
