import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/utils/ui_state.dart';
import '../../../../core/widgets/empty_state.dart';
import '../../../../core/widgets/error_state.dart';
import '../../../../core/widgets/premium_app_bar.dart';
import '../../../../core/widgets/premium_scaffold.dart';
import '../../../../core/widgets/shamel_button.dart';
import '../../../../routes/app_routes.dart';
import '../../../auth/presentation/controllers/auth_controller.dart';
import '../controllers/orders_controller.dart';
import '../widgets/service_order_card.dart';

class OrdersScreen extends ConsumerStatefulWidget {
  const OrdersScreen({super.key, this.isEmbedded = false});

  final bool isEmbedded;

  @override
  ConsumerState<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends ConsumerState<OrdersScreen> {
  String? _loadedForUser;

  void _bootstrap(String? userId) {
    if (userId == null || userId.isEmpty || _loadedForUser == userId) return;
    _loadedForUser = userId;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      ref.read(ordersControllerProvider.notifier).loadCustomerOrders(userId);
    });
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authControllerProvider).user;
    _bootstrap(user?.userId);
    final state = ref.watch(ordersControllerProvider);

    ref.listen(ordersControllerProvider, (previous, next) {
      final message = next.errorMessage ?? next.message;
      if (message != null && message != previous?.message && message != previous?.errorMessage) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
      }
    });

    return PremiumScaffold(
      appBar: widget.isEmbedded ? const PremiumAppBar(title: 'طلباتي') : const PremiumAppBar(title: 'طلباتي', showBack: true),
      child: Builder(
        builder: (context) {
          if (user == null) {
            return const Center(
              child: EmptyState(
                title: 'لا توجد جلسة نشطة',
                message: 'سجّل الدخول لعرض سجل الطلبات.',
                icon: Icons.lock_outline_rounded,
              ),
            );
          }
          if (state.viewState == ViewState.loading) return const Center(child: CircularProgressIndicator());
          if (state.viewState == ViewState.error) {
            return Center(
              child: ErrorState(
                message: state.errorMessage ?? 'حدث خطأ غير متوقع.',
                onRetry: () => ref.read(ordersControllerProvider.notifier).loadCustomerOrders(user.userId),
              ),
            );
          }
          if (state.orders.isEmpty) {
            return Center(
              child: EmptyState(
                title: 'لا توجد طلبات',
                message: 'ابدأ بإنشاء طلب خدمة جديد.',
                icon: Icons.receipt_long_rounded,
                actionLabel: 'إنشاء طلب',
                onAction: () => Navigator.of(context).pushNamed(AppRoutes.createOrder),
              ),
            );
          }
          return RefreshIndicator(
            onRefresh: () => ref.read(ordersControllerProvider.notifier).loadCustomerOrders(user.userId),
            child: ListView(
              children: [
                ShamelButton.primary(
                  label: 'إنشاء طلب جديد',
                  icon: Icons.add_circle_outline_rounded,
                  onPressed: () => Navigator.of(context).pushNamed(AppRoutes.createOrder),
                ),
                const SizedBox(height: 18),
                if (state.currentOrders.isNotEmpty) ...[
                  Text('الطلبات الحالية', style: AppTextStyles.title),
                  const SizedBox(height: 10),
                  ...state.currentOrders.map((order) => Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: ServiceOrderCard(order: order),
                      )),
                  const SizedBox(height: 14),
                ],
                if (state.previousOrders.isNotEmpty) ...[
                  Text('الطلبات السابقة', style: AppTextStyles.title),
                  const SizedBox(height: 10),
                  ...state.previousOrders.map((order) => Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: ServiceOrderCard(order: order),
                      )),
                ],
                const SizedBox(height: 110),
              ],
            ),
          );
        },
      ),
    );
  }
}
