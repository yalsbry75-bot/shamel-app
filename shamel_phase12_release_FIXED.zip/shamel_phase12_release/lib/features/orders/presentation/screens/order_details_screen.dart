import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/widgets/empty_state.dart';
import '../../../../core/widgets/glass_container.dart';
import '../../../../core/widgets/premium_app_bar.dart';
import '../../../../core/widgets/premium_scaffold.dart';
import '../../../../core/widgets/shamel_button.dart';
import '../../../auth/domain/account_type.dart';
import '../../../auth/presentation/controllers/auth_controller.dart';
import '../../../provider/domain/provider_profile_model.dart';
import '../../../provider/presentation/controllers/provider_controller.dart';
import '../../domain/order_status.dart';
import '../../domain/service_order_model.dart';
import '../controllers/orders_controller.dart';
import '../widgets/order_status_chip.dart';

class OrderDetailsScreen extends ConsumerStatefulWidget {
  const OrderDetailsScreen({super.key, required this.orderId});

  final String orderId;

  @override
  ConsumerState<OrderDetailsScreen> createState() => _OrderDetailsScreenState();
}

class _OrderDetailsScreenState extends ConsumerState<OrderDetailsScreen> {
  ServiceOrderModel? _order;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() async {
    final order = await ref.read(ordersControllerProvider.notifier).findOrder(widget.orderId);
    if (!mounted) return;
    setState(() {
      _order = order;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final auth = ref.watch(authControllerProvider);
    final providerProfile = ref.watch(providerControllerProvider).profile;
    final isProvider = auth.user?.userType == AccountType.provider;
    final order = ref.watch(ordersControllerProvider).byId(widget.orderId) ?? _order;

    ref.listen(ordersControllerProvider, (previous, next) {
      final message = next.errorMessage ?? next.message;
      if (message != null && message != previous?.message && message != previous?.errorMessage) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
      }
    });

    if (_loading) {
      return const PremiumScaffold(
        appBar: PremiumAppBar(title: 'تفاصيل الطلب', showBack: true),
        child: Center(child: CircularProgressIndicator()),
      );
    }

    if (order == null) {
      return const PremiumScaffold(
        appBar: PremiumAppBar(title: 'تفاصيل الطلب', showBack: true),
        child: Center(
          child: EmptyState(
            title: 'الطلب غير موجود',
            message: 'قد يكون الطلب حُذف أو لم يتم تحميله بعد.',
            icon: Icons.search_off_rounded,
          ),
        ),
      );
    }

    return PremiumScaffold(
      appBar: const PremiumAppBar(title: 'تفاصيل الطلب', showBack: true),
      child: ListView(
        children: [
          GlassContainer(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(child: Text(order.serviceType, style: AppTextStyles.display)),
                    OrderStatusChip(status: order.status),
                  ],
                ),
                const SizedBox(height: 10),
                Text(order.description, style: AppTextStyles.body),
                const SizedBox(height: 12),
                _InfoRow(icon: Icons.confirmation_number_outlined, label: 'رقم الطلب', value: order.orderId),
                _InfoRow(icon: Icons.access_time_rounded, label: 'تاريخ الإنشاء', value: _formatDate(order.createdAt)),
              ],
            ),
          ),
          const SizedBox(height: 12),
          GlassContainer(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('بيانات العميل', style: AppTextStyles.section),
                const SizedBox(height: 10),
                _InfoRow(icon: Icons.person_outline_rounded, label: 'الاسم', value: order.customerName.isEmpty ? 'عميل شامل' : order.customerName),
                _InfoRow(icon: Icons.phone_iphone_rounded, label: 'رقم التواصل', value: order.phoneNumber),
              ],
            ),
          ),
          const SizedBox(height: 12),
          GlassContainer(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('بيانات مقدم الخدمة', style: AppTextStyles.section),
                const SizedBox(height: 10),
                _InfoRow(icon: Icons.storefront_outlined, label: 'النشاط', value: order.providerName.isEmpty ? 'غير محدد بعد' : order.providerName),
                _InfoRow(icon: Icons.handyman_outlined, label: 'نوع الخدمة', value: order.serviceType),
              ],
            ),
          ),
          const SizedBox(height: 12),
          GlassContainer(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('الموقع النصي', style: AppTextStyles.section),
                const SizedBox(height: 10),
                _InfoRow(icon: Icons.location_city_outlined, label: 'المحافظة', value: order.governorate),
                _InfoRow(icon: Icons.place_outlined, label: 'المديرية', value: order.district),
                _InfoRow(icon: Icons.home_work_outlined, label: 'الحي', value: order.neighborhood),
                _InfoRow(icon: Icons.flag_outlined, label: 'أقرب معلم', value: order.landmark.isEmpty ? 'غير محدد' : order.landmark),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _Timeline(order: order),
          const SizedBox(height: 16),
          if (isProvider && providerProfile != null) ..._providerActions(context, order, providerProfile),
          if (!isProvider && order.status.isOpen)
            ShamelButton.secondary(
              label: 'إلغاء الطلب',
              icon: Icons.cancel_outlined,
              onPressed: () async {
                final ok = await ref.read(ordersControllerProvider.notifier).cancelOrder(order.orderId);
                if (ok) await _load();
              },
            ),
          const SizedBox(height: 120),
        ],
      ),
    );
  }

  List<Widget> _providerActions(BuildContext context, ServiceOrderModel order, ProviderProfileModel providerProfile) {
    if (order.status == OrderStatus.pending) {
      return [
        ShamelButton.primary(
          label: 'قبول الطلب',
          icon: Icons.check_circle_outline_rounded,
          onPressed: () async {
            final ok = await ref.read(ordersControllerProvider.notifier).acceptOrder(order.orderId, providerProfile);
            if (ok) await _load();
          },
        ),
        const SizedBox(height: 10),
        ShamelButton.secondary(
          label: 'رفض الطلب',
          icon: Icons.close_rounded,
          onPressed: () async {
            final reason = await _askRejectReason(context);
            if (reason == null) return;
            final ok = await ref.read(ordersControllerProvider.notifier).rejectOrder(order.orderId, providerProfile, reason);
            if (ok) await _load();
          },
        ),
      ];
    }
    if (order.status == OrderStatus.accepted) {
      return [
        ShamelButton.primary(
          label: 'تحديث إلى في الطريق',
          icon: Icons.directions_car_filled_outlined,
          onPressed: () async {
            final ok = await ref.read(ordersControllerProvider.notifier).markOnTheWay(order.orderId);
            if (ok) await _load();
          },
        ),
      ];
    }
    if (order.status == OrderStatus.onTheWay) {
      return [
        ShamelButton.primary(
          label: 'تحديث إلى تم الإنجاز',
          icon: Icons.task_alt_rounded,
          onPressed: () async {
            final ok = await ref.read(ordersControllerProvider.notifier).completeOrder(order.orderId);
            if (ok) await _load();
          },
        ),
      ];
    }
    return const [];
  }

  Future<String?> _askRejectReason(BuildContext context) async {
    final controller = TextEditingController();
    final result = await showDialog<String>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('سبب الرفض'),
          content: TextField(
            controller: controller,
            maxLines: 3,
            decoration: const InputDecoration(hintText: 'اختياري'),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('إلغاء')),
            FilledButton(onPressed: () => Navigator.of(context).pop(controller.text), child: const Text('رفض الطلب')),
          ],
        );
      },
    );
    controller.dispose();
    return result;
  }

  String _formatDate(DateTime? date) {
    if (date == null) return '—';
    final hour = date.hour.toString().padLeft(2, '0');
    final minute = date.minute.toString().padLeft(2, '0');
    return '${date.year}/${date.month.toString().padLeft(2, '0')}/${date.day.toString().padLeft(2, '0')} - $hour:$minute';
  }
}

class _InfoRow extends StatelessWidget {
  const _InfoRow({required this.icon, required this.label, required this.value});

  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 18, color: AppColors.textSecondary),
          const SizedBox(width: 8),
          SizedBox(width: 92, child: Text(label, style: AppTextStyles.caption)),
          Expanded(child: Text(value.isEmpty ? '—' : value, style: AppTextStyles.body)),
        ],
      ),
    );
  }
}

class _Timeline extends StatelessWidget {
  const _Timeline({required this.order});

  final ServiceOrderModel order;

  @override
  Widget build(BuildContext context) {
    final items = <({String label, bool done})>[
      (label: 'قيد الانتظار', done: true),
      (label: 'تم القبول', done: order.status == OrderStatus.accepted || order.status == OrderStatus.onTheWay || order.status == OrderStatus.completed),
      (label: 'في الطريق', done: order.status == OrderStatus.onTheWay || order.status == OrderStatus.completed),
      (label: 'تم الإنجاز', done: order.status == OrderStatus.completed),
    ];
    return GlassContainer(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('مسار الحالة', style: AppTextStyles.section),
          const SizedBox(height: 12),
          ...items.map((item) => Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Row(
                  children: [
                    Icon(item.done ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded, color: item.done ? AppColors.success : AppColors.textSecondary),
                    const SizedBox(width: 10),
                    Text(item.label, style: AppTextStyles.body),
                  ],
                ),
              )),
          if (order.status == OrderStatus.rejected || order.status == OrderStatus.cancelled) ...[
            const Divider(color: AppColors.border),
            Row(
              children: [
                const Icon(Icons.info_outline_rounded, color: AppColors.error),
                const SizedBox(width: 10),
                Expanded(child: Text(order.status.label, style: AppTextStyles.body.copyWith(color: AppColors.error))),
              ],
            ),
            if (order.rejectionReason.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text('سبب الرفض: ${order.rejectionReason}', style: AppTextStyles.caption),
            ],
          ],
        ],
      ),
    );
  }
}
