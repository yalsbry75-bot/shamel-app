import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/errors/app_exception.dart';
import '../../../../core/utils/ui_state.dart';
import '../../../auth/domain/user_model.dart';
import '../../../provider/domain/provider_profile_model.dart';
import '../../data/orders_repository.dart';
import '../../domain/order_status.dart';
import '../../domain/orders_state.dart';
import '../../domain/service_order_model.dart';

final ordersControllerProvider = StateNotifierProvider<OrdersController, OrdersState>((ref) {
  return OrdersController(ref.watch(ordersRepositoryProvider));
});

class OrdersController extends StateNotifier<OrdersState> {
  OrdersController(this._repository) : super(const OrdersState());

  final OrdersRepository _repository;
  String? _lastCustomerId;
  String? _lastProviderId;

  Future<void> loadCustomerOrders(String userId) async {
    _lastCustomerId = userId;
    state = state.copyWith(viewState: ViewState.loading, clearError: true, clearMessage: true);
    try {
      final orders = await _repository.loadForCustomer(userId);
      state = state.copyWith(viewState: orders.isEmpty ? ViewState.empty : ViewState.success, orders: orders);
    } catch (error) {
      state = state.copyWith(viewState: ViewState.error, errorMessage: _safeMessage(error));
    }
  }

  Future<void> loadProviderOrders(String providerId) async {
    _lastProviderId = providerId;
    state = state.copyWith(viewState: ViewState.loading, clearError: true, clearMessage: true);
    try {
      final orders = await _repository.loadForProvider(providerId);
      state = state.copyWith(viewState: orders.isEmpty ? ViewState.empty : ViewState.success, orders: orders);
    } catch (error) {
      state = state.copyWith(viewState: ViewState.error, errorMessage: _safeMessage(error));
    }
  }

  Future<ServiceOrderModel?> findOrder(String orderId) async {
    final local = state.byId(orderId);
    if (local != null) return local;
    return _repository.findById(orderId);
  }

  Future<bool> createOrder({
    required UserModel user,
    required String serviceType,
    required String description,
    required String phoneNumber,
    required String governorate,
    required String district,
    required String neighborhood,
    required String landmark,
  }) async {
    state = state.copyWith(viewState: ViewState.loading, clearError: true, clearMessage: true);
    try {
      await _repository.createOrder(
        user: user,
        serviceType: serviceType,
        description: description,
        phoneNumber: phoneNumber,
        governorate: governorate,
        district: district,
        neighborhood: neighborhood,
        landmark: landmark,
      );
      await loadCustomerOrders(user.userId);
      state = state.copyWith(message: 'تم إرسال الطلب بنجاح');
      return true;
    } catch (error) {
      state = state.copyWith(viewState: ViewState.error, errorMessage: _safeMessage(error));
      return false;
    }
  }

  Future<bool> acceptOrder(String orderId, ProviderProfileModel provider) async {
    return _mutateProviderOrder(() => _repository.acceptOrder(orderId: orderId, provider: provider), 'تم قبول الطلب');
  }

  Future<bool> rejectOrder(String orderId, ProviderProfileModel provider, String reason) async {
    return _mutateProviderOrder(() => _repository.rejectOrder(orderId: orderId, provider: provider, reason: reason), 'تم رفض الطلب');
  }

  Future<bool> markOnTheWay(String orderId) async {
    return _mutateProviderOrder(() => _repository.changeStatus(orderId: orderId, status: OrderStatus.onTheWay), 'تم تحديث الطلب إلى في الطريق');
  }

  Future<bool> completeOrder(String orderId) async {
    return _mutateProviderOrder(() => _repository.changeStatus(orderId: orderId, status: OrderStatus.completed), 'تم إكمال الطلب');
  }

  Future<bool> cancelOrder(String orderId) async {
    state = state.copyWith(viewState: ViewState.loading, clearError: true, clearMessage: true);
    try {
      await _repository.cancelOrder(orderId);
      await _refreshLast();
      state = state.copyWith(message: 'تم إلغاء الطلب');
      return true;
    } catch (error) {
      state = state.copyWith(viewState: ViewState.error, errorMessage: _safeMessage(error));
      return false;
    }
  }

  Future<bool> _mutateProviderOrder(Future<ServiceOrderModel> Function() action, String successMessage) async {
    state = state.copyWith(viewState: ViewState.loading, clearError: true, clearMessage: true);
    try {
      await action();
      await _refreshLast();
      state = state.copyWith(message: successMessage);
      return true;
    } catch (error) {
      state = state.copyWith(viewState: ViewState.error, errorMessage: _safeMessage(error));
      return false;
    }
  }

  Future<void> _refreshLast() async {
    if (_lastProviderId != null) {
      final orders = await _repository.loadForProvider(_lastProviderId!);
      state = state.copyWith(viewState: orders.isEmpty ? ViewState.empty : ViewState.success, orders: orders);
      return;
    }
    if (_lastCustomerId != null) {
      final orders = await _repository.loadForCustomer(_lastCustomerId!);
      state = state.copyWith(viewState: orders.isEmpty ? ViewState.empty : ViewState.success, orders: orders);
    }
  }

  void clearMessages() {
    state = state.copyWith(clearError: true, clearMessage: true);
  }

  String _safeMessage(Object error) {
    if (error is AppException) return error.message;
    return 'تعذر إكمال العملية. حاول مرة أخرى.';
  }
}
