import 'package:flutter/material.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../domain/order_status.dart';

class OrderStatusChip extends StatelessWidget {
  const OrderStatusChip({super.key, required this.status});

  final OrderStatus status;

  @override
  Widget build(BuildContext context) {
    final color = switch (status) {
      OrderStatus.pending => AppColors.warning,
      OrderStatus.accepted => AppColors.primary,
      OrderStatus.onTheWay => AppColors.accentGold,
      OrderStatus.completed => AppColors.success,
      OrderStatus.rejected => AppColors.error,
      OrderStatus.cancelled => AppColors.textSecondary,
    };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.14),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: color.withOpacity(0.34)),
      ),
      child: Text(status.label, style: AppTextStyles.caption.copyWith(color: color, fontWeight: FontWeight.w800)),
    );
  }
}
