import 'package:flutter/material.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/widgets/glass_container.dart';
import '../../../../routes/app_routes.dart';
import '../../domain/service_order_model.dart';
import 'order_status_chip.dart';

class ServiceOrderCard extends StatelessWidget {
  const ServiceOrderCard({super.key, required this.order, this.subtitlePrefix = 'الموقع'});

  final ServiceOrderModel order;
  final String subtitlePrefix;

  @override
  Widget build(BuildContext context) {
    return GlassContainer(
      onTap: () => Navigator.of(context).pushNamed(AppRoutes.orderDetails, arguments: order.orderId),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  color: AppColors.primary.withOpacity(0.16),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: const Icon(Icons.receipt_long_rounded, color: AppColors.primary),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(order.serviceType, style: AppTextStyles.section),
                    const SizedBox(height: 4),
                    Text(order.providerName.isEmpty ? order.customerName : order.providerName, style: AppTextStyles.caption),
                  ],
                ),
              ),
              OrderStatusChip(status: order.status),
            ],
          ),
          const SizedBox(height: 12),
          Text(order.description, style: AppTextStyles.body, maxLines: 2, overflow: TextOverflow.ellipsis),
          const SizedBox(height: 10),
          Row(
            children: [
              const Icon(Icons.location_on_outlined, size: 16, color: AppColors.textSecondary),
              const SizedBox(width: 6),
              Expanded(child: Text('$subtitlePrefix: ${order.locationText}', style: AppTextStyles.caption, maxLines: 1, overflow: TextOverflow.ellipsis)),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              const Icon(Icons.access_time_rounded, size: 16, color: AppColors.textSecondary),
              const SizedBox(width: 6),
              Text(_formatDate(order.createdAt), style: AppTextStyles.caption),
            ],
          ),
        ],
      ),
    );
  }

  String _formatDate(DateTime date) {
    final hour = date.hour.toString().padLeft(2, '0');
    final minute = date.minute.toString().padLeft(2, '0');
    return '${date.year}/${date.month.toString().padLeft(2, '0')}/${date.day.toString().padLeft(2, '0')} - $hour:$minute';
  }
}
