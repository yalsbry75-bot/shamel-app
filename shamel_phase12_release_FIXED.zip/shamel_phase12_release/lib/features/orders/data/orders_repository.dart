import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/errors/app_exception.dart';
import '../../auth/domain/user_model.dart';
import '../../notifications/data/notification_repository.dart';
import '../../notifications/domain/notification_type.dart';
import '../../provider/data/provider_repository.dart';
import '../../provider/domain/provider_profile_model.dart';
import '../../provider/domain/provider_status.dart';
import '../domain/order_status.dart';
import '../domain/service_order_model.dart';
import 'orders_service.dart';

final ordersServiceProvider = Provider<OrdersService>((ref) => FirebaseOrdersService());

final ordersRepositoryProvider = Provider<OrdersRepository>((ref) {
  return OrdersRepository(
    ref.watch(ordersServiceProvider),
    ref.watch(notificationRepositoryProvider),
    ref.watch(providerRepositoryProvider),
  );
});

class OrdersRepository {
  const OrdersRepository(this._service, this._notifications, this._providers);

  final OrdersService _service;
  final NotificationRepository _notifications;
  final ProviderRepository _providers;

  Future<List<ServiceOrderModel>> loadForCustomer(String userId) => _service.loadForCustomer(userId);
  Future<List<ServiceOrderModel>> loadForProvider(String providerId) => _service.loadForProvider(providerId);
  Future<ServiceOrderModel?> findById(String orderId) => _service.findById(orderId);

  Future<ServiceOrderModel> createOrder({
    required UserModel user,
    required String serviceType,
    required String description,
    required String phoneNumber,
    required String governorate,
    required String district,
    required String neighborhood,
    required String landmark,
  }) async {
    if (serviceType.trim().isEmpty || description.trim().isEmpty || phoneNumber.trim().isEmpty) {
      throw const AppException('نوع الخدمة والوصف ورقم التواصل مطلوبة.', code: 'INVALID_ORDER_FORM');
    }
    final provider = await _resolveTargetProvider();
    final locationText = _location(governorate, district, neighborhood, landmark);
    final now = DateTime.now();
    final order = ServiceOrderModel(
      orderId: _id('ord', user.userId),
      userId: user.userId,
      customerName: user.name.trim().isEmpty ? 'عميل شامل' : user.name.trim(),
      providerId: provider?.providerId ?? ServiceOrderModel.publicPoolProviderId,
      providerUserId: provider?.userId ?? '',
      providerName: provider?.businessName ?? 'طلبات عامة',
      serviceType: serviceType.trim(),
      description: description.trim(),
      phoneNumber: phoneNumber.trim(),
      governorate: governorate.trim(),
      district: district.trim(),
      neighborhood: neighborhood.trim(),
      landmark: landmark.trim(),
      locationText: locationText,
      createdAt: now,
      status: OrderStatus.pending,
      updatedAt: now,
    );
    final saved = await _service.create(order);
    await _notifications.create(
      userId: user.userId,
      title: 'تم إرسال طلبك',
      message: 'تم إرسال طلب ${saved.serviceType} بنجاح، وسيظهر لك تحديث الحالة هنا.',
      type: NotificationType.orderCreated,
      orderId: saved.orderId,
    );
    if (saved.providerUserId.isNotEmpty) {
      await _notifications.create(
        userId: saved.providerUserId,
        title: 'طلب جديد',
        message: 'لديك طلب جديد في ${saved.serviceType} من ${saved.customerName}.',
        type: NotificationType.orderCreated,
        orderId: saved.orderId,
      );
    }
    return saved;
  }

  Future<ServiceOrderModel> acceptOrder({required String orderId, required ProviderProfileModel provider}) async {
    final order = await _mustFind(orderId);
    if (order.status != OrderStatus.pending) {
      throw const AppException('لا يمكن قبول هذا الطلب في حالته الحالية.', code: 'INVALID_ORDER_TRANSITION');
    }
    final now = DateTime.now();
    final updated = order.copyWith(
      providerId: provider.providerId,
      providerUserId: provider.userId,
      providerName: provider.businessName.trim().isEmpty ? 'مقدم خدمة شامل' : provider.businessName.trim(),
      status: OrderStatus.accepted,
      acceptedAt: now,
      updatedAt: now,
    );
    final saved = await _service.update(updated);
    await _notifications.create(
      userId: saved.userId,
      title: 'تم قبول الطلب',
      message: 'قبل ${saved.providerName} طلب ${saved.serviceType}.',
      type: NotificationType.orderAccepted,
      orderId: saved.orderId,
    );
    return saved;
  }

  Future<ServiceOrderModel> rejectOrder({required String orderId, required ProviderProfileModel provider, required String reason}) async {
    final order = await _mustFind(orderId);
    if (order.status != OrderStatus.pending) {
      throw const AppException('لا يمكن رفض هذا الطلب في حالته الحالية.', code: 'INVALID_ORDER_TRANSITION');
    }
    final now = DateTime.now();
    final updated = order.copyWith(
      providerId: order.isPublicPool ? provider.providerId : order.providerId,
      providerUserId: order.providerUserId.isEmpty ? provider.userId : order.providerUserId,
      providerName: order.providerName == 'طلبات عامة' || order.providerName.isEmpty ? provider.businessName : order.providerName,
      status: OrderStatus.rejected,
      rejectedAt: now,
      rejectionReason: reason.trim(),
      updatedAt: now,
    );
    final saved = await _service.update(updated);
    await _notifications.create(
      userId: saved.userId,
      title: 'تم رفض الطلب',
      message: reason.trim().isEmpty ? 'تم رفض طلب ${saved.serviceType}.' : 'تم رفض طلب ${saved.serviceType}. السبب: ${reason.trim()}',
      type: NotificationType.orderRejected,
      orderId: saved.orderId,
    );
    return saved;
  }

  Future<ServiceOrderModel> changeStatus({required String orderId, required OrderStatus status}) async {
    final order = await _mustFind(orderId);
    if (!_isValidTransition(order.status, status)) {
      throw const AppException('انتقال حالة الطلب غير مسموح.', code: 'INVALID_ORDER_TRANSITION');
    }
    final now = DateTime.now();
    final updated = order.copyWith(
      status: status,
      completedAt: status == OrderStatus.completed ? now : order.completedAt,
      updatedAt: now,
    );
    final saved = await _service.update(updated);
    await _notifications.create(
      userId: saved.userId,
      title: 'تغيرت حالة الطلب',
      message: 'أصبحت حالة طلب ${saved.serviceType}: ${saved.status.label}.',
      type: NotificationType.orderStatusChanged,
      orderId: saved.orderId,
    );
    return saved;
  }

  Future<ServiceOrderModel> cancelOrder(String orderId) async {
    final order = await _mustFind(orderId);
    if (!order.status.isOpen) {
      throw const AppException('لا يمكن إلغاء طلب مغلق.', code: 'ORDER_ALREADY_CLOSED');
    }
    final now = DateTime.now();
    final saved = await _service.update(order.copyWith(status: OrderStatus.cancelled, cancelledAt: now, updatedAt: now));
    if (saved.providerUserId.isNotEmpty) {
      await _notifications.create(
        userId: saved.providerUserId,
        title: 'إلغاء طلب',
        message: 'ألغى العميل طلب ${saved.serviceType}.',
        type: NotificationType.orderCancelled,
        orderId: saved.orderId,
      );
    }
    await _notifications.create(
      userId: saved.userId,
      title: 'تم إلغاء الطلب',
      message: 'تم إلغاء طلب ${saved.serviceType}.',
      type: NotificationType.orderCancelled,
      orderId: saved.orderId,
    );
    return saved;
  }

  Future<ProviderProfileModel?> _resolveTargetProvider() async {
    final providers = await _providers.loadAllProfiles();
    final active = providers.where((item) => item.status == ProviderStatus.active && item.isCompleted).toList(growable: false);
    if (active.isNotEmpty) return active.first;
    final completed = providers.where((item) => item.isCompleted).toList(growable: false);
    if (completed.isNotEmpty) return completed.first;
    return null;
  }

  Future<ServiceOrderModel> _mustFind(String orderId) async {
    final order = await _service.findById(orderId);
    if (order == null) throw const AppException('لم يتم العثور على الطلب.', code: 'ORDER_NOT_FOUND');
    return order;
  }

  bool _isValidTransition(OrderStatus current, OrderStatus next) {
    if (current == OrderStatus.pending && next == OrderStatus.accepted) return true;
    if (current == OrderStatus.accepted && next == OrderStatus.onTheWay) return true;
    if (current == OrderStatus.onTheWay && next == OrderStatus.completed) return true;
    return false;
  }

  String _location(String governorate, String district, String neighborhood, String landmark) {
    final parts = [governorate, district, neighborhood, landmark].map((item) => item.trim()).where((item) => item.isNotEmpty).toList();
    return parts.isEmpty ? 'موقع نصي غير محدد' : parts.join('، ');
  }

  String _id(String prefix, String ownerId) {
    final safeOwner = ownerId.replaceAll(RegExp(r'[^A-Za-z0-9_]'), '');
    return '${prefix}_${safeOwner}_${DateTime.now().microsecondsSinceEpoch}';
  }
}
