import '../../../core/performance/app_performance.dart';
import '../../../core/security/rate_limiter_service.dart';
import '../domain/service_order_model.dart';

import '../../../core/database/firestore_json.dart';
import '../../../core/database/firestore_collections.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
abstract class OrdersService {
  Future<ServiceOrderModel> create(ServiceOrderModel order);
  Future<List<ServiceOrderModel>> loadForCustomer(String userId);
  Future<List<ServiceOrderModel>> loadForProvider(String providerId);
  Future<ServiceOrderModel?> findById(String orderId);
  Future<ServiceOrderModel> update(ServiceOrderModel order);
}

class FirebaseOrdersService implements OrdersService {
  FirebaseOrdersService({FirebaseFirestore? firestore, RateLimiterService? rateLimiter})
      : _firestore = firestore ?? FirebaseFirestore.instance,
        _rateLimiter = rateLimiter ?? const RateLimiterService();

  final FirebaseFirestore _firestore;
  final RateLimiterService _rateLimiter;

  @override
  Future<ServiceOrderModel> create(ServiceOrderModel order) async {
    await _rateLimiter.check(key: 'order_${order.userId}', rule: RateLimiterService.orderRule, message: 'تم إرسال طلبات كثيرة خلال وقت قصير. حاول لاحقًا.');
    await AppPerformance.trace('orders_create', () async {
      await _firestore.collection(FirestoreCollections.orders).doc(order.orderId).set(FirestoreJson.withServerAudit(order.toJson(), isCreate: true), SetOptions(merge: true));
    });
    return order;
  }

  @override
  Future<List<ServiceOrderModel>> loadForCustomer(String userId) async {
    final snapshot = await _firestore.collection(FirestoreCollections.orders).where('userId', isEqualTo: userId).orderBy('createdAt', descending: true).limit(80).get();
    return snapshot.docs.map((doc) => ServiceOrderModel.fromJson(FirestoreJson.normalize(doc.data()))).toList(growable: false);
  }

  @override
  Future<List<ServiceOrderModel>> loadForProvider(String providerId) async {
    final snapshot = await _firestore.collection(FirestoreCollections.orders).where('providerId', isEqualTo: providerId).orderBy('createdAt', descending: true).limit(80).get();
    return snapshot.docs.map((doc) => ServiceOrderModel.fromJson(FirestoreJson.normalize(doc.data()))).toList(growable: false);
  }

  @override
  Future<ServiceOrderModel?> findById(String orderId) async {
    final doc = await _firestore.collection(FirestoreCollections.orders).doc(orderId).get();
    if (!doc.exists || doc.data() == null) return null;
    return ServiceOrderModel.fromJson(FirestoreJson.normalize(doc.data()!));
  }

  @override
  Future<ServiceOrderModel> update(ServiceOrderModel order) async {
    await _firestore.collection(FirestoreCollections.orders).doc(order.orderId).set(FirestoreJson.withServerAudit(order.toJson()), SetOptions(merge: true));
    return order;
  }
}
