import '../../../core/errors/app_exception.dart';
import '../domain/favorite_item_type.dart';
import '../domain/favorite_model.dart';

import '../../../core/database/firestore_json.dart';
import '../../../core/database/firestore_collections.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
abstract class FavoritesService {
  Future<List<FavoriteModel>> loadForUser(String userId);
  Future<FavoriteModel?> find({required String userId, required String itemId, required FavoriteItemType itemType});
  Future<FavoriteModel> save(FavoriteModel favorite);
  Future<void> remove({required String userId, required String itemId, required FavoriteItemType itemType});
}

class FirebaseFavoritesService implements FavoritesService {
  FirebaseFavoritesService({FirebaseFirestore? firestore}) : _firestore = firestore ?? FirebaseFirestore.instance;
  final FirebaseFirestore _firestore;

  @override
  Future<List<FavoriteModel>> loadForUser(String userId) async {
    final snapshot = await _firestore.collection(FirestoreCollections.favorites).where('userId', isEqualTo: userId).orderBy('createdAt', descending: true).limit(100).get();
    return snapshot.docs.map((doc) => FavoriteModel.fromJson(FirestoreJson.normalize(doc.data()))).toList(growable: false);
  }

  @override
  Future<FavoriteModel?> find({required String userId, required String itemId, required FavoriteItemType itemType}) async {
    final snapshot = await _firestore.collection(FirestoreCollections.favorites).where('userId', isEqualTo: userId).where('itemId', isEqualTo: itemId).where('itemType', isEqualTo: itemType.value).limit(1).get();
    if (snapshot.docs.isEmpty) return null;
    return FavoriteModel.fromJson(FirestoreJson.normalize(snapshot.docs.first.data()));
  }

  @override
  Future<FavoriteModel> save(FavoriteModel favorite) async {
    if (favorite.userId.trim().isEmpty || favorite.itemId.trim().isEmpty) {
      throw const AppException('الجلسة غير متاحة لحفظ المفضلة.', code: 'INVALID_FAVORITE');
    }
    await _firestore.collection(FirestoreCollections.favorites).doc(favorite.favoriteId).set(FirestoreJson.withServerAudit(favorite.toJson(), isCreate: true), SetOptions(merge: true));
    return favorite;
  }

  @override
  Future<void> remove({required String userId, required String itemId, required FavoriteItemType itemType}) async {
    final snapshot = await _firestore.collection(FirestoreCollections.favorites).where('userId', isEqualTo: userId).where('itemId', isEqualTo: itemId).where('itemType', isEqualTo: itemType.value).limit(10).get();
    final batch = _firestore.batch();
    for (final doc in snapshot.docs) {
      batch.delete(doc.reference);
    }
    await batch.commit();
  }
}
