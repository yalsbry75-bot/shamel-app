import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../search/domain/search_result_model.dart';
import '../../search/domain/search_result_type.dart';
import '../domain/favorite_item_type.dart';
import '../domain/favorite_model.dart';
import 'favorites_service.dart';

final favoritesServiceProvider = Provider<FavoritesService>((ref) => FirebaseFavoritesService());

final favoritesRepositoryProvider = Provider<FavoritesRepository>((ref) {
  return FavoritesRepository(ref.watch(favoritesServiceProvider));
});

class FavoritesRepository {
  const FavoritesRepository(this._service);

  final FavoritesService _service;

  Future<List<FavoriteModel>> loadForUser(String userId) => _service.loadForUser(userId);

  Future<List<FavoriteModel>> toggleFromResult({required String userId, required SearchResultModel result}) async {
    final itemType = _toFavoriteType(result.type);
    final existing = await _service.find(userId: userId, itemId: result.itemId, itemType: itemType);
    if (existing == null) {
      await _service.save(
        FavoriteModel(
          favoriteId: 'fav_${userId}_${result.itemId}_${DateTime.now().microsecondsSinceEpoch}',
          userId: userId,
          itemId: result.itemId,
          itemType: itemType,
          createdAt: DateTime.now(),
          title: result.title,
          subtitle: result.subtitle,
          locationText: result.locationText,
          imageUrl: result.imageUrl,
        ),
      );
    } else {
      await _service.remove(userId: userId, itemId: result.itemId, itemType: itemType);
    }
    return loadForUser(userId);
  }

  Future<List<FavoriteModel>> toggleSnapshot({
    required String userId,
    required String itemId,
    required FavoriteItemType itemType,
    required String title,
    required String subtitle,
    required String locationText,
    String imageUrl = '',
  }) async {
    final existing = await _service.find(userId: userId, itemId: itemId, itemType: itemType);
    if (existing == null) {
      await _service.save(
        FavoriteModel(
          favoriteId: 'fav_${userId}_${itemId}_${DateTime.now().microsecondsSinceEpoch}',
          userId: userId,
          itemId: itemId,
          itemType: itemType,
          createdAt: DateTime.now(),
          title: title,
          subtitle: subtitle,
          locationText: locationText,
          imageUrl: imageUrl,
        ),
      );
    } else {
      await _service.remove(userId: userId, itemId: itemId, itemType: itemType);
    }
    return loadForUser(userId);
  }

  Future<List<FavoriteModel>> remove({required String userId, required String itemId, required FavoriteItemType itemType}) async {
    await _service.remove(userId: userId, itemId: itemId, itemType: itemType);
    return loadForUser(userId);
  }

  FavoriteItemType _toFavoriteType(SearchResultType type) {
    switch (type) {
      case SearchResultType.ad:
        return FavoriteItemType.ad;
      case SearchResultType.provider:
      case SearchResultType.service:
        return FavoriteItemType.provider;
    }
  }
}
