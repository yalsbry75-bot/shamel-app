enum FavoriteItemType { provider, ad }

extension FavoriteItemTypeX on FavoriteItemType {
  String get value {
    switch (this) {
      case FavoriteItemType.provider:
        return 'provider';
      case FavoriteItemType.ad:
        return 'ad';
    }
  }

  String get label {
    switch (this) {
      case FavoriteItemType.provider:
        return 'مقدم خدمة';
      case FavoriteItemType.ad:
        return 'إعلان';
    }
  }

  static FavoriteItemType fromValue(String value) {
    switch (value) {
      case 'ad':
        return FavoriteItemType.ad;
      default:
        return FavoriteItemType.provider;
    }
  }
}
