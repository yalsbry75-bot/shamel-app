import '../../../core/utils/ui_state.dart';
import 'favorite_item_type.dart';
import 'favorite_model.dart';

class FavoritesState {
  const FavoritesState({
    this.viewState = ViewState.initial,
    this.favorites = const [],
    this.message,
    this.errorMessage,
  });

  final ViewState viewState;
  final List<FavoriteModel> favorites;
  final String? message;
  final String? errorMessage;

  List<FavoriteModel> get providers => favorites.where((item) => item.itemType == FavoriteItemType.provider).toList(growable: false);
  List<FavoriteModel> get ads => favorites.where((item) => item.itemType == FavoriteItemType.ad).toList(growable: false);

  bool isFavorite({required String userId, required String itemId, required FavoriteItemType itemType}) {
    return favorites.any((item) => item.userId == userId && item.itemId == itemId && item.itemType == itemType);
  }

  FavoritesState copyWith({
    ViewState? viewState,
    List<FavoriteModel>? favorites,
    String? message,
    bool clearMessage = false,
    String? errorMessage,
    bool clearError = false,
  }) {
    return FavoritesState(
      viewState: viewState ?? this.viewState,
      favorites: favorites ?? this.favorites,
      message: clearMessage ? null : message ?? this.message,
      errorMessage: clearError ? null : errorMessage ?? this.errorMessage,
    );
  }
}
