import 'favorite_item_type.dart';

class FavoriteModel {
  const FavoriteModel({
    required this.favoriteId,
    required this.userId,
    required this.itemId,
    required this.itemType,
    required this.createdAt,
    this.title = '',
    this.subtitle = '',
    this.locationText = '',
    this.imageUrl = '',
  });

  final String favoriteId;
  final String userId;
  final String itemId;
  final FavoriteItemType itemType;
  final DateTime createdAt;
  final String title;
  final String subtitle;
  final String locationText;
  final String imageUrl;

  factory FavoriteModel.fromJson(Map<String, dynamic> json) {
    return FavoriteModel(
      favoriteId: json['favoriteId'] as String? ?? '',
      userId: json['userId'] as String? ?? '',
      itemId: json['itemId'] as String? ?? '',
      itemType: FavoriteItemTypeX.fromValue(json['itemType'] as String? ?? 'provider'),
      createdAt: DateTime.tryParse(json['createdAt'] as String? ?? '') ?? DateTime.fromMillisecondsSinceEpoch(0),
      title: json['title'] as String? ?? '',
      subtitle: json['subtitle'] as String? ?? '',
      locationText: json['locationText'] as String? ?? '',
      imageUrl: json['imageUrl'] as String? ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'favoriteId': favoriteId,
      'userId': userId,
      'itemId': itemId,
      'itemType': itemType.value,
      'createdAt': createdAt.toIso8601String(),
      'title': title,
      'subtitle': subtitle,
      'locationText': locationText,
      'imageUrl': imageUrl,
    };
  }

  FavoriteModel copyWith({
    String? favoriteId,
    String? userId,
    String? itemId,
    FavoriteItemType? itemType,
    DateTime? createdAt,
    String? title,
    String? subtitle,
    String? locationText,
    String? imageUrl,
  }) {
    return FavoriteModel(
      favoriteId: favoriteId ?? this.favoriteId,
      userId: userId ?? this.userId,
      itemId: itemId ?? this.itemId,
      itemType: itemType ?? this.itemType,
      createdAt: createdAt ?? this.createdAt,
      title: title ?? this.title,
      subtitle: subtitle ?? this.subtitle,
      locationText: locationText ?? this.locationText,
      imageUrl: imageUrl ?? this.imageUrl,
    );
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        other is FavoriteModel &&
            runtimeType == other.runtimeType &&
            favoriteId == other.favoriteId &&
            userId == other.userId &&
            itemId == other.itemId &&
            itemType == other.itemType &&
            createdAt == other.createdAt &&
            title == other.title &&
            subtitle == other.subtitle &&
            locationText == other.locationText &&
            imageUrl == other.imageUrl;
  }

  @override
  int get hashCode => Object.hash(favoriteId, userId, itemId, itemType, createdAt, title, subtitle, locationText, imageUrl);
}
