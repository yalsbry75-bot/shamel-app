import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/errors/app_exception.dart';
import '../../../../core/utils/ui_state.dart';
import '../../../search/domain/search_result_model.dart';
import '../../data/favorites_repository.dart';
import '../../domain/favorite_item_type.dart';
import '../../domain/favorites_state.dart';

final favoritesControllerProvider = StateNotifierProvider<FavoritesController, FavoritesState>((ref) {
  return FavoritesController(ref.watch(favoritesRepositoryProvider));
});

class FavoritesController extends StateNotifier<FavoritesState> {
  FavoritesController(this._repository) : super(const FavoritesState());

  final FavoritesRepository _repository;

  Future<void> load(String userId) async {
    if (userId.trim().isEmpty) {
      state = const FavoritesState(viewState: ViewState.empty);
      return;
    }
    state = state.copyWith(viewState: ViewState.loading, clearError: true, clearMessage: true);
    try {
      final favorites = await _repository.loadForUser(userId);
      state = state.copyWith(viewState: favorites.isEmpty ? ViewState.empty : ViewState.success, favorites: favorites);
    } catch (error) {
      state = state.copyWith(viewState: ViewState.error, errorMessage: _safeMessage(error));
    }
  }

  Future<void> toggleResult({required String userId, required SearchResultModel result}) async {
    if (userId.trim().isEmpty) {
      state = state.copyWith(errorMessage: 'سجّل الدخول أولًا لحفظ المفضلة.');
      return;
    }
    try {
      final wasFavorite = state.favorites.any((item) => item.userId == userId && item.itemId == result.itemId);
      final favorites = await _repository.toggleFromResult(userId: userId, result: result);
      state = state.copyWith(
        viewState: favorites.isEmpty ? ViewState.empty : ViewState.success,
        favorites: favorites,
        message: wasFavorite ? 'تمت الإزالة من المفضلة' : 'تم الحفظ في المفضلة',
      );
    } catch (error) {
      state = state.copyWith(errorMessage: _safeMessage(error));
    }
  }

  Future<void> toggleSnapshot({
    required String userId,
    required String itemId,
    required FavoriteItemType itemType,
    required String title,
    required String subtitle,
    required String locationText,
    String imageUrl = '',
  }) async {
    if (userId.trim().isEmpty) {
      state = state.copyWith(errorMessage: 'سجّل الدخول أولًا لحفظ المفضلة.');
      return;
    }
    try {
      final favorites = await _repository.toggleSnapshot(
        userId: userId,
        itemId: itemId,
        itemType: itemType,
        title: title,
        subtitle: subtitle,
        locationText: locationText,
        imageUrl: imageUrl,
      );
      state = state.copyWith(viewState: favorites.isEmpty ? ViewState.empty : ViewState.success, favorites: favorites, message: 'تم تحديث المفضلة');
    } catch (error) {
      state = state.copyWith(errorMessage: _safeMessage(error));
    }
  }

  Future<void> remove({required String userId, required String itemId, required FavoriteItemType itemType}) async {
    try {
      final favorites = await _repository.remove(userId: userId, itemId: itemId, itemType: itemType);
      state = state.copyWith(viewState: favorites.isEmpty ? ViewState.empty : ViewState.success, favorites: favorites, message: 'تم الحذف من المفضلة');
    } catch (error) {
      state = state.copyWith(errorMessage: _safeMessage(error));
    }
  }

  void clearMessages() {
    state = state.copyWith(clearError: true, clearMessage: true);
  }

  String _safeMessage(Object error) {
    if (error is AppException) return error.message;
    return 'تعذر تحديث المفضلة. حاول مرة أخرى.';
  }
}
