import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/widgets/glass_container.dart';
import '../../../../routes/app_routes.dart';
import '../../../../shared/components/section_header.dart';
import '../../../ads/presentation/controllers/ads_controller.dart';
import '../../data/search_repository.dart';
import '../../domain/search_result_model.dart';

class DiscoverySuggestionsSection extends ConsumerStatefulWidget {
  const DiscoverySuggestionsSection({super.key});

  @override
  ConsumerState<DiscoverySuggestionsSection> createState() => _DiscoverySuggestionsSectionState();
}

class _DiscoverySuggestionsSectionState extends ConsumerState<DiscoverySuggestionsSection> {
  late Future<List<List<SearchResultModel>>> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
    Future.microtask(() => ref.read(adsControllerProvider.notifier).loadAds());
  }

  Future<List<List<SearchResultModel>>> _load() async {
    final repository = ref.read(searchRepositoryProvider);
    final topRated = await repository.topRated();
    final mostRequested = await repository.mostRequested();
    final newest = await repository.newest();
    return [topRated, mostRequested, newest];
  }

  @override
  Widget build(BuildContext context) {
    final offers = ref.watch(adsControllerProvider).offers;
    final importantAds = ref.watch(adsControllerProvider).bannerAds;
    return FutureBuilder<List<List<SearchResultModel>>>(
      future: _future,
      builder: (context, snapshot) {
        final groups = snapshot.data ?? const [<SearchResultModel>[], <SearchResultModel>[], <SearchResultModel>[]];
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _ResultStrip(title: 'الأعلى تقييمًا', icon: Icons.star_rounded, results: groups[0], onMore: () => Navigator.of(context).pushNamed(AppRoutes.search)),
            const SizedBox(height: 18),
            _ResultStrip(title: 'الأكثر طلبًا', icon: Icons.local_fire_department_outlined, results: groups[1], onMore: () => Navigator.of(context).pushNamed(AppRoutes.search)),
            const SizedBox(height: 18),
            _ResultStrip(title: 'خدمات جديدة', icon: Icons.new_releases_outlined, results: groups[2], onMore: () => Navigator.of(context).pushNamed(AppRoutes.search)),
            const SizedBox(height: 18),
            SectionHeader(title: 'عروض مميزة', actionLabel: 'عرض الكل', onAction: () => Navigator.of(context).pushNamed(AppRoutes.ads)),
            const SizedBox(height: 10),
            _AdMiniStrip(items: offers.take(5).map((ad) => _MiniAd(ad.adId, ad.title, ad.locationText, ad.effectiveDiscountPercent)).toList(growable: false)),
            const SizedBox(height: 18),
            SectionHeader(title: 'إعلانات مهمة', actionLabel: 'Marketplace', onAction: () => Navigator.of(context).pushNamed(AppRoutes.ads)),
            const SizedBox(height: 10),
            _AdMiniStrip(items: importantAds.take(5).map((ad) => _MiniAd(ad.adId, ad.title, ad.locationText, ad.effectiveDiscountPercent)).toList(growable: false)),
          ],
        );
      },
    );
  }
}

class _ResultStrip extends StatelessWidget {
  const _ResultStrip({required this.title, required this.icon, required this.results, required this.onMore});

  final String title;
  final IconData icon;
  final List<SearchResultModel> results;
  final VoidCallback onMore;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SectionHeader(title: title, actionLabel: 'بحث', onAction: onMore),
        const SizedBox(height: 10),
        SizedBox(
          height: 112,
          child: results.isEmpty
              ? GlassContainer(child: Center(child: Text('ستظهر الاقتراحات بعد إضافة مقدمي خدمات أو إعلانات.', style: AppTextStyles.caption)))
              : ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: results.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 10),
                  itemBuilder: (context, index) {
                    final result = results[index];
                    return SizedBox(
                      width: 245,
                      child: GlassContainer(
                        onTap: () => Navigator.of(context).pushNamed(AppRoutes.search, arguments: {'query': result.title}),
                        child: Row(
                          children: [
                            Container(width: 44, height: 44, decoration: BoxDecoration(color: AppColors.primary.withOpacity(0.16), borderRadius: BorderRadius.circular(16)), child: Icon(icon, color: AppColors.primary)),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(result.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTextStyles.body.copyWith(fontWeight: FontWeight.w900)),
                                  const SizedBox(height: 4),
                                  Text(result.locationText, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTextStyles.caption),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }
}

class _AdMiniStrip extends StatelessWidget {
  const _AdMiniStrip({required this.items});

  final List<_MiniAd> items;

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) return GlassContainer(child: Center(child: Text('لا توجد إعلانات متاحة حاليًا.', style: AppTextStyles.caption)));
    return SizedBox(
      height: 104,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: items.length,
        separatorBuilder: (_, __) => const SizedBox(width: 10),
        itemBuilder: (context, index) {
          final item = items[index];
          return SizedBox(
            width: 230,
            child: GlassContainer(
              onTap: () => Navigator.of(context).pushNamed(AppRoutes.adDetails, arguments: item.adId),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(item.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTextStyles.body.copyWith(fontWeight: FontWeight.w900)),
                  const SizedBox(height: 8),
                  Text(item.location, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTextStyles.caption),
                  if (item.discount > 0) ...[
                    const SizedBox(height: 8),
                    Text('${item.discount}% خصم', style: AppTextStyles.caption.copyWith(color: AppColors.accentGold, fontWeight: FontWeight.w900)),
                  ],
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class _MiniAd {
  const _MiniAd(this.adId, this.title, this.location, this.discount);
  final String adId;
  final String title;
  final String location;
  final int discount;
}
