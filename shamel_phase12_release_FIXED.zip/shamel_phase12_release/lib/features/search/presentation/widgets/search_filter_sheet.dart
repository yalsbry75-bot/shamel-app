import 'package:flutter/material.dart';

import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/widgets/shamel_button.dart';
import '../../../../core/widgets/shamel_text_field.dart';
import '../../domain/search_filter_model.dart';
import '../../domain/search_sort_option.dart';

class SearchFilterSheet extends StatefulWidget {
  const SearchFilterSheet({super.key, required this.initialFilters, required this.onApply, required this.onClear});

  final SearchFilterModel initialFilters;
  final ValueChanged<SearchFilterModel> onApply;
  final VoidCallback onClear;

  @override
  State<SearchFilterSheet> createState() => _SearchFilterSheetState();
}

class _SearchFilterSheetState extends State<SearchFilterSheet> {
  late final TextEditingController _governorate;
  late final TextEditingController _district;
  late final TextEditingController _serviceType;
  late final TextEditingController _minPrice;
  late final TextEditingController _maxPrice;
  late SearchSortOption _sortOption;

  @override
  void initState() {
    super.initState();
    _governorate = TextEditingController(text: widget.initialFilters.governorate);
    _district = TextEditingController(text: widget.initialFilters.district);
    _serviceType = TextEditingController(text: widget.initialFilters.serviceType);
    _minPrice = TextEditingController(text: widget.initialFilters.minPrice?.toString() ?? '');
    _maxPrice = TextEditingController(text: widget.initialFilters.maxPrice?.toString() ?? '');
    _sortOption = widget.initialFilters.sortOption;
  }

  @override
  void dispose() {
    _governorate.dispose();
    _district.dispose();
    _serviceType.dispose();
    _minPrice.dispose();
    _maxPrice.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.only(left: 20, right: 20, top: 18, bottom: MediaQuery.of(context).viewInsets.bottom + 20),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('الفلاتر المتقدمة', style: AppTextStyles.title),
              const SizedBox(height: 16),
              ShamelTextField(hintText: 'المحافظة', controller: _governorate, prefixIcon: Icons.location_city_outlined),
              const SizedBox(height: 12),
              ShamelTextField(hintText: 'المديرية', controller: _district, prefixIcon: Icons.place_outlined),
              const SizedBox(height: 12),
              ShamelTextField(hintText: 'نوع الخدمة', controller: _serviceType, prefixIcon: Icons.design_services_outlined),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(child: ShamelTextField(hintText: 'أقل سعر', controller: _minPrice, keyboardType: TextInputType.number, prefixIcon: Icons.price_change_outlined)),
                  const SizedBox(width: 10),
                  Expanded(child: ShamelTextField(hintText: 'أعلى سعر', controller: _maxPrice, keyboardType: TextInputType.number, prefixIcon: Icons.sell_outlined)),
                ],
              ),
              const SizedBox(height: 14),
              DropdownButtonFormField<SearchSortOption>(
                value: _sortOption,
                decoration: const InputDecoration(prefixIcon: Icon(Icons.sort_rounded), hintText: 'الترتيب'),
                items: SearchSortOption.values.map((item) => DropdownMenuItem(value: item, child: Text(item.label))).toList(),
                onChanged: (value) => setState(() => _sortOption = value ?? SearchSortOption.smart),
              ),
              const SizedBox(height: 18),
              ShamelButton.primary(
                label: 'تطبيق الفلاتر',
                icon: Icons.tune_rounded,
                onPressed: () {
                  widget.onApply(
                    widget.initialFilters.copyWith(
                      governorate: _governorate.text.trim(),
                      district: _district.text.trim(),
                      serviceType: _serviceType.text.trim(),
                      minPrice: double.tryParse(_minPrice.text.trim()),
                      clearMinPrice: _minPrice.text.trim().isEmpty,
                      maxPrice: double.tryParse(_maxPrice.text.trim()),
                      clearMaxPrice: _maxPrice.text.trim().isEmpty,
                      sortOption: _sortOption,
                    ),
                  );
                  Navigator.of(context).pop();
                },
              ),
              const SizedBox(height: 10),
              ShamelButton.secondary(
                label: 'مسح الفلاتر',
                icon: Icons.filter_alt_off_outlined,
                onPressed: () {
                  widget.onClear();
                  Navigator.of(context).pop();
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
