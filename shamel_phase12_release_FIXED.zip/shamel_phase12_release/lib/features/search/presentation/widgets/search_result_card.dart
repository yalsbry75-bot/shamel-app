import 'package:flutter/material.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/widgets/glass_container.dart';
import '../../domain/search_result_model.dart';
import '../../domain/search_result_type.dart';

class SearchResultCard extends StatelessWidget {
  const SearchResultCard({
    super.key,
    required this.result,
    required this.isFavorite,
    required this.onTap,
    required this.onFavorite,
  });

  final SearchResultModel result;
  final bool isFavorite;
  final VoidCallback onTap;
  final VoidCallback onFavorite;

  @override
  Widget build(BuildContext context) {
    return GlassContainer(
      onTap: onTap,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              _LeadingIcon(result: result),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(child: Text(result.title, style: AppTextStyles.body.copyWith(fontWeight: FontWeight.w900))),
                        _TypeChip(type: result.type),
                      ],
                    ),
                    const SizedBox(height: 5),
                    Text(result.subtitle, style: AppTextStyles.caption),
                  ],
                ),
              ),
              IconButton(
                onPressed: onFavorite,
                icon: Icon(isFavorite ? Icons.favorite_rounded : Icons.favorite_border_rounded, color: isFavorite ? AppColors.accentGold : AppColors.textSecondary),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(result.description.isEmpty ? 'تفاصيل مختصرة متاحة عند فتح العنصر.' : result.description, maxLines: 2, overflow: TextOverflow.ellipsis, style: AppTextStyles.caption.copyWith(height: 1.5)),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _MetaChip(icon: Icons.place_outlined, label: result.locationText),
              if (result.rating > 0) _MetaChip(icon: Icons.star_rounded, label: '${result.rating.toStringAsFixed(1)} (${result.ratingCount})', gold: true),
              if (result.hasPrice) _MetaChip(icon: Icons.sell_outlined, label: _price(result.price!)),
              if (result.hasDiscount) _MetaChip(icon: Icons.local_offer_outlined, label: '${result.discountPercent}% خصم', gold: true),
            ],
          ),
        ],
      ),
    );
  }

  String _price(double value) {
    final clean = value % 1 == 0 ? value.toStringAsFixed(0) : value.toStringAsFixed(2);
    return '$clean ر.ي';
  }
}

class _LeadingIcon extends StatelessWidget {
  const _LeadingIcon({required this.result});

  final SearchResultModel result;

  @override
  Widget build(BuildContext context) {
    final icon = switch (result.type) {
      SearchResultType.provider => Icons.storefront_outlined,
      SearchResultType.service => Icons.design_services_outlined,
      SearchResultType.ad => Icons.campaign_outlined,
    };
    return Container(
      width: 54,
      height: 54,
      decoration: BoxDecoration(
        color: AppColors.primary.withOpacity(0.15),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.border),
      ),
      child: Icon(icon, color: AppColors.primary),
    );
  }
}

class _TypeChip extends StatelessWidget {
  const _TypeChip({required this.type});

  final SearchResultType type;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(color: AppColors.surfaceHigh.withOpacity(0.7), borderRadius: BorderRadius.circular(999), border: Border.all(color: AppColors.border)),
      child: Text(type.label, style: AppTextStyles.caption.copyWith(fontWeight: FontWeight.w800)),
    );
  }
}

class _MetaChip extends StatelessWidget {
  const _MetaChip({required this.icon, required this.label, this.gold = false});

  final IconData icon;
  final String label;
  final bool gold;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
      decoration: BoxDecoration(color: (gold ? AppColors.accentGold : AppColors.surfaceHigh).withOpacity(0.16), borderRadius: BorderRadius.circular(999)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: gold ? AppColors.accentGold : AppColors.textSecondary),
          const SizedBox(width: 5),
          Text(label, style: AppTextStyles.caption.copyWith(color: gold ? AppColors.accentGold : AppColors.textSecondary)),
        ],
      ),
    );
  }
}
