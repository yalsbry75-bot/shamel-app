import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/errors/app_exception.dart';
import '../../../../core/utils/ui_state.dart';
import '../../data/search_repository.dart';
import '../../domain/search_filter_model.dart';
import '../../domain/search_sort_option.dart';
import '../../domain/search_state.dart';

final smartSearchControllerProvider = StateNotifierProvider<SmartSearchController, SearchState>((ref) {
  return SmartSearchController(ref.watch(searchRepositoryProvider));
});

class SmartSearchController extends StateNotifier<SearchState> {
  SmartSearchController(this._repository) : super(const SearchState());

  final SearchRepository _repository;

  Future<void> initialize({required String userId, String initialCategoryId = ''}) async {
    final recent = await _repository.loadRecentSearches(userId);
    final filters = initialCategoryId.isEmpty ? state.filters : state.filters.copyWith(categoryId: initialCategoryId);
    state = state.copyWith(recentSearches: recent, filters: filters);
    await search(userId: userId, query: state.query, filters: filters, saveQuery: false);
  }

  Future<void> search({required String userId, required String query, SearchFilterModel? filters, bool saveQuery = true}) async {
    final activeFilters = filters ?? state.filters;
    state = state.copyWith(
      viewState: ViewState.loading,
      query: query,
      filters: activeFilters,
      page: 1,
      clearError: true,
      clearMessage: true,
      clearDidYouMean: true,
    );
    try {
      final page = await _repository.search(query: query, filters: activeFilters, page: 1);
      final recent = saveQuery && query.trim().isNotEmpty ? await _repository.saveRecentSearch(userId: userId, query: query) : state.recentSearches;
      state = state.copyWith(
        viewState: page.results.isEmpty ? ViewState.empty : ViewState.success,
        results: page.results,
        suggestions: page.suggestions,
        recentSearches: recent,
        didYouMean: page.didYouMean,
        hasMore: page.hasMore,
        page: 1,
      );
    } catch (error) {
      state = state.copyWith(viewState: ViewState.error, errorMessage: _safeMessage(error));
    }
  }

  Future<void> liveSearch({required String userId, required String query}) {
    return search(userId: userId, query: query, saveQuery: false);
  }

  Future<void> loadMore({required String userId}) async {
    if (!state.hasMore || state.isLoading) return;
    final nextPage = state.page + 1;
    state = state.copyWith(viewState: ViewState.loading, clearError: true, clearMessage: true);
    try {
      final page = await _repository.search(query: state.query, filters: state.filters, page: nextPage);
      state = state.copyWith(
        viewState: page.results.isEmpty ? ViewState.empty : ViewState.success,
        results: page.results,
        suggestions: page.suggestions,
        didYouMean: page.didYouMean,
        hasMore: page.hasMore,
        page: nextPage,
      );
    } catch (error) {
      state = state.copyWith(viewState: ViewState.error, errorMessage: _safeMessage(error));
    }
  }

  Future<void> applyFilters({
    required String userId,
    String? governorate,
    String? district,
    String? serviceType,
    String? categoryId,
    double? minPrice,
    bool clearMinPrice = false,
    double? maxPrice,
    bool clearMaxPrice = false,
    SearchSortOption? sortOption,
  }) async {
    final filters = state.filters.copyWith(
      governorate: governorate,
      district: district,
      serviceType: serviceType,
      categoryId: categoryId,
      minPrice: minPrice,
      clearMinPrice: clearMinPrice,
      maxPrice: maxPrice,
      clearMaxPrice: clearMaxPrice,
      sortOption: sortOption,
    );
    await search(userId: userId, query: state.query, filters: filters, saveQuery: false);
  }

  Future<void> clearFilters(String userId) async {
    await search(userId: userId, query: state.query, filters: const SearchFilterModel(), saveQuery: false);
  }

  Future<void> useSuggestion({required String userId, required String suggestion}) async {
    await search(userId: userId, query: suggestion, saveQuery: true);
  }

  Future<void> clearRecent(String userId) async {
    await _repository.clearRecentSearches(userId);
    state = state.copyWith(recentSearches: const [], clearMessage: true);
  }

  String _safeMessage(Object error) {
    if (error is AppException) return error.message;
    return 'تعذر تنفيذ البحث. حاول مرة أخرى.';
  }
}
