import '../../ads/data/ads_repository.dart';
import '../../ads/domain/ad_model.dart';
import '../../provider/data/provider_repository.dart';
import '../../provider/domain/provider_profile_model.dart';
import '../../provider/domain/provider_service_item_model.dart';

import '../../../core/database/firestore_json.dart';
import '../../../core/database/firestore_collections.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
class DiscoveryIndexData {
  const DiscoveryIndexData({required this.providers, required this.services, required this.ads});

  final List<ProviderProfileModel> providers;
  final List<ProviderServiceItemModel> services;
  final List<AdModel> ads;
}

abstract class SearchService {
  Future<DiscoveryIndexData> loadIndex();
  Future<List<String>> loadRecentSearches(String userId);
  Future<List<String>> saveRecentSearch({required String userId, required String query});
  Future<void> clearRecentSearches(String userId);
}

class FirebaseSearchService implements SearchService {
  FirebaseSearchService({
    required AdsRepository adsRepository,
    required ProviderRepository providerRepository,
    FirebaseFirestore? firestore,
  })  : _adsRepository = adsRepository,
        _providerRepository = providerRepository,
        _firestore = firestore ?? FirebaseFirestore.instance;

  static DiscoveryIndexData? _cachedIndex;
  static DateTime? _cacheTime;
  final AdsRepository _adsRepository;
  final ProviderRepository _providerRepository;
  final FirebaseFirestore _firestore;

  @override
  Future<DiscoveryIndexData> loadIndex() async {
    final cache = _cachedIndex;
    final cacheTime = _cacheTime;
    if (cache != null && cacheTime != null && DateTime.now().difference(cacheTime) < const Duration(seconds: 45)) return cache;
    final providers = await _providerRepository.loadAllProfiles();
    final services = await _providerRepository.loadAllServices();
    final ads = await _adsRepository.loadAll();
    final index = DiscoveryIndexData(providers: providers, services: services, ads: ads);
    _cachedIndex = index;
    _cacheTime = DateTime.now();
    return index;
  }

  @override
  Future<List<String>> loadRecentSearches(String userId) async {
    if (userId.trim().isEmpty) return const [];
    final doc = await _firestore.collection(FirestoreCollections.recentSearches).doc(userId).get();
    if (!doc.exists || doc.data() == null) return const [];
    final data = FirestoreJson.normalize(doc.data()!);
    return (data['queries'] as List<dynamic>? ?? const []).map((item) => item.toString()).where((item) => item.trim().isNotEmpty).take(8).toList(growable: false);
  }

  @override
  Future<List<String>> saveRecentSearch({required String userId, required String query}) async {
    final normalized = query.trim();
    if (userId.trim().isEmpty || normalized.isEmpty) return loadRecentSearches(userId);
    final current = await loadRecentSearches(userId);
    final updated = <String>[normalized, ...current.where((item) => item != normalized)].take(8).toList(growable: false);
    await _firestore.collection(FirestoreCollections.recentSearches).doc(userId).set({'userId': userId, 'queries': updated, 'updatedAtServer': FieldValue.serverTimestamp()}, SetOptions(merge: true));
    return updated;
  }

  @override
  Future<void> clearRecentSearches(String userId) async {
    if (userId.trim().isEmpty) return;
    await _firestore.collection(FirestoreCollections.recentSearches).doc(userId).delete();
  }
}
