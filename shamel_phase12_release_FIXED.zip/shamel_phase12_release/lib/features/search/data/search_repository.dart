import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../ads/data/ads_repository.dart';
import '../../provider/data/provider_repository.dart';
import '../../provider/domain/provider_profile_model.dart';
import '../domain/search_filter_model.dart';
import '../domain/search_result_model.dart';
import '../domain/search_result_type.dart';
import '../domain/search_sort_option.dart';
import 'search_service.dart';

final searchServiceProvider = Provider<SearchService>((ref) {
  return FirebaseSearchService(
    adsRepository: ref.watch(adsRepositoryProvider),
    providerRepository: ref.watch(providerRepositoryProvider),
  );
});

final searchRepositoryProvider = Provider<SearchRepository>((ref) {
  return SearchRepository(ref.watch(searchServiceProvider));
});

class SearchPage {
  const SearchPage({required this.results, required this.suggestions, required this.didYouMean, required this.hasMore, required this.totalCount});

  final List<SearchResultModel> results;
  final List<String> suggestions;
  final String? didYouMean;
  final bool hasMore;
  final int totalCount;
}

class SearchRepository {
  const SearchRepository(this._service);

  static const int pageSize = 10;
  final SearchService _service;

  Future<List<String>> loadRecentSearches(String userId) => _service.loadRecentSearches(userId);
  Future<List<String>> saveRecentSearch({required String userId, required String query}) => _service.saveRecentSearch(userId: userId, query: query);
  Future<void> clearRecentSearches(String userId) => _service.clearRecentSearches(userId);

  Future<SearchPage> search({required String query, required SearchFilterModel filters, int page = 1}) async {
    final index = await _service.loadIndex();
    final normalizedQuery = _normalize(query);
    final providersById = <String, ProviderProfileModel>{for (final provider in index.providers) provider.providerId: provider};
    final results = <SearchResultModel>[];

    for (final provider in index.providers) {
      results.add(_providerToResult(provider, normalizedQuery));
    }

    for (final service in index.services) {
      final provider = providersById[service.providerId];
      results.add(_serviceToResult(service, provider, normalizedQuery));
    }

    for (final ad in index.ads.where((item) => item.isActive || item.status.value == 'pending')) {
      results.add(_adToResult(ad, normalizedQuery));
    }

    var filtered = results.where((item) => _matchesQuery(item, normalizedQuery)).where((item) => _matchesFilters(item, filters)).toList(growable: false);
    filtered = _sort(filtered, filters.sortOption);

    final total = filtered.length;
    final safePage = page < 1 ? 1 : page;
    final end = (safePage * pageSize).clamp(0, total);
    final visible = filtered.take(end).toList(growable: false);
    final suggestions = _suggestions(results, normalizedQuery, filters);
    final didYouMean = _didYouMean(normalizedQuery, suggestions);
    return SearchPage(results: visible, suggestions: suggestions, didYouMean: didYouMean, hasMore: end < total, totalCount: total);
  }

  Future<List<SearchResultModel>> topRated() async {
    final page = await search(query: '', filters: const SearchFilterModel(sortOption: SearchSortOption.topRated));
    return page.results.take(6).toList(growable: false);
  }

  Future<List<SearchResultModel>> mostRequested() async {
    final page = await search(query: '', filters: const SearchFilterModel(sortOption: SearchSortOption.mostRequested));
    return page.results.take(6).toList(growable: false);
  }

  Future<List<SearchResultModel>> newest() async {
    final page = await search(query: '', filters: const SearchFilterModel(sortOption: SearchSortOption.newest));
    return page.results.take(6).toList(growable: false);
  }

  SearchResultModel _providerToResult(ProviderProfileModel provider, String query) {
    const rating = 0.0;
    final text = '${provider.businessName} ${provider.description} ${provider.serviceType} ${provider.governorate} ${provider.district} ${provider.address}';
    return SearchResultModel(
      itemId: provider.providerId,
      type: SearchResultType.provider,
      title: provider.businessName.isEmpty ? 'مقدم خدمة' : provider.businessName,
      subtitle: provider.serviceType.isEmpty ? 'خدمات عامة' : provider.serviceType,
      description: provider.description,
      categoryId: _categoryAlias(provider.categoryId, provider.serviceType),
      locationText: _location(provider.governorate, provider.district, provider.address),
      createdAt: provider.createdAt,
      providerId: provider.providerId,
      imageUrl: provider.logoPath,
      governorate: provider.governorate,
      district: provider.district,
      serviceType: provider.serviceType,
      rating: rating,
      ratingCount: 0,
      requestCount: 0,
      score: _score(text, query),
    );
  }

  SearchResultModel _serviceToResult(service, ProviderProfileModel? provider, String query) {
    final text = '${service.name} ${service.description} ${service.category} ${provider?.businessName ?? ''} ${provider?.governorate ?? ''} ${provider?.district ?? ''}';
    final providerId = service.providerId;
    return SearchResultModel(
      itemId: service.serviceId,
      type: SearchResultType.service,
      title: service.name,
      subtitle: provider?.businessName ?? 'خدمة من مقدم مستقل',
      description: service.description,
      categoryId: _categoryAlias(service.category, service.name),
      locationText: provider == null ? 'حسب مقدم الخدمة' : _location(provider.governorate, provider.district, provider.address),
      createdAt: service.createdAt,
      providerId: providerId,
      imageUrl: provider?.logoPath ?? '',
      governorate: provider?.governorate ?? '',
      district: provider?.district ?? '',
      serviceType: service.category,
      rating: 0,
      ratingCount: 0,
      requestCount: 0,
      price: service.price,
      score: _score(text, query),
    );
  }

  SearchResultModel _adToResult(ad, String query) {
    final text = '${ad.title} ${ad.description} ${ad.locationText} ${ad.ownerName} ${ad.categoryId}';
    return SearchResultModel(
      itemId: ad.adId,
      type: SearchResultType.ad,
      title: ad.title,
      subtitle: ad.ownerName.isEmpty ? 'إعلان' : ad.ownerName,
      description: ad.description,
      categoryId: _categoryAlias(ad.categoryId, ad.title),
      locationText: ad.locationText,
      createdAt: ad.createdAt,
      providerId: ad.providerId,
      imageUrl: ad.mainImage,
      rating: 0,
      requestCount: 0,
      price: ad.priceAfter > 0 ? ad.priceAfter : null,
      discountPercent: ad.effectiveDiscountPercent,
      score: _score(text, query),
    );
  }

  bool _matchesQuery(SearchResultModel item, String query) {
    if (query.isEmpty) return true;
    final haystack = _normalize('${item.title} ${item.subtitle} ${item.description} ${item.categoryId} ${item.locationText} ${item.governorate} ${item.district} ${item.serviceType}');
    if (haystack.contains(query)) return true;
    final words = query.split(' ').where((word) => word.trim().isNotEmpty).toList(growable: false);
    return words.every((word) => haystack.contains(word) || _nearAny(word, haystack.split(' ')));
  }

  bool _matchesFilters(SearchResultModel item, SearchFilterModel filters) {
    final governorate = _normalize(filters.governorate);
    final district = _normalize(filters.district);
    final serviceType = _normalize(filters.serviceType);
    final categoryId = _normalize(filters.categoryId);
    if (governorate.isNotEmpty && !_normalize(item.governorate).contains(governorate) && !_normalize(item.locationText).contains(governorate)) return false;
    if (district.isNotEmpty && !_normalize(item.district).contains(district) && !_normalize(item.locationText).contains(district)) return false;
    if (serviceType.isNotEmpty && !_normalize(item.serviceType).contains(serviceType) && !_normalize(item.subtitle).contains(serviceType)) return false;
    if (categoryId.isNotEmpty && _normalize(item.categoryId) != categoryId) return false;
    if (filters.minPrice != null && (item.price ?? 0) < filters.minPrice!) return false;
    if (filters.maxPrice != null && item.price != null && item.price! > filters.maxPrice!) return false;
    return true;
  }

  List<SearchResultModel> _sort(List<SearchResultModel> results, SearchSortOption option) {
    final sorted = [...results];
    switch (option) {
      case SearchSortOption.topRated:
        sorted.sort((a, b) => b.rating.compareTo(a.rating));
        break;
      case SearchSortOption.newest:
        sorted.sort((a, b) => b.createdAt.compareTo(a.createdAt));
        break;
      case SearchSortOption.mostRequested:
        sorted.sort((a, b) => b.requestCount.compareTo(a.requestCount));
        break;
      case SearchSortOption.priceLowToHigh:
        sorted.sort((a, b) => (a.price ?? 999999999).compareTo(b.price ?? 999999999));
        break;
      case SearchSortOption.priceHighToLow:
        sorted.sort((a, b) => (b.price ?? 0).compareTo(a.price ?? 0));
        break;
      case SearchSortOption.smart:
        sorted.sort((a, b) {
          final byScore = b.score.compareTo(a.score);
          if (byScore != 0) return byScore;
          return b.createdAt.compareTo(a.createdAt);
        });
    }
    return sorted;
  }

  List<String> _suggestions(List<SearchResultModel> results, String query, SearchFilterModel filters) {
    final values = <String>{};
    for (final item in results) {
      if (item.title.trim().isNotEmpty) values.add(item.title.trim());
      if (item.serviceType.trim().isNotEmpty) values.add(item.serviceType.trim());
      if (item.governorate.trim().isNotEmpty) values.add(item.governorate.trim());
      if (item.district.trim().isNotEmpty) values.add(item.district.trim());
    }
    const defaults = ['مطعم', 'تكسي', 'مياه', 'بنشر', 'ميكانيكي', 'عقار', 'سيارة', 'صيدلية', 'بقالة', 'سباك', 'كهربائي'];
    values.addAll(defaults);
    final sorted = values.toList(growable: false)..sort();
    if (query.isEmpty) return sorted.take(12).toList(growable: false);
    final normalized = _normalize(query);
    final starts = sorted.where((item) => _normalize(item).startsWith(normalized)).take(6);
    final contains = sorted.where((item) => _normalize(item).contains(normalized) && !_normalize(item).startsWith(normalized)).take(6);
    return [...starts, ...contains].take(10).toList(growable: false);
  }

  String? _didYouMean(String query, List<String> suggestions) {
    if (query.isEmpty || suggestions.isEmpty) return null;
    var best = '';
    var bestDistance = 99;
    for (final suggestion in suggestions) {
      final normalized = _normalize(suggestion);
      final distance = _levenshtein(query, normalized);
      if (distance < bestDistance) {
        bestDistance = distance;
        best = suggestion;
      }
    }
    if (best.isEmpty) return null;
    if (bestDistance > 0 && bestDistance <= 2) return best;
    const corrections = {'مطعمم': 'مطعم', 'تكسيي': 'تكسي', 'عقارا': 'عقار', 'سياره': 'سيارة', 'بقاله': 'بقالة'};
    return corrections[query];
  }

  double _score(String text, String query) {
    if (query.isEmpty) return 1;
    final haystack = _normalize(text);
    if (haystack == query) return 100;
    if (haystack.startsWith(query)) return 80;
    if (haystack.contains(query)) return 60;
    final words = query.split(' ').where((item) => item.isNotEmpty);
    return words.fold<double>(0, (score, word) => score + (haystack.contains(word) ? 12 : 0));
  }

  bool _nearAny(String word, List<String> terms) {
    if (word.length < 4) return false;
    return terms.any((term) => term.length >= 4 && _levenshtein(word, term) <= 1);
  }

  int _levenshtein(String a, String b) {
    if (a == b) return 0;
    if (a.isEmpty) return b.length;
    if (b.isEmpty) return a.length;
    final previous = List<int>.generate(b.length + 1, (index) => index);
    final current = List<int>.filled(b.length + 1, 0);
    for (var i = 0; i < a.length; i += 1) {
      current[0] = i + 1;
      for (var j = 0; j < b.length; j += 1) {
        final insert = current[j] + 1;
        final delete = previous[j + 1] + 1;
        final replace = previous[j] + (a[i] == b[j] ? 0 : 1);
        current[j + 1] = [insert, delete, replace].reduce((x, y) => x < y ? x : y);
      }
      for (var j = 0; j < previous.length; j += 1) {
        previous[j] = current[j];
      }
    }
    return previous[b.length];
  }

  String _categoryAlias(String raw, String fallback) {
    final text = _normalize('$raw $fallback');
    if (text.contains('water') || text.contains('ماء') || text.contains('مياه')) return 'water';
    if (text.contains('taxi') || text.contains('تكسي') || text.contains('توصيل')) return 'taxi';
    if (text.contains('tire') || text.contains('بنشر') || text.contains('اطار') || text.contains('إطار')) return 'tire';
    if (text.contains('mechanic') || text.contains('ميكانيك') || text.contains('سيارات')) return 'mechanic';
    if (text.contains('restaurant') || text.contains('مطعم') || text.contains('وجبات')) return 'restaurants';
    if (text.contains('grocery') || text.contains('بقال')) return 'groceries';
    if (text.contains('pharmacy') || text.contains('صيدلية')) return 'pharmacy';
    if (text.contains('real') || text.contains('عقار') || text.contains('شقة') || text.contains('أرض')) return 'real_estate';
    if (text.contains('car') || text.contains('سيارة') || text.contains('سيارات')) return 'cars';
    if (text.contains('craft') || text.contains('سباك') || text.contains('كهرب') || text.contains('نجار') || text.contains('حرف')) return 'craftsmen';
    return raw.trim().isEmpty ? 'other_services' : raw.trim();
  }

  String _location(String governorate, String district, String address) {
    final parts = [governorate, district, address].where((item) => item.trim().isNotEmpty).toList(growable: false);
    return parts.isEmpty ? 'الموقع غير محدد' : parts.join(' - ');
  }

  String _normalize(String value) {
    return value
        .trim()
        .toLowerCase()
        .replaceAll('أ', 'ا')
        .replaceAll('إ', 'ا')
        .replaceAll('آ', 'ا')
        .replaceAll('ى', 'ي')
        .replaceAll('ة', 'ه')
        .replaceAll(RegExp(r'\s+'), ' ');
  }
}
