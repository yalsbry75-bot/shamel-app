import '../../../core/utils/ui_state.dart';
import 'search_filter_model.dart';
import 'search_result_model.dart';

class SearchState {
  const SearchState({
    this.viewState = ViewState.initial,
    this.query = '',
    this.results = const [],
    this.suggestions = const [],
    this.recentSearches = const [],
    this.filters = const SearchFilterModel(),
    this.didYouMean,
    this.page = 1,
    this.hasMore = false,
    this.message,
    this.errorMessage,
  });

  final ViewState viewState;
  final String query;
  final List<SearchResultModel> results;
  final List<String> suggestions;
  final List<String> recentSearches;
  final SearchFilterModel filters;
  final String? didYouMean;
  final int page;
  final bool hasMore;
  final String? message;
  final String? errorMessage;

  bool get isLoading => viewState == ViewState.loading;
  bool get isEmpty => viewState == ViewState.empty || results.isEmpty;

  SearchState copyWith({
    ViewState? viewState,
    String? query,
    List<SearchResultModel>? results,
    List<String>? suggestions,
    List<String>? recentSearches,
    SearchFilterModel? filters,
    String? didYouMean,
    bool clearDidYouMean = false,
    int? page,
    bool? hasMore,
    String? message,
    bool clearMessage = false,
    String? errorMessage,
    bool clearError = false,
  }) {
    return SearchState(
      viewState: viewState ?? this.viewState,
      query: query ?? this.query,
      results: results ?? this.results,
      suggestions: suggestions ?? this.suggestions,
      recentSearches: recentSearches ?? this.recentSearches,
      filters: filters ?? this.filters,
      didYouMean: clearDidYouMean ? null : didYouMean ?? this.didYouMean,
      page: page ?? this.page,
      hasMore: hasMore ?? this.hasMore,
      message: clearMessage ? null : message ?? this.message,
      errorMessage: clearError ? null : errorMessage ?? this.errorMessage,
    );
  }
}
