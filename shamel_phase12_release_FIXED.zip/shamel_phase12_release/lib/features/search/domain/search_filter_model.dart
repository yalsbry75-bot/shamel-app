import 'search_sort_option.dart';

class SearchFilterModel {
  const SearchFilterModel({
    this.governorate = '',
    this.district = '',
    this.serviceType = '',
    this.categoryId = '',
    this.minPrice,
    this.maxPrice,
    this.sortOption = SearchSortOption.smart,
  });

  final String governorate;
  final String district;
  final String serviceType;
  final String categoryId;
  final double? minPrice;
  final double? maxPrice;
  final SearchSortOption sortOption;

  bool get hasActiveFilters {
    return governorate.trim().isNotEmpty ||
        district.trim().isNotEmpty ||
        serviceType.trim().isNotEmpty ||
        categoryId.trim().isNotEmpty ||
        minPrice != null ||
        maxPrice != null ||
        sortOption != SearchSortOption.smart;
  }

  factory SearchFilterModel.fromJson(Map<String, dynamic> json) {
    return SearchFilterModel(
      governorate: json['governorate'] as String? ?? '',
      district: json['district'] as String? ?? '',
      serviceType: json['serviceType'] as String? ?? '',
      categoryId: json['categoryId'] as String? ?? '',
      minPrice: _doubleOrNull(json['minPrice']),
      maxPrice: _doubleOrNull(json['maxPrice']),
      sortOption: SearchSortOptionX.fromValue(json['sortOption'] as String? ?? 'smart'),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'governorate': governorate,
      'district': district,
      'serviceType': serviceType,
      'categoryId': categoryId,
      'minPrice': minPrice,
      'maxPrice': maxPrice,
      'sortOption': sortOption.value,
    };
  }

  SearchFilterModel copyWith({
    String? governorate,
    String? district,
    String? serviceType,
    String? categoryId,
    double? minPrice,
    bool clearMinPrice = false,
    double? maxPrice,
    bool clearMaxPrice = false,
    SearchSortOption? sortOption,
  }) {
    return SearchFilterModel(
      governorate: governorate ?? this.governorate,
      district: district ?? this.district,
      serviceType: serviceType ?? this.serviceType,
      categoryId: categoryId ?? this.categoryId,
      minPrice: clearMinPrice ? null : minPrice ?? this.minPrice,
      maxPrice: clearMaxPrice ? null : maxPrice ?? this.maxPrice,
      sortOption: sortOption ?? this.sortOption,
    );
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        other is SearchFilterModel &&
            runtimeType == other.runtimeType &&
            governorate == other.governorate &&
            district == other.district &&
            serviceType == other.serviceType &&
            categoryId == other.categoryId &&
            minPrice == other.minPrice &&
            maxPrice == other.maxPrice &&
            sortOption == other.sortOption;
  }

  @override
  int get hashCode => Object.hash(governorate, district, serviceType, categoryId, minPrice, maxPrice, sortOption);

  static double? _doubleOrNull(dynamic value) {
    if (value == null || value.toString().trim().isEmpty) return null;
    if (value is num) return value.toDouble();
    return double.tryParse(value.toString());
  }
}
