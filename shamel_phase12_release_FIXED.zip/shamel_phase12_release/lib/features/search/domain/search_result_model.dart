import 'search_result_type.dart';

class SearchResultModel {
  const SearchResultModel({
    required this.itemId,
    required this.type,
    required this.title,
    required this.subtitle,
    required this.description,
    required this.categoryId,
    required this.locationText,
    required this.createdAt,
    this.providerId = '',
    this.imageUrl = '',
    this.governorate = '',
    this.district = '',
    this.serviceType = '',
    this.rating = 0,
    this.ratingCount = 0,
    this.requestCount = 0,
    this.price,
    this.discountPercent = 0,
    this.score = 0,
  });

  final String itemId;
  final SearchResultType type;
  final String title;
  final String subtitle;
  final String description;
  final String categoryId;
  final String locationText;
  final DateTime createdAt;
  final String providerId;
  final String imageUrl;
  final String governorate;
  final String district;
  final String serviceType;
  final double rating;
  final int ratingCount;
  final int requestCount;
  final double? price;
  final int discountPercent;
  final double score;

  bool get hasPrice => price != null && price! > 0;
  bool get hasDiscount => discountPercent > 0;
  bool get isAd => type == SearchResultType.ad;
  bool get isProvider => type == SearchResultType.provider;
  bool get isService => type == SearchResultType.service;

  factory SearchResultModel.fromJson(Map<String, dynamic> json) {
    return SearchResultModel(
      itemId: json['itemId'] as String? ?? '',
      type: SearchResultTypeX.fromValue(json['type'] as String? ?? 'service'),
      title: json['title'] as String? ?? '',
      subtitle: json['subtitle'] as String? ?? '',
      description: json['description'] as String? ?? '',
      categoryId: json['categoryId'] as String? ?? '',
      locationText: json['locationText'] as String? ?? '',
      createdAt: DateTime.tryParse(json['createdAt'] as String? ?? '') ?? DateTime.fromMillisecondsSinceEpoch(0),
      providerId: json['providerId'] as String? ?? '',
      imageUrl: json['imageUrl'] as String? ?? '',
      governorate: json['governorate'] as String? ?? '',
      district: json['district'] as String? ?? '',
      serviceType: json['serviceType'] as String? ?? '',
      rating: _double(json['rating']),
      ratingCount: _int(json['ratingCount']),
      requestCount: _int(json['requestCount']),
      price: _doubleOrNull(json['price']),
      discountPercent: _int(json['discountPercent']),
      score: _double(json['score']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'itemId': itemId,
      'type': type.value,
      'title': title,
      'subtitle': subtitle,
      'description': description,
      'categoryId': categoryId,
      'locationText': locationText,
      'createdAt': createdAt.toIso8601String(),
      'providerId': providerId,
      'imageUrl': imageUrl,
      'governorate': governorate,
      'district': district,
      'serviceType': serviceType,
      'rating': rating,
      'ratingCount': ratingCount,
      'requestCount': requestCount,
      'price': price,
      'discountPercent': discountPercent,
      'score': score,
    };
  }

  SearchResultModel copyWith({
    String? itemId,
    SearchResultType? type,
    String? title,
    String? subtitle,
    String? description,
    String? categoryId,
    String? locationText,
    DateTime? createdAt,
    String? providerId,
    String? imageUrl,
    String? governorate,
    String? district,
    String? serviceType,
    double? rating,
    int? ratingCount,
    int? requestCount,
    double? price,
    bool clearPrice = false,
    int? discountPercent,
    double? score,
  }) {
    return SearchResultModel(
      itemId: itemId ?? this.itemId,
      type: type ?? this.type,
      title: title ?? this.title,
      subtitle: subtitle ?? this.subtitle,
      description: description ?? this.description,
      categoryId: categoryId ?? this.categoryId,
      locationText: locationText ?? this.locationText,
      createdAt: createdAt ?? this.createdAt,
      providerId: providerId ?? this.providerId,
      imageUrl: imageUrl ?? this.imageUrl,
      governorate: governorate ?? this.governorate,
      district: district ?? this.district,
      serviceType: serviceType ?? this.serviceType,
      rating: rating ?? this.rating,
      ratingCount: ratingCount ?? this.ratingCount,
      requestCount: requestCount ?? this.requestCount,
      price: clearPrice ? null : price ?? this.price,
      discountPercent: discountPercent ?? this.discountPercent,
      score: score ?? this.score,
    );
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        other is SearchResultModel &&
            runtimeType == other.runtimeType &&
            itemId == other.itemId &&
            type == other.type &&
            title == other.title &&
            subtitle == other.subtitle &&
            description == other.description &&
            categoryId == other.categoryId &&
            locationText == other.locationText &&
            createdAt == other.createdAt &&
            providerId == other.providerId &&
            imageUrl == other.imageUrl &&
            governorate == other.governorate &&
            district == other.district &&
            serviceType == other.serviceType &&
            rating == other.rating &&
            ratingCount == other.ratingCount &&
            requestCount == other.requestCount &&
            price == other.price &&
            discountPercent == other.discountPercent &&
            score == other.score;
  }

  @override
  int get hashCode => Object.hash(
        itemId,
        type,
        title,
        subtitle,
        description,
        categoryId,
        locationText,
        createdAt,
        providerId,
        imageUrl,
        governorate,
        district,
        serviceType,
        rating,
        ratingCount,
        requestCount,
        price,
        discountPercent,
        score,
      );

  static int _int(dynamic value) {
    if (value == null) return 0;
    if (value is num) return value.toInt();
    return int.tryParse(value.toString()) ?? 0;
  }

  static double _double(dynamic value) {
    if (value == null) return 0;
    if (value is num) return value.toDouble();
    return double.tryParse(value.toString()) ?? 0;
  }

  static double? _doubleOrNull(dynamic value) {
    if (value == null || value.toString().trim().isEmpty) return null;
    if (value is num) return value.toDouble();
    return double.tryParse(value.toString());
  }
}
