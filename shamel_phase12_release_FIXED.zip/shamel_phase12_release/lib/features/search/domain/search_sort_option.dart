enum SearchSortOption { smart, topRated, newest, mostRequested, priceLowToHigh, priceHighToLow }

extension SearchSortOptionX on SearchSortOption {
  String get value {
    switch (this) {
      case SearchSortOption.smart:
        return 'smart';
      case SearchSortOption.topRated:
        return 'top_rated';
      case SearchSortOption.newest:
        return 'newest';
      case SearchSortOption.mostRequested:
        return 'most_requested';
      case SearchSortOption.priceLowToHigh:
        return 'price_low_to_high';
      case SearchSortOption.priceHighToLow:
        return 'price_high_to_low';
    }
  }

  String get label {
    switch (this) {
      case SearchSortOption.smart:
        return 'الأكثر صلة';
      case SearchSortOption.topRated:
        return 'أعلى تقييم';
      case SearchSortOption.newest:
        return 'الأحدث';
      case SearchSortOption.mostRequested:
        return 'الأكثر طلبًا';
      case SearchSortOption.priceLowToHigh:
        return 'السعر الأقل';
      case SearchSortOption.priceHighToLow:
        return 'السعر الأعلى';
    }
  }

  static SearchSortOption fromValue(String value) {
    switch (value) {
      case 'top_rated':
        return SearchSortOption.topRated;
      case 'newest':
        return SearchSortOption.newest;
      case 'most_requested':
        return SearchSortOption.mostRequested;
      case 'price_low_to_high':
        return SearchSortOption.priceLowToHigh;
      case 'price_high_to_low':
        return SearchSortOption.priceHighToLow;
      default:
        return SearchSortOption.smart;
    }
  }
}
