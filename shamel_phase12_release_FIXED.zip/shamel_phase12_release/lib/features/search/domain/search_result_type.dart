enum SearchResultType { provider, service, ad }

extension SearchResultTypeX on SearchResultType {
  String get value {
    switch (this) {
      case SearchResultType.provider:
        return 'provider';
      case SearchResultType.service:
        return 'service';
      case SearchResultType.ad:
        return 'ad';
    }
  }

  String get label {
    switch (this) {
      case SearchResultType.provider:
        return 'مقدم خدمة';
      case SearchResultType.service:
        return 'خدمة';
      case SearchResultType.ad:
        return 'إعلان';
    }
  }

  static SearchResultType fromValue(String value) {
    switch (value) {
      case 'provider':
        return SearchResultType.provider;
      case 'service':
        return SearchResultType.service;
      case 'ad':
        return SearchResultType.ad;
      default:
        return SearchResultType.service;
    }
  }
}
