enum ProviderStatus { pending, active, suspended, expired }

extension ProviderStatusX on ProviderStatus {
  String get value {
    switch (this) {
      case ProviderStatus.pending:
        return 'pending';
      case ProviderStatus.active:
        return 'active';
      case ProviderStatus.suspended:
        return 'suspended';
      case ProviderStatus.expired:
        return 'expired';
    }
  }

  String get label {
    switch (this) {
      case ProviderStatus.pending:
        return 'بانتظار التفعيل';
      case ProviderStatus.active:
        return 'نشط';
      case ProviderStatus.suspended:
        return 'موقوف';
      case ProviderStatus.expired:
        return 'منتهي';
    }
  }

  static ProviderStatus fromValue(String value) {
    switch (value) {
      case 'active':
        return ProviderStatus.active;
      case 'suspended':
        return ProviderStatus.suspended;
      case 'expired':
        return ProviderStatus.expired;
      case 'pending':
      default:
        return ProviderStatus.pending;
    }
  }
}
