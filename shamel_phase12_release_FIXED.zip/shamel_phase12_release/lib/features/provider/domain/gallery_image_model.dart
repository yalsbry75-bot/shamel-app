enum GalleryImageType { work, product, equipment }

extension GalleryImageTypeX on GalleryImageType {
  String get value {
    switch (this) {
      case GalleryImageType.work:
        return 'work';
      case GalleryImageType.product:
        return 'product';
      case GalleryImageType.equipment:
        return 'equipment';
    }
  }

  String get label {
    switch (this) {
      case GalleryImageType.work:
        return 'صور الأعمال';
      case GalleryImageType.product:
        return 'صور المنتجات';
      case GalleryImageType.equipment:
        return 'صور المعدات';
    }
  }

  static GalleryImageType fromValue(String value) {
    switch (value) {
      case 'product':
        return GalleryImageType.product;
      case 'equipment':
        return GalleryImageType.equipment;
      case 'work':
      default:
        return GalleryImageType.work;
    }
  }
}

class GalleryImageModel {
  const GalleryImageModel({
    required this.imageId,
    required this.providerId,
    required this.title,
    required this.type,
    required this.sortOrder,
    required this.createdAt,
    this.localPath = '',
  });

  final String imageId;
  final String providerId;
  final String title;
  final GalleryImageType type;
  final int sortOrder;
  final DateTime createdAt;
  final String localPath;

  factory GalleryImageModel.fromJson(Map<String, dynamic> json) {
    return GalleryImageModel(
      imageId: json['imageId'] as String? ?? '',
      providerId: json['providerId'] as String? ?? '',
      title: json['title'] as String? ?? '',
      type: GalleryImageTypeX.fromValue(json['type'] as String? ?? 'work'),
      sortOrder: json['sortOrder'] as int? ?? 0,
      createdAt: DateTime.parse(json['createdAt'] as String),
      localPath: json['localPath'] as String? ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'imageId': imageId,
      'providerId': providerId,
      'title': title,
      'type': type.value,
      'sortOrder': sortOrder,
      'createdAt': createdAt.toIso8601String(),
      'localPath': localPath,
    };
  }

  GalleryImageModel copyWith({
    String? imageId,
    String? providerId,
    String? title,
    GalleryImageType? type,
    int? sortOrder,
    DateTime? createdAt,
    String? localPath,
  }) {
    return GalleryImageModel(
      imageId: imageId ?? this.imageId,
      providerId: providerId ?? this.providerId,
      title: title ?? this.title,
      type: type ?? this.type,
      sortOrder: sortOrder ?? this.sortOrder,
      createdAt: createdAt ?? this.createdAt,
      localPath: localPath ?? this.localPath,
    );
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        other is GalleryImageModel &&
            runtimeType == other.runtimeType &&
            imageId == other.imageId &&
            providerId == other.providerId &&
            title == other.title &&
            type == other.type &&
            sortOrder == other.sortOrder &&
            createdAt == other.createdAt &&
            localPath == other.localPath;
  }

  @override
  int get hashCode => Object.hash(imageId, providerId, title, type, sortOrder, createdAt, localPath);
}
