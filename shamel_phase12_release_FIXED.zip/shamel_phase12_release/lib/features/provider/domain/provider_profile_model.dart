import 'provider_status.dart';

class ProviderProfileModel {
  const ProviderProfileModel({
    required this.providerId,
    required this.userId,
    required this.businessName,
    required this.phoneNumber,
    required this.description,
    required this.categoryId,
    required this.serviceType,
    required this.governorate,
    required this.district,
    required this.address,
    required this.status,
    required this.createdAt,
    this.logoPath = '',
    this.coverPath = '',
    this.workingHours = 'من 9 صباحًا إلى 9 مساءً',
    this.serviceAreas = const [],
  });

  final String providerId;
  final String userId;
  final String businessName;
  final String phoneNumber;
  final String description;
  final String categoryId;
  final String serviceType;
  final String governorate;
  final String district;
  final String address;
  final ProviderStatus status;
  final DateTime createdAt;
  final String logoPath;
  final String coverPath;
  final String workingHours;
  final List<String> serviceAreas;

  bool get isVisible => status == ProviderStatus.active;
  bool get isCompleted {
    return businessName.trim().isNotEmpty &&
        phoneNumber.trim().isNotEmpty &&
        description.trim().isNotEmpty &&
        serviceType.trim().isNotEmpty &&
        governorate.trim().isNotEmpty &&
        district.trim().isNotEmpty;
  }

  factory ProviderProfileModel.empty({required String providerId, required String userId, required String phoneNumber}) {
    return ProviderProfileModel(
      providerId: providerId,
      userId: userId,
      businessName: '',
      phoneNumber: phoneNumber,
      description: '',
      categoryId: '',
      serviceType: '',
      governorate: '',
      district: '',
      address: '',
      status: ProviderStatus.pending,
      createdAt: DateTime.now(),
    );
  }

  factory ProviderProfileModel.fromJson(Map<String, dynamic> json) {
    return ProviderProfileModel(
      providerId: json['providerId'] as String? ?? '',
      userId: json['userId'] as String? ?? '',
      businessName: json['businessName'] as String? ?? '',
      phoneNumber: json['phoneNumber'] as String? ?? '',
      description: json['description'] as String? ?? '',
      categoryId: json['categoryId'] as String? ?? '',
      serviceType: json['serviceType'] as String? ?? '',
      governorate: json['governorate'] as String? ?? '',
      district: json['district'] as String? ?? '',
      address: json['address'] as String? ?? '',
      status: ProviderStatusX.fromValue(json['status'] as String? ?? 'pending'),
      createdAt: DateTime.parse(json['createdAt'] as String),
      logoPath: json['logoPath'] as String? ?? '',
      coverPath: json['coverPath'] as String? ?? '',
      workingHours: json['workingHours'] as String? ?? 'من 9 صباحًا إلى 9 مساءً',
      serviceAreas: (json['serviceAreas'] as List<dynamic>? ?? const []).map((item) => item.toString()).toList(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'providerId': providerId,
      'userId': userId,
      'businessName': businessName,
      'phoneNumber': phoneNumber,
      'description': description,
      'categoryId': categoryId,
      'serviceType': serviceType,
      'governorate': governorate,
      'district': district,
      'address': address,
      'status': status.value,
      'createdAt': createdAt.toIso8601String(),
      'logoPath': logoPath,
      'coverPath': coverPath,
      'workingHours': workingHours,
      'serviceAreas': serviceAreas,
    };
  }

  ProviderProfileModel copyWith({
    String? providerId,
    String? userId,
    String? businessName,
    String? phoneNumber,
    String? description,
    String? categoryId,
    String? serviceType,
    String? governorate,
    String? district,
    String? address,
    ProviderStatus? status,
    DateTime? createdAt,
    String? logoPath,
    String? coverPath,
    String? workingHours,
    List<String>? serviceAreas,
  }) {
    return ProviderProfileModel(
      providerId: providerId ?? this.providerId,
      userId: userId ?? this.userId,
      businessName: businessName ?? this.businessName,
      phoneNumber: phoneNumber ?? this.phoneNumber,
      description: description ?? this.description,
      categoryId: categoryId ?? this.categoryId,
      serviceType: serviceType ?? this.serviceType,
      governorate: governorate ?? this.governorate,
      district: district ?? this.district,
      address: address ?? this.address,
      status: status ?? this.status,
      createdAt: createdAt ?? this.createdAt,
      logoPath: logoPath ?? this.logoPath,
      coverPath: coverPath ?? this.coverPath,
      workingHours: workingHours ?? this.workingHours,
      serviceAreas: serviceAreas ?? this.serviceAreas,
    );
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        other is ProviderProfileModel &&
            runtimeType == other.runtimeType &&
            providerId == other.providerId &&
            userId == other.userId &&
            businessName == other.businessName &&
            phoneNumber == other.phoneNumber &&
            description == other.description &&
            categoryId == other.categoryId &&
            serviceType == other.serviceType &&
            governorate == other.governorate &&
            district == other.district &&
            address == other.address &&
            status == other.status &&
            createdAt == other.createdAt &&
            logoPath == other.logoPath &&
            coverPath == other.coverPath &&
            workingHours == other.workingHours &&
            _sameList(serviceAreas, other.serviceAreas);
  }

  @override
  int get hashCode => Object.hash(
        providerId,
        userId,
        businessName,
        phoneNumber,
        description,
        categoryId,
        serviceType,
        governorate,
        district,
        address,
        status,
        createdAt,
        logoPath,
        coverPath,
        workingHours,
        Object.hashAll(serviceAreas),
      );

  static bool _sameList(List<String> first, List<String> second) {
    if (first.length != second.length) return false;
    for (var i = 0; i < first.length; i += 1) {
      if (first[i] != second[i]) return false;
    }
    return true;
  }
}
