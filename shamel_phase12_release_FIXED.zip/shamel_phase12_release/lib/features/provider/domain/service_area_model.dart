class ServiceAreaModel {
  const ServiceAreaModel({
    required this.areaId,
    required this.providerId,
    required this.governorate,
    required this.district,
    required this.neighborhood,
    required this.createdAt,
  });

  final String areaId;
  final String providerId;
  final String governorate;
  final String district;
  final String neighborhood;
  final DateTime createdAt;

  factory ServiceAreaModel.fromJson(Map<String, dynamic> json) {
    return ServiceAreaModel(
      areaId: json['areaId'] as String? ?? '',
      providerId: json['providerId'] as String? ?? _providerIdFromAreaId(json['areaId'] as String? ?? ''),
      governorate: json['governorate'] as String? ?? '',
      district: json['district'] as String? ?? '',
      neighborhood: json['neighborhood'] as String? ?? '',
      createdAt: DateTime.parse(json['createdAt'] as String),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'areaId': areaId,
      'providerId': providerId,
      'governorate': governorate,
      'district': district,
      'neighborhood': neighborhood,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  ServiceAreaModel copyWith({
    String? areaId,
    String? providerId,
    String? governorate,
    String? district,
    String? neighborhood,
    DateTime? createdAt,
  }) {
    return ServiceAreaModel(
      areaId: areaId ?? this.areaId,
      providerId: providerId ?? this.providerId,
      governorate: governorate ?? this.governorate,
      district: district ?? this.district,
      neighborhood: neighborhood ?? this.neighborhood,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        other is ServiceAreaModel &&
            runtimeType == other.runtimeType &&
            areaId == other.areaId &&
            providerId == other.providerId &&
            governorate == other.governorate &&
            district == other.district &&
            neighborhood == other.neighborhood &&
            createdAt == other.createdAt;
  }

  @override
  int get hashCode => Object.hash(areaId, providerId, governorate, district, neighborhood, createdAt);

  static String _providerIdFromAreaId(String areaId) {
    final markerIndex = areaId.lastIndexOf('_');
    if (markerIndex <= 0) return '';
    return areaId.substring(0, markerIndex);
  }
}
