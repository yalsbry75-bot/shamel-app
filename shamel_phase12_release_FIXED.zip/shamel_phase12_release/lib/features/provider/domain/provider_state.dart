import '../../../core/utils/ui_state.dart';
import 'gallery_image_model.dart';
import 'provider_profile_model.dart';
import 'provider_service_item_model.dart';
import 'provider_status.dart';
import 'service_area_model.dart';

class ProviderState {
  const ProviderState({
    this.viewState = ViewState.initial,
    this.profile,
    this.services = const [],
    this.gallery = const [],
    this.areas = const [],
    this.message,
    this.errorMessage,
  });

  final ViewState viewState;
  final ProviderProfileModel? profile;
  final List<ProviderServiceItemModel> services;
  final List<GalleryImageModel> gallery;
  final List<ServiceAreaModel> areas;
  final String? message;
  final String? errorMessage;

  bool get hasProfile => profile != null;
  bool get profileCompleted => profile?.isCompleted ?? false;
  bool get isVisible => profile?.status == ProviderStatus.active;
  List<ProviderServiceItemModel> get mainServices => services.where((item) => !item.isSubService).toList(growable: false);
  List<ProviderServiceItemModel> subServicesOf(String serviceId) {
    return services.where((item) => item.parentServiceId == serviceId).toList(growable: false);
  }

  ProviderState copyWith({
    ViewState? viewState,
    ProviderProfileModel? profile,
    bool clearProfile = false,
    List<ProviderServiceItemModel>? services,
    List<GalleryImageModel>? gallery,
    List<ServiceAreaModel>? areas,
    String? message,
    bool clearMessage = false,
    String? errorMessage,
    bool clearError = false,
  }) {
    return ProviderState(
      viewState: viewState ?? this.viewState,
      profile: clearProfile ? null : profile ?? this.profile,
      services: services ?? this.services,
      gallery: gallery ?? this.gallery,
      areas: areas ?? this.areas,
      message: clearMessage ? null : message ?? this.message,
      errorMessage: clearError ? null : errorMessage ?? this.errorMessage,
    );
  }
}
