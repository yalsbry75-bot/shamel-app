import 'provider_status.dart';

class ProviderServiceItemModel {
  const ProviderServiceItemModel({
    required this.serviceId,
    required this.providerId,
    required this.name,
    required this.description,
    required this.category,
    required this.createdAt,
    this.price,
    this.status = ProviderStatus.active,
    this.parentServiceId,
  });

  final String serviceId;
  final String providerId;
  final String name;
  final String description;
  final String category;
  final double? price;
  final DateTime createdAt;
  final ProviderStatus status;
  final String? parentServiceId;

  bool get isSubService => parentServiceId != null && parentServiceId!.isNotEmpty;

  factory ProviderServiceItemModel.fromJson(Map<String, dynamic> json) {
    return ProviderServiceItemModel(
      serviceId: json['serviceId'] as String? ?? '',
      providerId: json['providerId'] as String? ?? '',
      name: json['name'] as String? ?? '',
      description: json['description'] as String? ?? '',
      category: json['category'] as String? ?? '',
      price: (json['price'] as num?)?.toDouble(),
      createdAt: DateTime.parse(json['createdAt'] as String),
      status: ProviderStatusX.fromValue(json['status'] as String? ?? 'active'),
      parentServiceId: json['parentServiceId'] as String?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'serviceId': serviceId,
      'providerId': providerId,
      'name': name,
      'description': description,
      'category': category,
      'price': price,
      'createdAt': createdAt.toIso8601String(),
      'status': status.value,
      'parentServiceId': parentServiceId,
    };
  }

  ProviderServiceItemModel copyWith({
    String? serviceId,
    String? providerId,
    String? name,
    String? description,
    String? category,
    double? price,
    bool clearPrice = false,
    DateTime? createdAt,
    ProviderStatus? status,
    String? parentServiceId,
    bool clearParentServiceId = false,
  }) {
    return ProviderServiceItemModel(
      serviceId: serviceId ?? this.serviceId,
      providerId: providerId ?? this.providerId,
      name: name ?? this.name,
      description: description ?? this.description,
      category: category ?? this.category,
      price: clearPrice ? null : price ?? this.price,
      createdAt: createdAt ?? this.createdAt,
      status: status ?? this.status,
      parentServiceId: clearParentServiceId ? null : parentServiceId ?? this.parentServiceId,
    );
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        other is ProviderServiceItemModel &&
            runtimeType == other.runtimeType &&
            serviceId == other.serviceId &&
            providerId == other.providerId &&
            name == other.name &&
            description == other.description &&
            category == other.category &&
            price == other.price &&
            createdAt == other.createdAt &&
            status == other.status &&
            parentServiceId == other.parentServiceId;
  }

  @override
  int get hashCode => Object.hash(serviceId, providerId, name, description, category, price, createdAt, status, parentServiceId);
}
