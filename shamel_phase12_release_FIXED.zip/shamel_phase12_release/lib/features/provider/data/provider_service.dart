import '../../../core/errors/app_exception.dart';
import '../domain/gallery_image_model.dart';
import '../domain/provider_profile_model.dart';
import '../domain/provider_service_item_model.dart';
import '../domain/service_area_model.dart';

import '../../../core/database/firestore_json.dart';
import '../../../core/database/firestore_collections.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
class ProviderBundle {
  const ProviderBundle({
    this.profile,
    this.services = const [],
    this.gallery = const [],
    this.areas = const [],
  });

  final ProviderProfileModel? profile;
  final List<ProviderServiceItemModel> services;
  final List<GalleryImageModel> gallery;
  final List<ServiceAreaModel> areas;
}

abstract class ProviderService {
  Future<ProviderBundle> loadBundle(String userId);
  Future<List<ProviderProfileModel>> loadAllProfiles();
  Future<List<ProviderServiceItemModel>> loadAllServices();
  Future<ProviderProfileModel> saveProfile(ProviderProfileModel profile);
  Future<ProviderServiceItemModel> saveServiceItem(ProviderServiceItemModel item);
  Future<void> deleteServiceItem(String serviceId);
  Future<GalleryImageModel> saveGalleryImage(GalleryImageModel image);
  Future<void> deleteGalleryImage(String imageId);
  Future<List<GalleryImageModel>> reorderGallery({required String providerId, required int oldIndex, required int newIndex});
  Future<ServiceAreaModel> saveServiceArea(ServiceAreaModel area);
  Future<void> deleteServiceArea(String areaId);
}

class FirebaseProviderService implements ProviderService {
  FirebaseProviderService({FirebaseFirestore? firestore}) : _firestore = firestore ?? FirebaseFirestore.instance;
  final FirebaseFirestore _firestore;

  @override
  Future<ProviderBundle> loadBundle(String userId) async {
    final profiles = await _firestore.collection(FirestoreCollections.providers).where('userId', isEqualTo: userId).limit(1).get();
    if (profiles.docs.isEmpty) return const ProviderBundle();
    final profile = ProviderProfileModel.fromJson(FirestoreJson.normalize(profiles.docs.first.data()));
    final services = await _loadServices(profile.providerId);
    final gallery = await _loadGallery(profile.providerId);
    final areas = await _loadAreas(profile.providerId);
    return ProviderBundle(profile: profile, services: services, gallery: gallery, areas: areas);
  }

  @override
  Future<List<ProviderProfileModel>> loadAllProfiles() async {
    final snapshot = await _firestore.collection(FirestoreCollections.providers).orderBy('createdAt', descending: true).limit(80).get();
    return snapshot.docs.map((doc) => ProviderProfileModel.fromJson(FirestoreJson.normalize(doc.data()))).toList(growable: false);
  }

  @override
  Future<List<ProviderServiceItemModel>> loadAllServices() async {
    final snapshot = await _firestore.collection(FirestoreCollections.services).orderBy('createdAt', descending: true).limit(120).get();
    return snapshot.docs.map((doc) => ProviderServiceItemModel.fromJson(FirestoreJson.normalize(doc.data()))).toList(growable: false);
  }

  @override
  Future<ProviderProfileModel> saveProfile(ProviderProfileModel profile) async {
    if (profile.userId.trim().isEmpty || profile.providerId.trim().isEmpty) {
      throw const AppException('بيانات مقدم الخدمة غير مكتملة.', code: 'INVALID_PROVIDER_PROFILE');
    }
    await _firestore.collection(FirestoreCollections.providers).doc(profile.providerId).set(FirestoreJson.withServerAudit(profile.toJson(), isCreate: true), SetOptions(merge: true));
    return profile;
  }

  @override
  Future<ProviderServiceItemModel> saveServiceItem(ProviderServiceItemModel item) async {
    if (item.providerId.trim().isEmpty || item.name.trim().isEmpty) {
      throw const AppException('اسم الخدمة مطلوب.', code: 'INVALID_SERVICE');
    }
    await _firestore.collection(FirestoreCollections.services).doc(item.serviceId).set(FirestoreJson.withServerAudit(item.toJson(), isCreate: true), SetOptions(merge: true));
    return item;
  }

  @override
  Future<void> deleteServiceItem(String serviceId) async {
    await _firestore.collection(FirestoreCollections.services).doc(serviceId).delete();
  }

  @override
  Future<GalleryImageModel> saveGalleryImage(GalleryImageModel image) async {
    await _firestore.collection(FirestoreCollections.providerGallery).doc(image.imageId).set(FirestoreJson.withServerAudit(image.toJson(), isCreate: true), SetOptions(merge: true));
    return image;
  }

  @override
  Future<void> deleteGalleryImage(String imageId) async {
    await _firestore.collection(FirestoreCollections.providerGallery).doc(imageId).delete();
  }

  @override
  Future<List<GalleryImageModel>> reorderGallery({required String providerId, required int oldIndex, required int newIndex}) async {
    final images = await _loadGallery(providerId);
    if (oldIndex < 0 || oldIndex >= images.length || newIndex < 0 || newIndex > images.length) return images;
    if (newIndex > oldIndex) newIndex -= 1;
    final mutable = images.toList(growable: true);
    final moved = mutable.removeAt(oldIndex);
    mutable.insert(newIndex, moved);
    final batch = _firestore.batch();
    final ordered = <GalleryImageModel>[];
    for (var index = 0; index < mutable.length; index += 1) {
      final next = mutable[index].copyWith(sortOrder: index);
      ordered.add(next);
      batch.set(_firestore.collection(FirestoreCollections.providerGallery).doc(next.imageId), FirestoreJson.withServerAudit(next.toJson()), SetOptions(merge: true));
    }
    await batch.commit();
    return ordered;
  }

  @override
  Future<ServiceAreaModel> saveServiceArea(ServiceAreaModel area) async {
    await _firestore.collection(FirestoreCollections.serviceAreas).doc(area.areaId).set(FirestoreJson.withServerAudit(area.toJson(), isCreate: true), SetOptions(merge: true));
    return area;
  }

  @override
  Future<void> deleteServiceArea(String areaId) async {
    await _firestore.collection(FirestoreCollections.serviceAreas).doc(areaId).delete();
  }

  Future<List<ProviderServiceItemModel>> _loadServices(String providerId) async {
    final snapshot = await _firestore.collection(FirestoreCollections.services).where('providerId', isEqualTo: providerId).limit(80).get();
    return snapshot.docs.map((doc) => ProviderServiceItemModel.fromJson(FirestoreJson.normalize(doc.data()))).toList(growable: false);
  }

  Future<List<GalleryImageModel>> _loadGallery(String providerId) async {
    final snapshot = await _firestore.collection(FirestoreCollections.providerGallery).where('providerId', isEqualTo: providerId).orderBy('sortOrder').limit(80).get();
    return snapshot.docs.map((doc) => GalleryImageModel.fromJson(FirestoreJson.normalize(doc.data()))).toList(growable: false);
  }

  Future<List<ServiceAreaModel>> _loadAreas(String providerId) async {
    final snapshot = await _firestore.collection(FirestoreCollections.serviceAreas).limit(200).get();
    return snapshot.docs
        .where((doc) => (FirestoreJson.normalize(doc.data())['providerId'] ?? '').toString() == providerId)
        .map((doc) => ServiceAreaModel.fromJson(FirestoreJson.normalize(doc.data())))
        .toList(growable: false);
  }
}
