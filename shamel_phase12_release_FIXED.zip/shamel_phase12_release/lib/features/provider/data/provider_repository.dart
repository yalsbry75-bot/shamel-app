import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../auth/domain/user_model.dart';
import '../domain/gallery_image_model.dart';
import '../domain/provider_profile_model.dart';
import '../domain/provider_service_item_model.dart';
import '../domain/provider_status.dart';
import '../domain/service_area_model.dart';
import 'provider_service.dart';

final providerServiceProvider = Provider<ProviderService>((ref) => FirebaseProviderService());

final providerRepositoryProvider = Provider<ProviderRepository>((ref) {
  return ProviderRepository(ref.watch(providerServiceProvider));
});

class ProviderRepository {
  const ProviderRepository(this._service);

  final ProviderService _service;

  Future<ProviderBundle> loadBundle(String userId) {
    return _service.loadBundle(userId);
  }

  Future<List<ProviderProfileModel>> loadAllProfiles() {
    return _service.loadAllProfiles();
  }

  Future<List<ProviderServiceItemModel>> loadAllServices() {
    return _service.loadAllServices();
  }

  Future<ProviderProfileModel> ensureProfile(UserModel user) async {
    final bundle = await _service.loadBundle(user.userId);
    if (bundle.profile != null) return bundle.profile!;
    final profile = ProviderProfileModel.empty(
      providerId: _id('prv', user.userId),
      userId: user.userId,
      phoneNumber: user.phoneNumber,
    );
    return _service.saveProfile(profile);
  }

  Future<ProviderProfileModel> saveProfile({
    required ProviderProfileModel current,
    required String businessName,
    required String description,
    required String categoryId,
    required String serviceType,
    required String governorate,
    required String district,
    required String address,
    required String phoneNumber,
    required String logoPath,
    required String coverPath,
    required String workingHours,
    required List<String> serviceAreas,
  }) {
    final status = current.status == ProviderStatus.pending && businessName.trim().isNotEmpty ? ProviderStatus.active : current.status;
    final updated = current.copyWith(
      businessName: businessName.trim(),
      description: description.trim(),
      categoryId: categoryId.trim(),
      serviceType: serviceType.trim(),
      governorate: governorate.trim(),
      district: district.trim(),
      address: address.trim(),
      phoneNumber: phoneNumber.trim(),
      logoPath: logoPath.trim(),
      coverPath: coverPath.trim(),
      workingHours: workingHours.trim().isEmpty ? 'من 9 صباحًا إلى 9 مساءً' : workingHours.trim(),
      serviceAreas: serviceAreas.map((item) => item.trim()).where((item) => item.isNotEmpty).toList(growable: false),
      status: status,
    );
    return _service.saveProfile(updated);
  }

  Future<ProviderProfileModel> changeStatus(ProviderProfileModel current, ProviderStatus status) {
    return _service.saveProfile(current.copyWith(status: status));
  }

  Future<ProviderServiceItemModel> addService({
    required String providerId,
    required String name,
    required String description,
    required String category,
    required double? price,
    String? parentServiceId,
  }) {
    final item = ProviderServiceItemModel(
      serviceId: _id('srv', providerId),
      providerId: providerId,
      name: name.trim(),
      description: description.trim(),
      category: category.trim(),
      price: price,
      parentServiceId: parentServiceId,
      createdAt: DateTime.now(),
    );
    return _service.saveServiceItem(item);
  }

  Future<ProviderServiceItemModel> updateServiceStatus(ProviderServiceItemModel item, ProviderStatus status) {
    return _service.saveServiceItem(item.copyWith(status: status));
  }

  Future<void> deleteService(String serviceId) {
    return _service.deleteServiceItem(serviceId);
  }

  Future<GalleryImageModel> addGalleryImage({
    required String providerId,
    required String title,
    required GalleryImageType type,
    required int sortOrder,
  }) {
    final image = GalleryImageModel(
      imageId: _id('img', providerId),
      providerId: providerId,
      title: title.trim(),
      type: type,
      sortOrder: sortOrder,
      createdAt: DateTime.now(),
      localPath: '',
    );
    return _service.saveGalleryImage(image);
  }

  Future<void> deleteGalleryImage(String imageId) {
    return _service.deleteGalleryImage(imageId);
  }

  Future<List<GalleryImageModel>> reorderGallery({required String providerId, required int oldIndex, required int newIndex}) {
    return _service.reorderGallery(providerId: providerId, oldIndex: oldIndex, newIndex: newIndex);
  }

  Future<ServiceAreaModel> addServiceArea({
    required String providerId,
    required String governorate,
    required String district,
    required String neighborhood,
  }) {
    final area = ServiceAreaModel(
      areaId: '${providerId}_${DateTime.now().microsecondsSinceEpoch}',
      providerId: providerId,
      governorate: governorate.trim(),
      district: district.trim(),
      neighborhood: neighborhood.trim(),
      createdAt: DateTime.now(),
    );
    return _service.saveServiceArea(area);
  }

  Future<void> deleteServiceArea(String areaId) {
    return _service.deleteServiceArea(areaId);
  }

  String _id(String prefix, String ownerId) {
    final safeOwner = ownerId.replaceAll(RegExp(r'[^A-Za-z0-9_]'), '');
    return '${prefix}_${safeOwner}_${DateTime.now().microsecondsSinceEpoch}';
  }
}
