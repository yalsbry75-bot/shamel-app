import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/errors/app_exception.dart';
import '../../../../core/utils/ui_state.dart';
import '../../../auth/domain/user_model.dart';
import '../../data/provider_repository.dart';
import '../../domain/gallery_image_model.dart';
import '../../domain/provider_state.dart';
import '../../domain/provider_status.dart';

final providerControllerProvider = StateNotifierProvider<ProviderController, ProviderState>((ref) {
  return ProviderController(ref.watch(providerRepositoryProvider));
});

class ProviderController extends StateNotifier<ProviderState> {
  ProviderController(this._repository) : super(const ProviderState());

  final ProviderRepository _repository;

  Future<void> loadForUser(String userId) async {
    state = state.copyWith(viewState: ViewState.loading, clearError: true, clearMessage: true);
    try {
      final bundle = await _repository.loadBundle(userId);
      state = state.copyWith(
        viewState: bundle.profile == null ? ViewState.empty : ViewState.success,
        profile: bundle.profile,
        clearProfile: bundle.profile == null,
        services: bundle.services,
        gallery: bundle.gallery,
        areas: bundle.areas,
      );
    } catch (error) {
      state = state.copyWith(viewState: ViewState.error, errorMessage: _safeMessage(error));
    }
  }

  Future<void> ensureProviderProfile(UserModel user) async {
    state = state.copyWith(viewState: ViewState.loading, clearError: true, clearMessage: true);
    try {
      final profile = await _repository.ensureProfile(user);
      final bundle = await _repository.loadBundle(user.userId);
      state = state.copyWith(
        viewState: ViewState.success,
        profile: profile,
        services: bundle.services,
        gallery: bundle.gallery,
        areas: bundle.areas,
        message: profile.isCompleted ? 'تم تحميل ملف النشاط' : 'تم إنشاء ملف تجاري مبدئي. أكمل البيانات للظهور.',
      );
    } catch (error) {
      state = state.copyWith(viewState: ViewState.error, errorMessage: _safeMessage(error));
    }
  }

  Future<bool> saveBusinessProfile({
    required String businessName,
    required String description,
    required String categoryId,
    required String serviceType,
    required String governorate,
    required String district,
    required String address,
    required String phoneNumber,
    required String logoPath,
    required String coverPath,
    required String workingHours,
    required List<String> serviceAreas,
  }) async {
    final current = state.profile;
    if (current == null) {
      state = state.copyWith(viewState: ViewState.error, errorMessage: 'أنشئ ملف مقدم الخدمة أولًا.');
      return false;
    }
    state = state.copyWith(viewState: ViewState.loading, clearError: true, clearMessage: true);
    try {
      final updated = await _repository.saveProfile(
        current: current,
        businessName: businessName,
        description: description,
        categoryId: categoryId,
        serviceType: serviceType,
        governorate: governorate,
        district: district,
        address: address,
        phoneNumber: phoneNumber,
        logoPath: logoPath,
        coverPath: coverPath,
        workingHours: workingHours,
        serviceAreas: serviceAreas,
      );
      state = state.copyWith(viewState: ViewState.success, profile: updated, message: 'تم حفظ الملف التجاري');
      return true;
    } catch (error) {
      state = state.copyWith(viewState: ViewState.error, errorMessage: _safeMessage(error));
      return false;
    }
  }

  Future<bool> changeProviderStatus(ProviderStatus status) async {
    final current = state.profile;
    if (current == null) return false;
    state = state.copyWith(viewState: ViewState.loading, clearError: true, clearMessage: true);
    try {
      final updated = await _repository.changeStatus(current, status);
      state = state.copyWith(viewState: ViewState.success, profile: updated, message: 'تم تحديث حالة النشاط إلى ${status.label}');
      return true;
    } catch (error) {
      state = state.copyWith(viewState: ViewState.error, errorMessage: _safeMessage(error));
      return false;
    }
  }

  Future<bool> addService({
    required String name,
    required String description,
    required String category,
    required double? price,
    String? parentServiceId,
  }) async {
    final profile = state.profile;
    if (profile == null) {
      state = state.copyWith(viewState: ViewState.error, errorMessage: 'أكمل الملف التجاري قبل إضافة الخدمات.');
      return false;
    }
    state = state.copyWith(viewState: ViewState.loading, clearError: true, clearMessage: true);
    try {
      final item = await _repository.addService(
        providerId: profile.providerId,
        name: name,
        description: description,
        category: category,
        price: price,
        parentServiceId: parentServiceId,
      );
      state = state.copyWith(viewState: ViewState.success, services: [...state.services, item], message: 'تمت إضافة الخدمة');
      return true;
    } catch (error) {
      state = state.copyWith(viewState: ViewState.error, errorMessage: _safeMessage(error));
      return false;
    }
  }

  Future<void> updateServiceStatus(String serviceId, ProviderStatus status) async {
    final index = state.services.indexWhere((item) => item.serviceId == serviceId);
    if (index == -1) return;
    final item = state.services[index];
    final updated = await _repository.updateServiceStatus(item, status);
    final services = [...state.services];
    services[index] = updated;
    state = state.copyWith(services: services, message: 'تم تحديث حالة الخدمة');
  }

  Future<void> deleteService(String serviceId) async {
    await _repository.deleteService(serviceId);
    final services = state.services.where((item) => item.serviceId != serviceId && item.parentServiceId != serviceId).toList(growable: false);
    state = state.copyWith(services: services, message: 'تم حذف الخدمة');
  }

  Future<bool> addGalleryImage({required String title, required GalleryImageType type}) async {
    final profile = state.profile;
    if (profile == null) {
      state = state.copyWith(viewState: ViewState.error, errorMessage: 'أكمل الملف التجاري قبل إضافة الصور.');
      return false;
    }
    state = state.copyWith(viewState: ViewState.loading, clearError: true, clearMessage: true);
    try {
      final image = await _repository.addGalleryImage(
        providerId: profile.providerId,
        title: title,
        type: type,
        sortOrder: state.gallery.length,
      );
      state = state.copyWith(viewState: ViewState.success, gallery: [...state.gallery, image], message: 'تمت إضافة الصورة');
      return true;
    } catch (error) {
      state = state.copyWith(viewState: ViewState.error, errorMessage: _safeMessage(error));
      return false;
    }
  }

  Future<void> deleteGalleryImage(String imageId) async {
    await _repository.deleteGalleryImage(imageId);
    state = state.copyWith(gallery: state.gallery.where((item) => item.imageId != imageId).toList(growable: false), message: 'تم حذف الصورة');
  }

  Future<void> reorderGallery(int oldIndex, int newIndex) async {
    final profile = state.profile;
    if (profile == null) return;
    final gallery = await _repository.reorderGallery(providerId: profile.providerId, oldIndex: oldIndex, newIndex: newIndex);
    state = state.copyWith(gallery: gallery, message: 'تم ترتيب الصور');
  }

  Future<bool> addServiceArea({required String governorate, required String district, required String neighborhood}) async {
    final profile = state.profile;
    if (profile == null) {
      state = state.copyWith(viewState: ViewState.error, errorMessage: 'أكمل الملف التجاري قبل إضافة مناطق الخدمة.');
      return false;
    }
    try {
      final area = await _repository.addServiceArea(
        providerId: profile.providerId,
        governorate: governorate,
        district: district,
        neighborhood: neighborhood,
      );
      state = state.copyWith(areas: [...state.areas, area], message: 'تمت إضافة منطقة الخدمة');
      return true;
    } catch (error) {
      state = state.copyWith(viewState: ViewState.error, errorMessage: _safeMessage(error));
      return false;
    }
  }

  Future<void> deleteServiceArea(String areaId) async {
    await _repository.deleteServiceArea(areaId);
    state = state.copyWith(areas: state.areas.where((item) => item.areaId != areaId).toList(growable: false), message: 'تم حذف منطقة الخدمة');
  }

  void clearMessages() {
    state = state.copyWith(clearError: true, clearMessage: true);
  }

  String _safeMessage(Object error) {
    if (error is AppException) return error.message;
    return 'تعذر إكمال العملية. حاول مرة أخرى.';
  }
}
