import 'package:flutter/material.dart';

import '../../../../core/widgets/empty_state.dart';
import '../../../../core/widgets/premium_app_bar.dart';
import '../../../../core/widgets/premium_scaffold.dart';

class SubscriptionScreen extends StatelessWidget {
  const SubscriptionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const PremiumScaffold(
      appBar: PremiumAppBar(title: 'الاشتراك'),
      child: Center(
        child: EmptyState(
          title: 'الاشتراك',
          message: 'واجهة الاشتراك جاهزة بدون دفع فعلي أو Backend.',
          icon: Icons.workspace_premium_outlined,
        ),
      ),
    );
  }
}
