import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/utils/ui_state.dart';
import '../../../../core/widgets/empty_state.dart';
import '../../../../core/widgets/glass_container.dart';
import '../../../../core/widgets/premium_app_bar.dart';
import '../../../../core/widgets/premium_scaffold.dart';
import '../../../../core/widgets/shamel_button.dart';
import '../../../../routes/app_routes.dart';
import '../../../../shared/components/stat_card.dart';
import '../../../auth/domain/account_type.dart';
import '../../../auth/presentation/controllers/auth_controller.dart';
import '../../../rating/presentation/controllers/rating_controller.dart';
import '../../../subscription/presentation/controllers/subscription_controller.dart';
import '../../domain/provider_status.dart';
import '../controllers/provider_controller.dart';

class ProviderDashboardScreen extends ConsumerStatefulWidget {
  const ProviderDashboardScreen({super.key});

  @override
  ConsumerState<ProviderDashboardScreen> createState() => _ProviderDashboardScreenState();
}

class _ProviderDashboardScreenState extends ConsumerState<ProviderDashboardScreen> {
  String? _loadedForUser;
  String? _loadedForProvider;

  void _bootstrap() {
    final auth = ref.read(authControllerProvider);
    final user = auth.user;
    if (user == null || user.userType != AccountType.provider) return;
    if (_loadedForUser == user.userId) return;
    _loadedForUser = user.userId;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      ref.read(providerControllerProvider.notifier).ensureProviderProfile(user);
    });
  }

  void _loadDependentData(String providerId) {
    if (_loadedForProvider == providerId) return;
    _loadedForProvider = providerId;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      ref.read(subscriptionControllerProvider.notifier).load(providerId);
      ref.read(ratingControllerProvider.notifier).load(providerId);
    });
  }

  @override
  Widget build(BuildContext context) {
    _bootstrap();
    final providerState = ref.watch(providerControllerProvider);
    final ratingState = ref.watch(ratingControllerProvider);
    final subscriptionState = ref.watch(subscriptionControllerProvider);
    final profile = providerState.profile;
    if (profile != null) _loadDependentData(profile.providerId);

    ref.listen(providerControllerProvider, (previous, next) {
      final message = next.errorMessage ?? next.message;
      if (message != null && message != previous?.message && message != previous?.errorMessage) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
      }
    });

    if (providerState.viewState == ViewState.loading && profile == null) {
      return const PremiumScaffold(
        appBar: PremiumAppBar(title: 'لوحة مقدم الخدمة', subtitle: 'تهيئة الملف التجاري'),
        child: Center(child: CircularProgressIndicator()),
      );
    }

    if (profile == null) {
      return PremiumScaffold(
        appBar: const PremiumAppBar(title: 'لوحة مقدم الخدمة'),
        child: Center(
          child: EmptyState(
            title: 'لا يوجد ملف تجاري',
            message: 'اختر حساب مقدم خدمة ثم أنشئ الملف التجاري للمتابعة.',
            icon: Icons.storefront_outlined,
            actionLabel: 'الانتقال للحساب',
            onAction: () => Navigator.of(context).pushNamed(AppRoutes.profile),
          ),
        ),
      );
    }

    final subscription = subscriptionState.subscription;
    final statusLabel = profile.status.label;
    final subscriptionLabel = subscription?.status.label ?? 'قيد التهيئة';

    return PremiumScaffold(
      appBar: const PremiumAppBar(title: 'لوحة مقدم الخدمة', subtitle: 'إدارة النشاط والجاهزية'),
      child: ListView(
        children: [
          GlassContainer(
            child: Row(
              children: [
                Container(
                  width: 58,
                  height: 58,
                  decoration: BoxDecoration(
                    color: AppColors.primary.withOpacity(0.16),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: const Icon(Icons.storefront_outlined, color: AppColors.primary, size: 30),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(profile.businessName.isEmpty ? 'ملف تجاري غير مكتمل' : profile.businessName, style: AppTextStyles.section),
                      const SizedBox(height: 4),
                      Text('${profile.serviceType.isEmpty ? 'نوع الخدمة غير محدد' : profile.serviceType} • $statusLabel', style: AppTextStyles.caption),
                    ],
                  ),
                ),
                _StatusPill(label: statusLabel, status: profile.status),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(child: StatCard(title: 'الخدمات', value: providerState.services.length.toString(), icon: Icons.design_services_outlined)),
              const SizedBox(width: 12),
              Expanded(child: StatCard(title: 'الصور', value: providerState.gallery.length.toString(), icon: Icons.photo_library_outlined)),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(child: StatCard(title: 'التقييم', value: ratingState.summary.count == 0 ? '—' : ratingState.summary.average.toStringAsFixed(1), icon: Icons.star_border_rounded)),
              const SizedBox(width: 12),
              Expanded(child: StatCard(title: 'الاشتراك', value: subscriptionLabel, icon: Icons.workspace_premium_outlined)),
            ],
          ),
          const SizedBox(height: 16),
          if (!profile.isCompleted)
            GlassContainer(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('إكمال الملف مطلوب', style: AppTextStyles.section),
                  const SizedBox(height: 8),
                  Text('أكمل اسم النشاط، نوع الخدمة، الوصف، المحافظة، والمديرية ليصبح النشاط جاهزًا للظهور.', style: AppTextStyles.caption),
                  const SizedBox(height: 14),
                  ShamelButton.primary(
                    label: 'إكمال الملف التجاري',
                    icon: Icons.edit_note_rounded,
                    onPressed: () => Navigator.of(context).pushNamed(AppRoutes.businessProfileForm),
                  ),
                ],
              ),
            ),
          if (profile.isCompleted) ...[
            ShamelButton.primary(
              label: 'عرض صفحة النشاط العامة',
              icon: Icons.visibility_outlined,
              onPressed: () => Navigator.of(context).pushNamed(AppRoutes.businessProfile),
            ),
            const SizedBox(height: 10),
            ShamelButton.secondary(
              label: 'تعديل الملف التجاري',
              icon: Icons.edit_outlined,
              onPressed: () => Navigator.of(context).pushNamed(AppRoutes.businessProfileForm),
            ),
          ],
          const SizedBox(height: 16),
          _StatusManager(current: profile.status),
        ],
      ),
    );
  }
}

class _StatusManager extends ConsumerWidget {
  const _StatusManager({required this.current});

  final ProviderStatus current;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return GlassContainer(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('حالات مقدم الخدمة', style: AppTextStyles.section),
          const SizedBox(height: 8),
          Text('تعرض هذه الحالات وضع النشاط والاشتراك كما يرد من قاعدة البيانات.', style: AppTextStyles.caption),
          const SizedBox(height: 14),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: ProviderStatus.values.map((status) {
              final selected = current == status;
              return ChoiceChip(
                label: Text(status.label),
                selected: selected,
                onSelected: selected ? null : (_) => ref.read(providerControllerProvider.notifier).changeProviderStatus(status),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}

class _StatusPill extends StatelessWidget {
  const _StatusPill({required this.label, required this.status});

  final String label;
  final ProviderStatus status;

  @override
  Widget build(BuildContext context) {
    final color = switch (status) {
      ProviderStatus.active => AppColors.success,
      ProviderStatus.pending => AppColors.warning,
      ProviderStatus.expired => AppColors.textSecondary,
      ProviderStatus.suspended => AppColors.error,
    };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.16),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: color.withOpacity(0.35)),
      ),
      child: Text(label, style: AppTextStyles.caption.copyWith(color: color, fontWeight: FontWeight.w800)),
    );
  }
}
