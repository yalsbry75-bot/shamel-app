import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/utils/ui_state.dart';
import '../../../../core/widgets/empty_state.dart';
import '../../../../core/widgets/glass_container.dart';
import '../../../../core/widgets/premium_app_bar.dart';
import '../../../../core/widgets/premium_scaffold.dart';
import '../../../../core/widgets/shamel_button.dart';
import '../../../../core/widgets/shamel_text_field.dart';
import '../../domain/provider_service_item_model.dart';
import '../../domain/provider_status.dart';
import '../controllers/provider_controller.dart';

class ServicesManagementScreen extends ConsumerWidget {
  const ServicesManagementScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(providerControllerProvider);
    final profile = state.profile;
    final isLoading = state.viewState == ViewState.loading;

    if (profile == null) {
      return const PremiumScaffold(
        appBar: PremiumAppBar(title: 'إدارة الخدمات'),
        child: Center(
          child: EmptyState(
            title: 'الملف التجاري مطلوب',
            message: 'يجب إنشاء ملف مقدم الخدمة قبل إدارة الخدمات.',
            icon: Icons.design_services_outlined,
          ),
        ),
      );
    }

    return PremiumScaffold(
      appBar: PremiumAppBar(
        title: 'إدارة الخدمات',
        subtitle: 'خدمات رئيسية وفرعية بدون طلبات فعلية',
        actions: [
          IconButton(
            onPressed: isLoading ? null : () => _showServiceSheet(context, ref),
            icon: const Icon(Icons.add_circle_outline_rounded),
          ),
        ],
      ),
      child: ListView(
        children: [
          ShamelButton.primary(
            label: 'إضافة خدمة',
            icon: Icons.add_rounded,
            isLoading: isLoading,
            onPressed: isLoading ? null : () => _showServiceSheet(context, ref),
          ),
          const SizedBox(height: 14),
          if (state.services.isEmpty)
            const EmptyState(
              title: 'لا توجد خدمات',
              message: 'أضف خدمة رئيسية أو فرعية ليصبح الملف التجاري أكثر جاهزية.',
              icon: Icons.design_services_outlined,
            )
          else
            ...state.mainServices.map((service) {
              final children = state.subServicesOf(service.serviceId);
              return _ServiceTile(service: service, children: children);
            }),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  void _showServiceSheet(BuildContext context, WidgetRef ref) {
    final nameController = TextEditingController();
    final descriptionController = TextEditingController();
    final categoryController = TextEditingController();
    final priceController = TextEditingController();
    String? parentServiceId;
    final services = ref.read(providerControllerProvider).mainServices;

    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return Padding(
              padding: EdgeInsets.fromLTRB(20, 12, 20, 20 + MediaQuery.of(context).viewInsets.bottom),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('إضافة خدمة', style: AppTextStyles.section),
                    const SizedBox(height: 12),
                    ShamelTextField(hintText: 'اسم الخدمة', controller: nameController, prefixIcon: Icons.design_services_outlined),
                    const SizedBox(height: 12),
                    ShamelTextField(hintText: 'وصف الخدمة', controller: descriptionController, prefixIcon: Icons.description_outlined, maxLines: 3),
                    const SizedBox(height: 12),
                    ShamelTextField(hintText: 'التصنيف', controller: categoryController, prefixIcon: Icons.category_outlined),
                    const SizedBox(height: 12),
                    ShamelTextField(
                      hintText: 'سعر تقريبي اختياري',
                      controller: priceController,
                      keyboardType: TextInputType.number,
                      inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9.]'))],
                      prefixIcon: Icons.payments_outlined,
                    ),
                    if (services.isNotEmpty) ...[
                      const SizedBox(height: 12),
                      DropdownButtonFormField<String?>(
                        value: parentServiceId,
                        decoration: const InputDecoration(prefixIcon: Icon(Icons.account_tree_outlined), hintText: 'نوع الخدمة'),
                        items: [
                          const DropdownMenuItem<String?>(value: null, child: Text('خدمة رئيسية')),
                          ...services.map((item) => DropdownMenuItem<String?>(value: item.serviceId, child: Text('فرعية من: ${item.name}'))),
                        ],
                        onChanged: (value) => setState(() => parentServiceId = value),
                      ),
                    ],
                    const SizedBox(height: 18),
                    ShamelButton.primary(
                      label: 'حفظ الخدمة',
                      onPressed: () async {
                        final price = double.tryParse(priceController.text.trim());
                        final success = await ref.read(providerControllerProvider.notifier).addService(
                              name: nameController.text,
                              description: descriptionController.text,
                              category: categoryController.text,
                              price: price,
                              parentServiceId: parentServiceId,
                            );
                        if (success && context.mounted) Navigator.of(context).pop();
                      },
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
}

class _ServiceTile extends ConsumerWidget {
  const _ServiceTile({required this.service, required this.children});

  final ProviderServiceItemModel service;
  final List<ProviderServiceItemModel> children;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: GlassContainer(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(color: AppColors.primary.withOpacity(0.15), borderRadius: BorderRadius.circular(16)),
                  child: const Icon(Icons.design_services_outlined, color: AppColors.primary),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(service.name, style: AppTextStyles.section),
                      const SizedBox(height: 4),
                      Text(service.category.isEmpty ? 'بدون تصنيف' : service.category, style: AppTextStyles.caption),
                    ],
                  ),
                ),
                PopupMenuButton<String>(
                  onSelected: (value) {
                    if (value == 'delete') {
                      ref.read(providerControllerProvider.notifier).deleteService(service.serviceId);
                    } else if (value == 'suspend') {
                      ref.read(providerControllerProvider.notifier).updateServiceStatus(service.serviceId, ProviderStatus.suspended);
                    } else if (value == 'active') {
                      ref.read(providerControllerProvider.notifier).updateServiceStatus(service.serviceId, ProviderStatus.active);
                    }
                  },
                  itemBuilder: (context) => const [
                    PopupMenuItem(value: 'active', child: Text('تفعيل')),
                    PopupMenuItem(value: 'suspend', child: Text('إيقاف')),
                    PopupMenuItem(value: 'delete', child: Text('حذف')),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 10),
            Text(service.description.isEmpty ? 'لا يوجد وصف.' : service.description, style: AppTextStyles.caption),
            if (service.price != null) ...[
              const SizedBox(height: 8),
              Text('السعر التقريبي: ${service.price!.toStringAsFixed(0)}', style: AppTextStyles.body),
            ],
            if (children.isNotEmpty) ...[
              const SizedBox(height: 12),
              Text('الخدمات الفرعية', style: AppTextStyles.caption.copyWith(fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              ...children.map((child) => ListTile(
                    contentPadding: EdgeInsets.zero,
                    dense: true,
                    leading: const Icon(Icons.subdirectory_arrow_left_rounded),
                    title: Text(child.name),
                    subtitle: Text(child.description),
                    trailing: IconButton(
                      onPressed: () => ref.read(providerControllerProvider.notifier).deleteService(child.serviceId),
                      icon: const Icon(Icons.delete_outline_rounded),
                    ),
                  )),
            ],
          ],
        ),
      ),
    );
  }
}
