import 'package:flutter/material.dart';

import '../../../../core/widgets/premium_bottom_nav.dart';
import '../../../profile/presentation/screens/profile_screen.dart';
import '../../../subscription/presentation/screens/subscription_screen.dart';
import 'incoming_orders_screen.dart';
import 'provider_dashboard_screen.dart';
import 'services_management_screen.dart';

class ProviderShell extends StatefulWidget {
  const ProviderShell({super.key});

  @override
  State<ProviderShell> createState() => _ProviderShellState();
}

class _ProviderShellState extends State<ProviderShell> {
  int _index = 0;

  final _pages = const [
    ProviderDashboardScreen(),
    IncomingOrdersScreen(isEmbedded: true),
    ServicesManagementScreen(),
    SubscriptionScreen(),
    ProfileScreen(isEmbedded: true),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: _index, children: _pages),
      bottomNavigationBar: PremiumBottomNav(
        currentIndex: _index,
        onTap: (value) => setState(() => _index = value),
        items: const [
          PremiumNavItem(label: 'لوحة', icon: Icons.dashboard_rounded),
          PremiumNavItem(label: 'الطلبات', icon: Icons.receipt_long_rounded),
          PremiumNavItem(label: 'خدمات', icon: Icons.design_services_outlined),
          PremiumNavItem(label: 'اشتراك', icon: Icons.workspace_premium_outlined),
          PremiumNavItem(label: 'حسابي', icon: Icons.person_outline_rounded),
        ],
      ),
    );
  }
}
