import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_radius.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/utils/ui_state.dart';
import '../../../../core/widgets/empty_state.dart';
import '../../../../core/widgets/error_state.dart';
import '../../../../core/widgets/glass_container.dart';
import '../../../../core/widgets/premium_app_bar.dart';
import '../../../../core/widgets/premium_scaffold.dart';
import '../../../../core/widgets/shamel_button.dart';
import '../../../../core/widgets/shamel_text_field.dart';
import '../../../../routes/app_routes.dart';
import '../../../auth/presentation/controllers/auth_controller.dart';
import '../../../rating/presentation/controllers/rating_controller.dart';
import '../../domain/gallery_image_model.dart';
import '../../domain/provider_profile_model.dart';
import '../../domain/provider_status.dart';
import '../controllers/provider_controller.dart';

class BusinessProfileScreen extends ConsumerStatefulWidget {
  const BusinessProfileScreen({super.key, this.isEmbedded = false});

  final bool isEmbedded;

  @override
  ConsumerState<BusinessProfileScreen> createState() => _BusinessProfileScreenState();
}

class _BusinessProfileScreenState extends ConsumerState<BusinessProfileScreen> {
  String? _loadedRatingsFor;

  void _loadRatings(String providerId) {
    if (_loadedRatingsFor == providerId) return;
    _loadedRatingsFor = providerId;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      ref.read(ratingControllerProvider.notifier).load(providerId);
    });
  }

  @override
  Widget build(BuildContext context) {
    final providerState = ref.watch(providerControllerProvider);
    final ratingState = ref.watch(ratingControllerProvider);
    final profile = providerState.profile;
    if (profile != null) _loadRatings(profile.providerId);

    ref.listen(providerControllerProvider, (previous, next) {
      final message = next.errorMessage ?? next.message;
      if (message != null && message != previous?.message && message != previous?.errorMessage) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
      }
    });
    ref.listen(ratingControllerProvider, (previous, next) {
      final message = next.errorMessage ?? next.message;
      if (message != null && message != previous?.message && message != previous?.errorMessage) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
      }
    });

    if (providerState.viewState == ViewState.error && profile == null) {
      return PremiumScaffold(
        appBar: PremiumAppBar(title: 'صفحة مقدم الخدمة', showBack: !widget.isEmbedded),
        child: ErrorState(message: providerState.errorMessage ?? 'تعذر تحميل ملف النشاط.'),
      );
    }

    if (profile == null) {
      return PremiumScaffold(
        appBar: PremiumAppBar(title: 'ملف النشاط', showBack: !widget.isEmbedded),
        child: Center(
          child: EmptyState(
            title: 'لم يتم إنشاء الملف التجاري',
            message: 'سيتم إنشاء ملف تجاري تلقائيًا عند اختيار حساب مقدم خدمة.',
            icon: Icons.storefront_outlined,
            actionLabel: 'فتح لوحة مقدم الخدمة',
            onAction: widget.isEmbedded ? null : () => Navigator.of(context).pushNamed(AppRoutes.providerShell),
          ),
        ),
      );
    }

    return PremiumScaffold(
      appBar: PremiumAppBar(
        title: widget.isEmbedded ? 'ملف النشاط' : 'صفحة مقدم الخدمة',
        subtitle: 'صفحة عامة جاهزة للربط لاحقًا',
        showBack: !widget.isEmbedded,
        actions: [
          IconButton(
            onPressed: () => Navigator.of(context).pushNamed(AppRoutes.businessProfileForm),
            icon: const Icon(Icons.edit_outlined),
          ),
        ],
      ),
      child: ListView(
        children: [
          _BusinessHeader(profile: profile, average: ratingState.summary.average, count: ratingState.summary.count),
          const SizedBox(height: 14),
          _InfoSection(profile: profile),
          const SizedBox(height: 14),
          _ActionSection(profile: profile),
          const SizedBox(height: 14),
          _ServiceAreasSection(profile: profile),
          const SizedBox(height: 14),
          _GallerySection(images: providerState.gallery),
          const SizedBox(height: 14),
          _RatingSection(providerId: profile.providerId),
          const SizedBox(height: 28),
        ],
      ),
    );
  }
}

class _BusinessHeader extends StatelessWidget {
  const _BusinessHeader({required this.profile, required this.average, required this.count});

  final ProviderProfileModel profile;
  final double average;
  final int count;

  @override
  Widget build(BuildContext context) {
    return GlassContainer(
      padding: EdgeInsets.zero,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            height: 142,
            width: double.infinity,
            decoration: BoxDecoration(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(AppRadius.lg)),
              gradient: LinearGradient(
                colors: [AppColors.primary.withOpacity(0.5), AppColors.surfaceHigh],
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
              ),
            ),
            child: Center(
              child: Icon(profile.coverPath.isEmpty ? Icons.photo_size_select_actual_outlined : Icons.image_rounded, size: 46, color: AppColors.textPrimary.withOpacity(0.72)),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(18),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 72,
                  height: 72,
                  decoration: BoxDecoration(
                    color: AppColors.background,
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: Icon(profile.logoPath.isEmpty ? Icons.storefront_outlined : Icons.verified_rounded, color: AppColors.primary, size: 34),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(profile.businessName.isEmpty ? 'اسم النشاط غير مكتمل' : profile.businessName, style: AppTextStyles.title),
                      const SizedBox(height: 6),
                      Row(
                        children: [
                          const Icon(Icons.star_rounded, color: AppColors.accentGold, size: 20),
                          const SizedBox(width: 4),
                          Text(count == 0 ? 'لا توجد تقييمات' : '${average.toStringAsFixed(1)} ($count)', style: AppTextStyles.caption),
                          const SizedBox(width: 10),
                          _StatusBadge(status: profile.status),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _InfoSection extends StatelessWidget {
  const _InfoSection({required this.profile});

  final ProviderProfileModel profile;

  @override
  Widget build(BuildContext context) {
    return GlassContainer(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('معلومات الخدمة', style: AppTextStyles.section),
          const SizedBox(height: 12),
          Text(profile.description.isEmpty ? 'لا يوجد وصف مكتمل بعد.' : profile.description, style: AppTextStyles.body),
          const SizedBox(height: 14),
          _InfoRow(icon: Icons.design_services_outlined, label: 'نوع الخدمة', value: profile.serviceType.isEmpty ? 'غير محدد' : profile.serviceType),
          _InfoRow(icon: Icons.schedule_outlined, label: 'أوقات العمل', value: profile.workingHours),
          _InfoRow(icon: Icons.place_outlined, label: 'الموقع', value: '${profile.governorate} - ${profile.district}'),
          _InfoRow(icon: Icons.location_on_outlined, label: 'العنوان', value: profile.address.isEmpty ? 'غير محدد' : profile.address),
        ],
      ),
    );
  }
}

class _ActionSection extends StatelessWidget {
  const _ActionSection({required this.profile});

  final ProviderProfileModel profile;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: ShamelButton.secondary(
            label: 'اتصال',
            icon: Icons.call_outlined,
            onPressed: () => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('جاهز للربط بالاتصال: ${profile.phoneNumber}'))),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: ShamelButton.secondary(
            label: 'واتساب',
            icon: Icons.chat_bubble_outline_rounded,
            onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('زر واتساب جاهز للربط في مرحلة لاحقة.'))),
          ),
        ),
      ],
    );
  }
}

class _ServiceAreasSection extends StatelessWidget {
  const _ServiceAreasSection({required this.profile});

  final ProviderProfileModel profile;

  @override
  Widget build(BuildContext context) {
    return GlassContainer(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('مناطق العمل', style: AppTextStyles.section),
          const SizedBox(height: 10),
          if (profile.serviceAreas.isEmpty)
            Text('لم يتم تحديد الأحياء بعد.', style: AppTextStyles.caption)
          else
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: profile.serviceAreas.map((area) => Chip(label: Text(area), avatar: const Icon(Icons.near_me_outlined, size: 16))).toList(),
            ),
        ],
      ),
    );
  }
}

class _GallerySection extends ConsumerWidget {
  const _GallerySection({required this.images});

  final List<GalleryImageModel> images;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return GlassContainer(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text('معرض الصور', style: AppTextStyles.section)),
              TextButton.icon(
                onPressed: () => _showAddGallerySheet(context, ref),
                icon: const Icon(Icons.add_photo_alternate_outlined),
                label: const Text('إضافة'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          if (images.isEmpty)
            Text('لا توجد صور مضافة. أضف صور أعمال أو منتجات أو معدات عند توفرها.', style: AppTextStyles.caption)
          else
            ReorderableListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: images.length,
              onReorder: (oldIndex, newIndex) => ref.read(providerControllerProvider.notifier).reorderGallery(oldIndex, newIndex),
              itemBuilder: (context, index) {
                final image = images[index];
                return ListTile(
                  key: ValueKey(image.imageId),
                  leading: const Icon(Icons.drag_indicator_rounded),
                  title: Text(image.title),
                  subtitle: Text(image.type.label),
                  trailing: IconButton(
                    onPressed: () => ref.read(providerControllerProvider.notifier).deleteGalleryImage(image.imageId),
                    icon: const Icon(Icons.delete_outline_rounded),
                  ),
                );
              },
            ),
        ],
      ),
    );
  }

  void _showAddGallerySheet(BuildContext context, WidgetRef ref) {
    final titleController = TextEditingController();
    var selectedType = GalleryImageType.work;
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return Padding(
              padding: EdgeInsets.fromLTRB(20, 12, 20, 20 + MediaQuery.of(context).viewInsets.bottom),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('إضافة صورة للمعرض', style: AppTextStyles.section),
                  const SizedBox(height: 12),
                  ShamelTextField(hintText: 'عنوان الصورة', controller: titleController, prefixIcon: Icons.title_outlined),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<GalleryImageType>(
                    value: selectedType,
                    decoration: const InputDecoration(prefixIcon: Icon(Icons.category_outlined), hintText: 'نوع الصورة'),
                    items: GalleryImageType.values.map((type) => DropdownMenuItem(value: type, child: Text(type.label))).toList(),
                    onChanged: (value) => setState(() => selectedType = value ?? GalleryImageType.work),
                  ),
                  const SizedBox(height: 18),
                  ShamelButton.primary(
                    label: 'حفظ الصورة',
                    onPressed: () async {
                      final success = await ref.read(providerControllerProvider.notifier).addGalleryImage(title: titleController.text, type: selectedType);
                      if (success && context.mounted) Navigator.of(context).pop();
                    },
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}

class _RatingSection extends ConsumerWidget {
  const _RatingSection({required this.providerId});

  final String providerId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final ratingState = ref.watch(ratingControllerProvider);
    final userId = ref.watch(authControllerProvider).user?.userId ?? '';
    return GlassContainer(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text('التقييمات', style: AppTextStyles.section)),
              TextButton.icon(
                onPressed: () => ref.read(ratingControllerProvider.notifier).addRating(
                      providerId: providerId,
                      userId: userId,
                      stars: 5,
                      comment: 'تقييم جديد للخدمة.',
                    ),
                icon: const Icon(Icons.star_outline_rounded),
                label: const Text('إضافة تقييم'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          if (ratingState.ratings.isEmpty)
            Text('لا توجد تعليقات بعد.', style: AppTextStyles.caption)
          else
            ...ratingState.ratings.map((rating) {
              return ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const CircleAvatar(child: Icon(Icons.person_outline_rounded)),
                title: Row(
                  children: [
                    ...List.generate(5, (index) => Icon(index < rating.stars ? Icons.star_rounded : Icons.star_border_rounded, color: AppColors.accentGold, size: 18)),
                  ],
                ),
                subtitle: Text(rating.comment),
                trailing: IconButton(
                  onPressed: () => ref.read(ratingControllerProvider.notifier).deleteRating(providerId: providerId, ratingId: rating.ratingId),
                  icon: const Icon(Icons.delete_outline_rounded),
                ),
              );
            }),
        ],
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  const _InfoRow({required this.icon, required this.label, required this.value});

  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: Row(
        children: [
          Icon(icon, color: AppColors.textSecondary, size: 20),
          const SizedBox(width: 8),
          Text('$label: ', style: AppTextStyles.caption),
          Expanded(child: Text(value, style: AppTextStyles.body)),
        ],
      ),
    );
  }
}

class _StatusBadge extends StatelessWidget {
  const _StatusBadge({required this.status});

  final ProviderStatus status;

  @override
  Widget build(BuildContext context) {
    final color = switch (status) {
      ProviderStatus.active => AppColors.success,
      ProviderStatus.pending => AppColors.warning,
      ProviderStatus.expired => AppColors.textSecondary,
      ProviderStatus.suspended => AppColors.error,
    };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(color: color.withOpacity(0.14), borderRadius: BorderRadius.circular(999)),
      child: Text(status.label, style: AppTextStyles.caption.copyWith(color: color)),
    );
  }
}
