import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/utils/ui_state.dart';
import '../../../../core/widgets/empty_state.dart';
import '../../../../core/widgets/error_state.dart';
import '../../../../core/widgets/premium_app_bar.dart';
import '../../../../core/widgets/premium_scaffold.dart';
import '../../../auth/domain/account_type.dart';
import '../../../auth/presentation/controllers/auth_controller.dart';
import '../../../orders/domain/service_order_model.dart';
import '../../../orders/presentation/controllers/orders_controller.dart';
import '../../../orders/presentation/widgets/service_order_card.dart';
import '../controllers/provider_controller.dart';

class IncomingOrdersScreen extends ConsumerStatefulWidget {
  const IncomingOrdersScreen({super.key, this.isEmbedded = false});

  final bool isEmbedded;

  @override
  ConsumerState<IncomingOrdersScreen> createState() => _IncomingOrdersScreenState();
}

class _IncomingOrdersScreenState extends ConsumerState<IncomingOrdersScreen> with SingleTickerProviderStateMixin {
  String? _loadedForUser;
  String? _loadedForProvider;
  late final TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _bootstrap() {
    final user = ref.read(authControllerProvider).user;
    if (user == null || user.userType != AccountType.provider) return;
    if (_loadedForUser != user.userId) {
      _loadedForUser = user.userId;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        ref.read(providerControllerProvider.notifier).ensureProviderProfile(user);
      });
    }
    final profile = ref.read(providerControllerProvider).profile;
    if (profile != null && _loadedForProvider != profile.providerId) {
      _loadedForProvider = profile.providerId;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        ref.read(ordersControllerProvider.notifier).loadProviderOrders(profile.providerId);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    _bootstrap();
    final user = ref.watch(authControllerProvider).user;
    final profile = ref.watch(providerControllerProvider).profile;
    final state = ref.watch(ordersControllerProvider);

    ref.listen(ordersControllerProvider, (previous, next) {
      final message = next.errorMessage ?? next.message;
      if (message != null && message != previous?.message && message != previous?.errorMessage) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
      }
    });

    return PremiumScaffold(
      appBar: widget.isEmbedded
          ? const PremiumAppBar(title: 'طلبات مقدم الخدمة')
          : const PremiumAppBar(title: 'طلبات مقدم الخدمة', showBack: true),
      child: Builder(
        builder: (context) {
          if (user == null || user.userType != AccountType.provider) {
            return const Center(
              child: EmptyState(
                title: 'حساب مقدم خدمة مطلوب',
                message: 'هذه الصفحة مخصصة لمقدمي الخدمات فقط.',
                icon: Icons.lock_outline_rounded,
              ),
            );
          }
          if (profile == null) {
            return const Center(child: CircularProgressIndicator());
          }
          if (state.viewState == ViewState.loading) return const Center(child: CircularProgressIndicator());
          if (state.viewState == ViewState.error) {
            return Center(
              child: ErrorState(
                message: state.errorMessage ?? 'حدث خطأ غير متوقع.',
                onRetry: () => ref.read(ordersControllerProvider.notifier).loadProviderOrders(profile.providerId),
              ),
            );
          }
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TabBar(
                controller: _tabController,
                isScrollable: true,
                tabs: const [
                  Tab(text: 'الجديدة'),
                  Tab(text: 'المقبولة'),
                  Tab(text: 'المكتملة'),
                  Tab(text: 'المرفوضة'),
                ],
              ),
              const SizedBox(height: 12),
              Expanded(
                child: TabBarView(
                  controller: _tabController,
                  children: [
                    _OrdersList(title: 'الطلبات الجديدة', orders: state.pendingOrders, onRefresh: () => ref.read(ordersControllerProvider.notifier).loadProviderOrders(profile.providerId)),
                    _OrdersList(title: 'الطلبات المقبولة', orders: state.acceptedOrders, onRefresh: () => ref.read(ordersControllerProvider.notifier).loadProviderOrders(profile.providerId)),
                    _OrdersList(title: 'الطلبات المكتملة', orders: state.completedOrders, onRefresh: () => ref.read(ordersControllerProvider.notifier).loadProviderOrders(profile.providerId)),
                    _OrdersList(title: 'الطلبات المرفوضة/الملغية', orders: state.rejectedOrders, onRefresh: () => ref.read(ordersControllerProvider.notifier).loadProviderOrders(profile.providerId)),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _OrdersList extends StatelessWidget {
  const _OrdersList({required this.title, required this.orders, required this.onRefresh});

  final String title;
  final List<ServiceOrderModel> orders;
  final Future<void> Function() onRefresh;

  @override
  Widget build(BuildContext context) {
    if (orders.isEmpty) {
      return RefreshIndicator(
        onRefresh: onRefresh,
        child: ListView(
          children: const [
            SizedBox(height: 96),
            EmptyState(
              title: 'لا توجد طلبات',
              message: 'اسحب للتحديث أو انتظر وصول طلبات جديدة.',
              icon: Icons.call_received_rounded,
            ),
          ],
        ),
      );
    }
    return RefreshIndicator(
      onRefresh: onRefresh,
      child: ListView(
        children: [
          Text(title, style: AppTextStyles.title),
          const SizedBox(height: 10),
          ...orders.map((order) => Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: ServiceOrderCard(order: order, subtitlePrefix: 'موقع العميل'),
              )),
          const SizedBox(height: 120),
        ],
      ),
    );
  }
}
