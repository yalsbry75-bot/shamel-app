import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/utils/ui_state.dart';
import '../../../../core/widgets/empty_state.dart';
import '../../../../core/widgets/glass_container.dart';
import '../../../../core/widgets/premium_app_bar.dart';
import '../../../../core/widgets/premium_scaffold.dart';
import '../../../../core/widgets/shamel_button.dart';
import '../../../../core/widgets/shamel_text_field.dart';
import '../../../../core/widgets/cloud_image_picker_field.dart';
import '../controllers/provider_controller.dart';

class BusinessProfileFormScreen extends ConsumerStatefulWidget {
  const BusinessProfileFormScreen({super.key});

  @override
  ConsumerState<BusinessProfileFormScreen> createState() => _BusinessProfileFormScreenState();
}

class _BusinessProfileFormScreenState extends ConsumerState<BusinessProfileFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _businessNameController = TextEditingController();
  final _serviceTypeController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _governorateController = TextEditingController();
  final _districtController = TextEditingController();
  final _addressController = TextEditingController();
  final _phoneController = TextEditingController();
  final _logoController = TextEditingController();
  final _coverController = TextEditingController();
  final _workingHoursController = TextEditingController();
  final _serviceAreasController = TextEditingController();
  bool _hydrated = false;

  @override
  void dispose() {
    _businessNameController.dispose();
    _serviceTypeController.dispose();
    _descriptionController.dispose();
    _governorateController.dispose();
    _districtController.dispose();
    _addressController.dispose();
    _phoneController.dispose();
    _logoController.dispose();
    _coverController.dispose();
    _workingHoursController.dispose();
    _serviceAreasController.dispose();
    super.dispose();
  }

  void _hydrate() {
    if (_hydrated) return;
    final profile = ref.read(providerControllerProvider).profile;
    if (profile == null) return;
    _businessNameController.text = profile.businessName;
    _serviceTypeController.text = profile.serviceType;
    _descriptionController.text = profile.description;
    _governorateController.text = profile.governorate;
    _districtController.text = profile.district;
    _addressController.text = profile.address;
    _phoneController.text = profile.phoneNumber.replaceAll('+967', '');
    _logoController.text = profile.logoPath;
    _coverController.text = profile.coverPath;
    _workingHoursController.text = profile.workingHours;
    _serviceAreasController.text = profile.serviceAreas.join('، ');
    _hydrated = true;
  }

  @override
  Widget build(BuildContext context) {
    _hydrate();
    final state = ref.watch(providerControllerProvider);
    final profile = state.profile;
    final isLoading = state.viewState == ViewState.loading;

    if (profile == null) {
      return const PremiumScaffold(
        appBar: PremiumAppBar(title: 'إنشاء الملف التجاري', showBack: true),
        child: Center(
          child: EmptyState(
            title: 'لا يوجد ملف مقدم خدمة',
            message: 'يجب اختيار نوع الحساب كمقدم خدمة أولًا.',
            icon: Icons.storefront_outlined,
          ),
        ),
      );
    }

    return PremiumScaffold(
      appBar: const PremiumAppBar(title: 'الملف التجاري', subtitle: 'بيانات محفوظة في قاعدة البيانات والتخزين السحابي', showBack: true),
      child: Form(
        key: _formKey,
        child: ListView(
          children: [
            GlassContainer(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('البيانات الأساسية', style: AppTextStyles.section),
                  const SizedBox(height: 14),
                  ShamelTextField(
                    hintText: 'اسم النشاط',
                    controller: _businessNameController,
                    prefixIcon: Icons.storefront_outlined,
                    validator: _required,
                  ),
                  const SizedBox(height: 12),
                  ShamelTextField(
                    hintText: 'نوع الخدمة',
                    controller: _serviceTypeController,
                    prefixIcon: Icons.design_services_outlined,
                    validator: _required,
                  ),
                  const SizedBox(height: 12),
                  ShamelTextField(
                    hintText: 'وصف النشاط والخدمات',
                    controller: _descriptionController,
                    prefixIcon: Icons.description_outlined,
                    maxLines: 4,
                    validator: _required,
                  ),
                  const SizedBox(height: 12),
                  ShamelTextField(
                    hintText: 'رقم التواصل',
                    controller: _phoneController,
                    keyboardType: TextInputType.phone,
                    prefixIcon: Icons.phone_outlined,
                    inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                    validator: _required,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            GlassContainer(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('الموقع ومناطق العمل', style: AppTextStyles.section),
                  const SizedBox(height: 14),
                  ShamelTextField(
                    hintText: 'المحافظة',
                    controller: _governorateController,
                    prefixIcon: Icons.location_city_outlined,
                    validator: _required,
                  ),
                  const SizedBox(height: 12),
                  ShamelTextField(
                    hintText: 'المديرية',
                    controller: _districtController,
                    prefixIcon: Icons.map_outlined,
                    validator: _required,
                  ),
                  const SizedBox(height: 12),
                  ShamelTextField(
                    hintText: 'العنوان التفصيلي',
                    controller: _addressController,
                    prefixIcon: Icons.place_outlined,
                  ),
                  const SizedBox(height: 12),
                  ShamelTextField(
                    hintText: 'الأحياء المفصولة بفواصل: التحرير، الجامعة، الحصبة',
                    controller: _serviceAreasController,
                    prefixIcon: Icons.near_me_outlined,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            GlassContainer(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('الصور وأوقات العمل', style: AppTextStyles.section),
                  const SizedBox(height: 14),
                  CloudImagePickerField(
                    hintText: 'صورة الشعار',
                    controller: _logoController,
                    storagePathPrefix: 'providers/${profile.providerId}/logo',
                  ),
                  const SizedBox(height: 12),
                  CloudImagePickerField(
                    hintText: 'صورة الغلاف',
                    controller: _coverController,
                    storagePathPrefix: 'providers/${profile.providerId}/cover',
                  ),
                  const SizedBox(height: 12),
                  ShamelTextField(
                    hintText: 'أوقات العمل',
                    controller: _workingHoursController,
                    prefixIcon: Icons.schedule_outlined,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            ShamelButton.primary(
              label: 'حفظ الملف التجاري',
              icon: Icons.save_outlined,
              isLoading: isLoading,
              onPressed: isLoading ? null : _save,
            ),
            const SizedBox(height: 28),
          ],
        ),
      ),
    );
  }

  String? _required(String? value) {
    if (value == null || value.trim().isEmpty) return 'هذا الحقل مطلوب';
    return null;
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final areas = _serviceAreasController.text
        .split(RegExp(r'[,،]'))
        .map((item) => item.trim())
        .where((item) => item.isNotEmpty)
        .toList(growable: false);
    final phone = _phoneController.text.startsWith('+967') ? _phoneController.text : '+967${_phoneController.text}';
    final success = await ref.read(providerControllerProvider.notifier).saveBusinessProfile(
          businessName: _businessNameController.text,
          description: _descriptionController.text,
          categoryId: _serviceTypeController.text,
          serviceType: _serviceTypeController.text,
          governorate: _governorateController.text,
          district: _districtController.text,
          address: _addressController.text,
          phoneNumber: phone,
          logoPath: _logoController.text,
          coverPath: _coverController.text,
          workingHours: _workingHoursController.text,
          serviceAreas: areas,
        );
    if (success && mounted) Navigator.of(context).pop();
  }
}
