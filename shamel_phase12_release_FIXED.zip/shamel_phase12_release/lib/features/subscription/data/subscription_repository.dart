import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../domain/subscription_model.dart';
import '../domain/subscription_status.dart';
import 'subscription_service.dart';

final subscriptionServiceProvider = Provider<SubscriptionService>((ref) => FirebaseSubscriptionService());

final subscriptionRepositoryProvider = Provider<SubscriptionRepository>((ref) {
  return SubscriptionRepository(ref.watch(subscriptionServiceProvider));
});

class SubscriptionRepository {
  const SubscriptionRepository(this._service);

  final SubscriptionService _service;

  Future<SubscriptionModel> ensureSubscription(String providerId) async {
    final current = await _service.getByProviderId(providerId);
    if (current != null) return current;
    return _service.save(SubscriptionModel.pending(subscriptionId: _id(providerId), providerId: providerId));
  }

  Future<SubscriptionModel> updateStatus({
    required SubscriptionModel current,
    required SubscriptionStatus status,
    SubscriptionPaymentStatus? paymentStatus,
  }) {
    final updated = current.copyWith(
      status: status,
      paymentStatus: paymentStatus ?? current.paymentStatus,
    );
    return _service.save(updated);
  }

  Future<SubscriptionModel> changePlan({required SubscriptionModel current, required SubscriptionPlanType planType}) {
    final now = DateTime.now();
    final updated = current.copyWith(
      planType: planType,
      startDate: now,
      endDate: now.add(const Duration(days: 30)),
      status: SubscriptionStatus.pending,
      paymentStatus: SubscriptionPaymentStatus.unpaid,
    );
    return _service.save(updated);
  }

  String _id(String providerId) {
    final safe = providerId.replaceAll(RegExp(r'[^A-Za-z0-9_]'), '');
    return 'sub_${safe}_${DateTime.now().microsecondsSinceEpoch}';
  }
}
