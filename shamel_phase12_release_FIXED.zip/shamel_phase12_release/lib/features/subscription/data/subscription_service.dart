import '../domain/subscription_model.dart';

import '../../../core/database/firestore_json.dart';
import '../../../core/database/firestore_collections.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
abstract class SubscriptionService {
  Future<SubscriptionModel?> getByProviderId(String providerId);
  Future<SubscriptionModel> save(SubscriptionModel subscription);
}

class FirebaseSubscriptionService implements SubscriptionService {
  FirebaseSubscriptionService({FirebaseFirestore? firestore}) : _firestore = firestore ?? FirebaseFirestore.instance;
  final FirebaseFirestore _firestore;

  @override
  Future<SubscriptionModel?> getByProviderId(String providerId) async {
    final snapshot = await _firestore.collection(FirestoreCollections.subscriptions).where('providerId', isEqualTo: providerId).limit(1).get();
    if (snapshot.docs.isEmpty) return null;
    return SubscriptionModel.fromJson(FirestoreJson.normalize(snapshot.docs.first.data()));
  }

  @override
  Future<SubscriptionModel> save(SubscriptionModel subscription) async {
    await _firestore.collection(FirestoreCollections.subscriptions).doc(subscription.subscriptionId).set(FirestoreJson.withServerAudit(subscription.toJson(), isCreate: true), SetOptions(merge: true));
    return subscription;
  }
}
