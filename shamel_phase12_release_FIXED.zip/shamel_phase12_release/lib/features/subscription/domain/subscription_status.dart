enum SubscriptionStatus { active, pending, expired, suspended }

enum SubscriptionPaymentStatus { unpaid, pending, paid, failed }

enum SubscriptionPlanType { basic, premium, elite }

extension SubscriptionStatusX on SubscriptionStatus {
  String get value {
    switch (this) {
      case SubscriptionStatus.active:
        return 'active';
      case SubscriptionStatus.pending:
        return 'pending';
      case SubscriptionStatus.expired:
        return 'expired';
      case SubscriptionStatus.suspended:
        return 'suspended';
    }
  }

  String get label {
    switch (this) {
      case SubscriptionStatus.active:
        return 'نشط';
      case SubscriptionStatus.pending:
        return 'بانتظار التفعيل';
      case SubscriptionStatus.expired:
        return 'منتهي';
      case SubscriptionStatus.suspended:
        return 'موقوف';
    }
  }

  static SubscriptionStatus fromValue(String value) {
    switch (value) {
      case 'active':
        return SubscriptionStatus.active;
      case 'expired':
        return SubscriptionStatus.expired;
      case 'suspended':
        return SubscriptionStatus.suspended;
      case 'pending':
      default:
        return SubscriptionStatus.pending;
    }
  }
}

extension SubscriptionPaymentStatusX on SubscriptionPaymentStatus {
  String get value {
    switch (this) {
      case SubscriptionPaymentStatus.unpaid:
        return 'unpaid';
      case SubscriptionPaymentStatus.pending:
        return 'pending';
      case SubscriptionPaymentStatus.paid:
        return 'paid';
      case SubscriptionPaymentStatus.failed:
        return 'failed';
    }
  }

  String get label {
    switch (this) {
      case SubscriptionPaymentStatus.unpaid:
        return 'غير مدفوع';
      case SubscriptionPaymentStatus.pending:
        return 'قيد المراجعة';
      case SubscriptionPaymentStatus.paid:
        return 'مدفوع';
      case SubscriptionPaymentStatus.failed:
        return 'فشل الدفع';
    }
  }

  static SubscriptionPaymentStatus fromValue(String value) {
    switch (value) {
      case 'paid':
        return SubscriptionPaymentStatus.paid;
      case 'failed':
        return SubscriptionPaymentStatus.failed;
      case 'pending':
        return SubscriptionPaymentStatus.pending;
      case 'unpaid':
      default:
        return SubscriptionPaymentStatus.unpaid;
    }
  }
}

extension SubscriptionPlanTypeX on SubscriptionPlanType {
  String get value {
    switch (this) {
      case SubscriptionPlanType.basic:
        return 'basic';
      case SubscriptionPlanType.premium:
        return 'premium';
      case SubscriptionPlanType.elite:
        return 'elite';
    }
  }

  String get label {
    switch (this) {
      case SubscriptionPlanType.basic:
        return 'أساسية';
      case SubscriptionPlanType.premium:
        return 'احترافية';
      case SubscriptionPlanType.elite:
        return 'نخبة';
    }
  }

  static SubscriptionPlanType fromValue(String value) {
    switch (value) {
      case 'premium':
        return SubscriptionPlanType.premium;
      case 'elite':
        return SubscriptionPlanType.elite;
      case 'basic':
      default:
        return SubscriptionPlanType.basic;
    }
  }
}
