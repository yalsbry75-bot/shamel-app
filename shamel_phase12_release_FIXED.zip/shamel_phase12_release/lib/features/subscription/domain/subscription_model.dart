import 'subscription_status.dart';

class SubscriptionModel {
  const SubscriptionModel({
    required this.subscriptionId,
    required this.providerId,
    required this.planType,
    required this.startDate,
    required this.endDate,
    required this.status,
    required this.paymentStatus,
  });

  final String subscriptionId;
  final String providerId;
  final SubscriptionPlanType planType;
  final DateTime startDate;
  final DateTime endDate;
  final SubscriptionStatus status;
  final SubscriptionPaymentStatus paymentStatus;

  int get remainingDays {
    final days = endDate.difference(DateTime.now()).inDays;
    return days < 0 ? 0 : days;
  }

  factory SubscriptionModel.pending({required String subscriptionId, required String providerId}) {
    final now = DateTime.now();
    return SubscriptionModel(
      subscriptionId: subscriptionId,
      providerId: providerId,
      planType: SubscriptionPlanType.basic,
      startDate: now,
      endDate: now.add(const Duration(days: 30)),
      status: SubscriptionStatus.pending,
      paymentStatus: SubscriptionPaymentStatus.unpaid,
    );
  }

  factory SubscriptionModel.fromJson(Map<String, dynamic> json) {
    return SubscriptionModel(
      subscriptionId: json['subscriptionId'] as String? ?? '',
      providerId: json['providerId'] as String? ?? '',
      planType: SubscriptionPlanTypeX.fromValue(json['planType'] as String? ?? 'basic'),
      startDate: DateTime.parse(json['startDate'] as String),
      endDate: DateTime.parse(json['endDate'] as String),
      status: SubscriptionStatusX.fromValue(json['status'] as String? ?? 'pending'),
      paymentStatus: SubscriptionPaymentStatusX.fromValue(json['paymentStatus'] as String? ?? 'unpaid'),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'subscriptionId': subscriptionId,
      'providerId': providerId,
      'planType': planType.value,
      'startDate': startDate.toIso8601String(),
      'endDate': endDate.toIso8601String(),
      'status': status.value,
      'paymentStatus': paymentStatus.value,
    };
  }

  SubscriptionModel copyWith({
    String? subscriptionId,
    String? providerId,
    SubscriptionPlanType? planType,
    DateTime? startDate,
    DateTime? endDate,
    SubscriptionStatus? status,
    SubscriptionPaymentStatus? paymentStatus,
  }) {
    return SubscriptionModel(
      subscriptionId: subscriptionId ?? this.subscriptionId,
      providerId: providerId ?? this.providerId,
      planType: planType ?? this.planType,
      startDate: startDate ?? this.startDate,
      endDate: endDate ?? this.endDate,
      status: status ?? this.status,
      paymentStatus: paymentStatus ?? this.paymentStatus,
    );
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        other is SubscriptionModel &&
            runtimeType == other.runtimeType &&
            subscriptionId == other.subscriptionId &&
            providerId == other.providerId &&
            planType == other.planType &&
            startDate == other.startDate &&
            endDate == other.endDate &&
            status == other.status &&
            paymentStatus == other.paymentStatus;
  }

  @override
  int get hashCode => Object.hash(subscriptionId, providerId, planType, startDate, endDate, status, paymentStatus);
}
