import '../../../core/utils/ui_state.dart';
import 'subscription_model.dart';

class SubscriptionState {
  const SubscriptionState({
    this.viewState = ViewState.initial,
    this.subscription,
    this.message,
    this.errorMessage,
  });

  final ViewState viewState;
  final SubscriptionModel? subscription;
  final String? message;
  final String? errorMessage;

  SubscriptionState copyWith({
    ViewState? viewState,
    SubscriptionModel? subscription,
    bool clearSubscription = false,
    String? message,
    bool clearMessage = false,
    String? errorMessage,
    bool clearError = false,
  }) {
    return SubscriptionState(
      viewState: viewState ?? this.viewState,
      subscription: clearSubscription ? null : subscription ?? this.subscription,
      message: clearMessage ? null : message ?? this.message,
      errorMessage: clearError ? null : errorMessage ?? this.errorMessage,
    );
  }
}
