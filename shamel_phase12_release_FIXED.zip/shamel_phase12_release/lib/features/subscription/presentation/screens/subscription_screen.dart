import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/utils/ui_state.dart';
import '../../../../core/widgets/empty_state.dart';
import '../../../../core/widgets/error_state.dart';
import '../../../../core/widgets/glass_container.dart';
import '../../../../core/widgets/premium_app_bar.dart';
import '../../../../core/widgets/premium_scaffold.dart';
import '../../../../core/widgets/shamel_button.dart';
import '../../../provider/presentation/controllers/provider_controller.dart';
import '../../domain/subscription_model.dart';
import '../../domain/subscription_status.dart';
import '../controllers/subscription_controller.dart';

class SubscriptionScreen extends ConsumerStatefulWidget {
  const SubscriptionScreen({super.key});

  @override
  ConsumerState<SubscriptionScreen> createState() => _SubscriptionScreenState();
}

class _SubscriptionScreenState extends ConsumerState<SubscriptionScreen> {
  String? _loadedForProvider;

  void _load(String providerId) {
    if (_loadedForProvider == providerId) return;
    _loadedForProvider = providerId;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      ref.read(subscriptionControllerProvider.notifier).load(providerId);
    });
  }

  @override
  Widget build(BuildContext context) {
    final provider = ref.watch(providerControllerProvider).profile;
    final state = ref.watch(subscriptionControllerProvider);
    if (provider != null) _load(provider.providerId);

    ref.listen(subscriptionControllerProvider, (previous, next) {
      final message = next.errorMessage ?? next.message;
      if (message != null && message != previous?.message && message != previous?.errorMessage) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
      }
    });

    if (provider == null) {
      return const PremiumScaffold(
        appBar: PremiumAppBar(title: 'الاشتراك'),
        child: Center(
          child: EmptyState(
            title: 'الملف التجاري مطلوب',
            message: 'أنشئ ملف مقدم الخدمة أولًا ليتم إنشاء الاشتراك الشهري.',
            icon: Icons.workspace_premium_outlined,
          ),
        ),
      );
    }

    if (state.viewState == ViewState.loading && state.subscription == null) {
      return const PremiumScaffold(
        appBar: PremiumAppBar(title: 'الاشتراك', subtitle: 'تهيئة الاشتراك الشهري'),
        child: Center(child: CircularProgressIndicator()),
      );
    }

    if (state.viewState == ViewState.error && state.subscription == null) {
      return PremiumScaffold(
        appBar: const PremiumAppBar(title: 'الاشتراك'),
        child: ErrorState(message: state.errorMessage ?? 'تعذر تحميل الاشتراك.'),
      );
    }

    final subscription = state.subscription;
    if (subscription == null) {
      return const PremiumScaffold(
        appBar: PremiumAppBar(title: 'الاشتراك'),
        child: Center(
          child: EmptyState(
            title: 'لا يوجد اشتراك',
            message: 'سيتم إنشاء الاشتراك تلقائيًا بدون دفع فعلي.',
            icon: Icons.workspace_premium_outlined,
          ),
        ),
      );
    }

    return PremiumScaffold(
      appBar: const PremiumAppBar(title: 'الاشتراك الشهري', subtitle: 'بدون دفع إلكتروني في هذه المرحلة'),
      child: ListView(
        children: [
          _SubscriptionHero(subscription: subscription),
          const SizedBox(height: 14),
          GlassContainer(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('الخطة الحالية', style: AppTextStyles.section),
                const SizedBox(height: 14),
                _InfoRow(label: 'نوع الخطة', value: subscription.planType.label),
                _InfoRow(label: 'تاريخ البداية', value: _formatDate(subscription.startDate)),
                _InfoRow(label: 'تاريخ الانتهاء', value: _formatDate(subscription.endDate)),
                _InfoRow(label: 'حالة الاشتراك', value: subscription.status.label),
                _InfoRow(label: 'حالة الدفع', value: subscription.paymentStatus.label),
              ],
            ),
          ),
          const SizedBox(height: 14),
          GlassContainer(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('تغيير حالة الخطة', style: AppTextStyles.section),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: SubscriptionPlanType.values.map((plan) {
                    return ChoiceChip(
                      label: Text(plan.label),
                      selected: subscription.planType == plan,
                      onSelected: (_) => ref.read(subscriptionControllerProvider.notifier).changePlan(plan),
                    );
                  }).toList(),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          GlassContainer(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('حالات الاشتراك', style: AppTextStyles.section),
                const SizedBox(height: 8),
                Text('تعرض هذه الصفحة حالة الاشتراك الشهري وإجراءات الإدارة المتاحة عند الربط الإنتاجي.', style: AppTextStyles.caption),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: SubscriptionStatus.values.map((status) {
                    return ChoiceChip(
                      label: Text(status.label),
                      selected: subscription.status == status,
                      onSelected: (_) => ref.read(subscriptionControllerProvider.notifier).changeStatus(
                            status,
                            paymentStatus: status == SubscriptionStatus.active ? SubscriptionPaymentStatus.paid : null,
                          ),
                    );
                  }).toList(),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          ShamelButton.secondary(
            label: 'الدفع الإلكتروني غير مفعل',
            icon: Icons.lock_outline_rounded,
            onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('الدفع الإلكتروني مؤجل لمرحلة منفصلة.'))),
          ),
          const SizedBox(height: 28),
        ],
      ),
    );
  }

  String _formatDate(DateTime date) {
    return '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
  }
}

class _SubscriptionHero extends StatelessWidget {
  const _SubscriptionHero({required this.subscription});

  final SubscriptionModel subscription;

  @override
  Widget build(BuildContext context) {
    final color = switch (subscription.status) {
      SubscriptionStatus.active => AppColors.success,
      SubscriptionStatus.pending => AppColors.warning,
      SubscriptionStatus.expired => AppColors.textSecondary,
      SubscriptionStatus.suspended => AppColors.error,
    };
    return GlassContainer(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(color: AppColors.accentGold.withOpacity(0.14), borderRadius: BorderRadius.circular(20)),
                child: const Icon(Icons.workspace_premium_outlined, color: AppColors.accentGold, size: 30),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('اشتراك ${subscription.planType.label}', style: AppTextStyles.title),
                    const SizedBox(height: 4),
                    Text('متبقي ${subscription.remainingDays} يوم', style: AppTextStyles.caption),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(color: color.withOpacity(0.14), borderRadius: BorderRadius.circular(999)),
                child: Text(subscription.status.label, style: AppTextStyles.caption.copyWith(color: color, fontWeight: FontWeight.w800)),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  const _InfoRow({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          Expanded(child: Text(label, style: AppTextStyles.caption)),
          Text(value, style: AppTextStyles.body),
        ],
      ),
    );
  }
}
