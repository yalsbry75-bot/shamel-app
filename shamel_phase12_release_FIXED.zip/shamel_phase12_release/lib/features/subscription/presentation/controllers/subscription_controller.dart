import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/errors/app_exception.dart';
import '../../../../core/utils/ui_state.dart';
import '../../data/subscription_repository.dart';
import '../../domain/subscription_state.dart';
import '../../domain/subscription_status.dart';

final subscriptionControllerProvider = StateNotifierProvider<SubscriptionController, SubscriptionState>((ref) {
  return SubscriptionController(ref.watch(subscriptionRepositoryProvider));
});

class SubscriptionController extends StateNotifier<SubscriptionState> {
  SubscriptionController(this._repository) : super(const SubscriptionState());

  final SubscriptionRepository _repository;

  Future<void> load(String providerId) async {
    state = state.copyWith(viewState: ViewState.loading, clearError: true, clearMessage: true);
    try {
      final subscription = await _repository.ensureSubscription(providerId);
      state = state.copyWith(viewState: ViewState.success, subscription: subscription);
    } catch (error) {
      state = state.copyWith(viewState: ViewState.error, errorMessage: _safeMessage(error));
    }
  }

  Future<void> changeStatus(SubscriptionStatus status, {SubscriptionPaymentStatus? paymentStatus}) async {
    final current = state.subscription;
    if (current == null) return;
    state = state.copyWith(viewState: ViewState.loading, clearError: true, clearMessage: true);
    try {
      final updated = await _repository.updateStatus(current: current, status: status, paymentStatus: paymentStatus);
      state = state.copyWith(viewState: ViewState.success, subscription: updated, message: 'تم تحديث حالة الاشتراك إلى ${status.label}');
    } catch (error) {
      state = state.copyWith(viewState: ViewState.error, errorMessage: _safeMessage(error));
    }
  }

  Future<void> changePlan(SubscriptionPlanType planType) async {
    final current = state.subscription;
    if (current == null) return;
    state = state.copyWith(viewState: ViewState.loading, clearError: true, clearMessage: true);
    try {
      final updated = await _repository.changePlan(current: current, planType: planType);
      state = state.copyWith(viewState: ViewState.success, subscription: updated, message: 'تم اختيار خطة ${planType.label}');
    } catch (error) {
      state = state.copyWith(viewState: ViewState.error, errorMessage: _safeMessage(error));
    }
  }

  String _safeMessage(Object error) {
    if (error is AppException) return error.message;
    return 'تعذر إكمال العملية. حاول مرة أخرى.';
  }
}
