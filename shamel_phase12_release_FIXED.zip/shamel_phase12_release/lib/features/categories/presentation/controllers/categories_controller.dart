import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/utils/ui_state.dart';
import '../../data/categories_repository.dart';
import '../../domain/categories_state.dart';

final categoriesControllerProvider = StateNotifierProvider<CategoriesController, CategoriesState>((ref) {
  return CategoriesController(ref.watch(categoriesRepositoryProvider));
});

class CategoriesController extends StateNotifier<CategoriesState> {
  CategoriesController(this._repository) : super(const CategoriesState());

  final CategoriesRepository _repository;

  Future<void> loadCategories() async {
    if (state.categories.isNotEmpty) return;
    state = state.copyWith(viewState: ViewState.loading, clearError: true);
    try {
      final categories = await _repository.loadCategories();
      state = state.copyWith(viewState: ViewState.success, categories: categories);
    } catch (_) {
      state = state.copyWith(viewState: ViewState.error, errorMessage: 'تعذر تحميل التصنيفات.');
    }
  }

  void select(String categoryId) {
    state = state.copyWith(selectedCategoryId: categoryId, clearError: true);
  }

  void clearSelection() {
    state = state.copyWith(clearSelected: true, clearError: true);
  }
}
