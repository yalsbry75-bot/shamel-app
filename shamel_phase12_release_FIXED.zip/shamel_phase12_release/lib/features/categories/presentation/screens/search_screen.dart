import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/utils/ui_state.dart';
import '../../../../core/widgets/empty_state.dart';
import '../../../../core/widgets/error_state.dart';
import '../../../../core/widgets/loading_skeleton.dart';
import '../../../../core/widgets/premium_app_bar.dart';
import '../../../../core/widgets/premium_scaffold.dart';
import '../../../../core/widgets/shamel_text_field.dart';
import '../../../../routes/app_routes.dart';
import '../../../auth/presentation/controllers/auth_controller.dart';
import '../../../favorites/domain/favorite_item_type.dart';
import '../../../favorites/presentation/controllers/favorites_controller.dart';
import '../../../search/domain/search_result_type.dart';
import '../../../search/domain/search_sort_option.dart';
import '../../../search/presentation/controllers/search_controller.dart';
import '../../../search/presentation/widgets/search_filter_sheet.dart';
import '../../../search/presentation/widgets/search_result_card.dart';

class SearchScreen extends ConsumerStatefulWidget {
  const SearchScreen({super.key});

  @override
  ConsumerState<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends ConsumerState<SearchScreen> {
  late final TextEditingController _queryController;
  bool _didInit = false;

  @override
  void initState() {
    super.initState();
    _queryController = TextEditingController();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_didInit) return;
    _didInit = true;
    final args = ModalRoute.of(context)?.settings.arguments;
    var initialCategory = '';
    var initialQuery = '';
    if (args is Map) {
      initialCategory = args['categoryId']?.toString() ?? '';
      initialQuery = args['query']?.toString() ?? '';
    } else if (args is String) {
      initialQuery = args;
    }
    _queryController.text = initialQuery;
    Future.microtask(() async {
      final userId = ref.read(authControllerProvider).user?.userId ?? '';
      await ref.read(smartSearchControllerProvider.notifier).initialize(userId: userId, initialCategoryId: initialCategory);
      if (initialQuery.trim().isNotEmpty) {
        await ref.read(smartSearchControllerProvider.notifier).search(userId: userId, query: initialQuery, saveQuery: true);
      }
      await ref.read(favoritesControllerProvider.notifier).load(userId);
    });
  }

  @override
  void dispose() {
    _queryController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final userId = ref.watch(authControllerProvider).user?.userId ?? '';
    final searchState = ref.watch(smartSearchControllerProvider);
    final favorites = ref.watch(favoritesControllerProvider);
    return PremiumScaffold(
      appBar: PremiumAppBar(
        title: 'البحث الذكي',
        subtitle: searchState.filters.hasActiveFilters ? 'الفلاتر مفعلة' : 'ابحث في الخدمات والإعلانات',
        showBack: true,
        actions: [
          IconButton(onPressed: () => _openFilters(userId), icon: const Icon(Icons.tune_rounded)),
        ],
      ),
      child: NotificationListener<ScrollNotification>(
        onNotification: (notification) {
          if (notification.metrics.pixels > notification.metrics.maxScrollExtent - 220 && searchState.hasMore && !searchState.isLoading) {
            ref.read(smartSearchControllerProvider.notifier).loadMore(userId: userId);
          }
          return false;
        },
        child: ListView(
          children: [
            ShamelTextField(
              hintText: 'ابحث عن مقدم خدمة، إعلان، سيارة، عقار...',
              controller: _queryController,
              prefixIcon: Icons.search_rounded,
              suffixIcon: IconButton(
                onPressed: () {
                  _queryController.clear();
                  ref.read(smartSearchControllerProvider.notifier).liveSearch(userId: userId, query: '');
                },
                icon: const Icon(Icons.close_rounded),
              ),
              onChanged: (value) => ref.read(smartSearchControllerProvider.notifier).liveSearch(userId: userId, query: value),
              onSubmitted: (value) => ref.read(smartSearchControllerProvider.notifier).search(userId: userId, query: value, saveQuery: true),
            ),
            const SizedBox(height: 12),
            _QuickSort(userId: userId),
            if (searchState.didYouMean != null) ...[
              const SizedBox(height: 10),
              _DidYouMean(label: searchState.didYouMean!, onTap: () {
                _queryController.text = searchState.didYouMean!;
                ref.read(smartSearchControllerProvider.notifier).useSuggestion(userId: userId, suggestion: searchState.didYouMean!);
              }),
            ],
            const SizedBox(height: 12),
            if (searchState.query.trim().isEmpty && searchState.recentSearches.isNotEmpty) _RecentSearches(userId: userId, searches: searchState.recentSearches, onTap: (value) {
              _queryController.text = value;
              ref.read(smartSearchControllerProvider.notifier).useSuggestion(userId: userId, suggestion: value);
            }),
            if (searchState.suggestions.isNotEmpty) _Suggestions(userId: userId, suggestions: searchState.suggestions, onTap: (value) {
              _queryController.text = value;
              ref.read(smartSearchControllerProvider.notifier).useSuggestion(userId: userId, suggestion: value);
            }),
            const SizedBox(height: 16),
            if (searchState.viewState == ViewState.loading && searchState.results.isEmpty) const LoadingSkeleton(height: 160)
            else if (searchState.viewState == ViewState.error) ErrorState(message: searchState.errorMessage ?? 'تعذر البحث.', onRetry: () => ref.read(smartSearchControllerProvider.notifier).search(userId: userId, query: searchState.query, saveQuery: false))
            else if (searchState.results.isEmpty) const EmptyState(title: 'لا توجد نتائج', message: 'جرّب كلمة أخرى أو خفّف الفلاتر المطبقة.', icon: Icons.search_off_rounded)
            else ...[
              Text('${searchState.results.length} نتيجة ظاهرة', style: AppTextStyles.caption),
              const SizedBox(height: 10),
              ...searchState.results.map((result) {
                final itemType = result.type == SearchResultType.ad ? FavoriteItemType.ad : FavoriteItemType.provider;
                final itemId = result.type == SearchResultType.service && result.providerId.isNotEmpty ? result.providerId : result.itemId;
                final isFavorite = favorites.isFavorite(userId: userId, itemId: itemId, itemType: itemType);
                final favoriteResult = result.type == SearchResultType.service && result.providerId.isNotEmpty ? result.copyWith(itemId: result.providerId, type: SearchResultType.provider) : result;
                return Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: SearchResultCard(
                    result: result,
                    isFavorite: isFavorite,
                    onFavorite: () => ref.read(favoritesControllerProvider.notifier).toggleResult(userId: userId, result: favoriteResult),
                    onTap: () => _openResult(result),
                  ),
                );
              }),
              if (searchState.hasMore) const Padding(padding: EdgeInsets.only(top: 10, bottom: 30), child: LoadingSkeleton(height: 70)),
              const SizedBox(height: 90),
            ],
          ],
        ),
      ),
    );
  }

  void _openResult(result) {
    if (result.type == SearchResultType.ad) {
      Navigator.of(context).pushNamed(AppRoutes.adDetails, arguments: result.itemId);
    } else {
      Navigator.of(context).pushNamed(AppRoutes.serviceDetails);
    }
  }

  void _openFilters(String userId) {
    final filters = ref.read(smartSearchControllerProvider).filters;
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (_) => SearchFilterSheet(
        initialFilters: filters,
        onApply: (value) => ref.read(smartSearchControllerProvider.notifier).search(userId: userId, query: ref.read(smartSearchControllerProvider).query, filters: value, saveQuery: false),
        onClear: () => ref.read(smartSearchControllerProvider.notifier).clearFilters(userId),
      ),
    );
  }
}

class _QuickSort extends ConsumerWidget {
  const _QuickSort({required this.userId});

  final String userId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final sort = ref.watch(smartSearchControllerProvider).filters.sortOption;
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        SearchSortOption.topRated,
        SearchSortOption.newest,
        SearchSortOption.mostRequested,
      ].map((option) {
        return ChoiceChip(
          label: Text(option.label),
          selected: sort == option,
          onSelected: (_) => ref.read(smartSearchControllerProvider.notifier).applyFilters(userId: userId, sortOption: sort == option ? SearchSortOption.smart : option),
        );
      }).toList(),
    );
  }
}

class _DidYouMean extends StatelessWidget {
  const _DidYouMean({required this.label, required this.onTap});
  final String label;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: AppColors.primary.withOpacity(0.12), borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.primary.withOpacity(0.28))),
        child: Text('هل تقصد: $label؟', style: AppTextStyles.body.copyWith(color: AppColors.primary, fontWeight: FontWeight.w800)),
      ),
    );
  }
}

class _Suggestions extends StatelessWidget {
  const _Suggestions({required this.userId, required this.suggestions, required this.onTap});
  final String userId;
  final List<String> suggestions;
  final ValueChanged<String> onTap;
  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: suggestions.take(10).map((item) => ActionChip(label: Text(item), avatar: const Icon(Icons.auto_awesome_outlined, size: 16), onPressed: () => onTap(item))).toList(),
    );
  }
}

class _RecentSearches extends ConsumerWidget {
  const _RecentSearches({required this.userId, required this.searches, required this.onTap});
  final String userId;
  final List<String> searches;
  final ValueChanged<String> onTap;
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text('آخر عمليات البحث', style: AppTextStyles.section),
            const Spacer(),
            TextButton(onPressed: () => ref.read(smartSearchControllerProvider.notifier).clearRecent(userId), child: const Text('مسح')),
          ],
        ),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: searches.map((item) => ActionChip(label: Text(item), avatar: const Icon(Icons.history_rounded, size: 16), onPressed: () => onTap(item))).toList(),
        ),
        const SizedBox(height: 12),
      ],
    );
  }
}
