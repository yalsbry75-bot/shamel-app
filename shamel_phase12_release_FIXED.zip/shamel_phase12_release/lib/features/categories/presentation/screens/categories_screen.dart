import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/utils/ui_state.dart';
import '../../../../core/widgets/error_state.dart';
import '../../../../core/widgets/glass_container.dart';
import '../../../../core/widgets/loading_skeleton.dart';
import '../../../../core/widgets/premium_app_bar.dart';
import '../../../../core/widgets/premium_scaffold.dart';
import '../../../../routes/app_routes.dart';
import '../controllers/categories_controller.dart';

class CategoriesScreen extends ConsumerStatefulWidget {
  const CategoriesScreen({super.key, this.isEmbedded = false});

  final bool isEmbedded;

  @override
  ConsumerState<CategoriesScreen> createState() => _CategoriesScreenState();
}

class _CategoriesScreenState extends ConsumerState<CategoriesScreen> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() => ref.read(categoriesControllerProvider.notifier).loadCategories());
  }


  IconData _categoryIcon(String categoryId) {
    switch (categoryId) {
      case 'water':
        return Icons.water_drop_outlined;
      case 'taxi':
        return Icons.local_taxi_outlined;
      case 'tire':
        return Icons.tire_repair_outlined;
      case 'mechanic':
        return Icons.car_repair_outlined;
      case 'restaurants':
        return Icons.restaurant_outlined;
      case 'groceries':
        return Icons.local_grocery_store_outlined;
      case 'pharmacy':
        return Icons.local_pharmacy_outlined;
      case 'real_estate':
        return Icons.home_work_outlined;
      case 'cars':
        return Icons.directions_car_filled_outlined;
      case 'craftsmen':
        return Icons.handyman_outlined;
      default:
        return Icons.more_horiz_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(categoriesControllerProvider);
    return PremiumScaffold(
      appBar: widget.isEmbedded ? const PremiumAppBar(title: 'التصنيفات') : const PremiumAppBar(title: 'التصنيفات', showBack: true),
      child: state.viewState == ViewState.loading
          ? const LoadingSkeleton(height: 180)
          : state.viewState == ViewState.error
              ? ErrorState(message: state.errorMessage ?? 'تعذر تحميل التصنيفات.', onRetry: () => ref.read(categoriesControllerProvider.notifier).loadCategories())
              : GridView.builder(
                  itemCount: state.categories.length,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                    childAspectRatio: 0.95,
                  ),
                  itemBuilder: (context, index) {
                    final category = state.categories[index];
                    return GlassContainer(
                      onTap: () {
                        ref.read(categoriesControllerProvider.notifier).select(category.categoryId);
                        Navigator.of(context).pushNamed(AppRoutes.search, arguments: {'categoryId': category.categoryId, 'query': category.name});
                      },
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 58,
                            height: 58,
                            decoration: BoxDecoration(
                              color: AppColors.primary.withOpacity(0.14),
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(color: AppColors.primary.withOpacity(0.18)),
                            ),
                            child: Icon(_categoryIcon(category.categoryId), color: AppColors.primary),
                          ),
                          const SizedBox(height: 14),
                          Text(category.name, textAlign: TextAlign.center, style: AppTextStyles.section),
                          const SizedBox(height: 7),
                          Text(category.description, textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis, style: AppTextStyles.caption.copyWith(height: 1.45)),
                        ],
                      ),
                    );
                  },
                ),
    );
  }
}
