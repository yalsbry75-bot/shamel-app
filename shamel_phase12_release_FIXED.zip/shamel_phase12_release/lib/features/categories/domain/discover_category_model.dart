class DiscoverCategoryModel {
  const DiscoverCategoryModel({
    required this.categoryId,
    required this.name,
    required this.description,
    required this.iconCodePoint,
    this.sortOrder = 0,
  });

  final String categoryId;
  final String name;
  final String description;
  final int iconCodePoint;
  final int sortOrder;

  factory DiscoverCategoryModel.fromJson(Map<String, dynamic> json) {
    return DiscoverCategoryModel(
      categoryId: json['categoryId'] as String? ?? '',
      name: json['name'] as String? ?? '',
      description: json['description'] as String? ?? '',
      iconCodePoint: json['iconCodePoint'] as int? ?? 0xe574,
      sortOrder: json['sortOrder'] as int? ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'categoryId': categoryId,
      'name': name,
      'description': description,
      'iconCodePoint': iconCodePoint,
      'sortOrder': sortOrder,
    };
  }

  DiscoverCategoryModel copyWith({
    String? categoryId,
    String? name,
    String? description,
    int? iconCodePoint,
    int? sortOrder,
  }) {
    return DiscoverCategoryModel(
      categoryId: categoryId ?? this.categoryId,
      name: name ?? this.name,
      description: description ?? this.description,
      iconCodePoint: iconCodePoint ?? this.iconCodePoint,
      sortOrder: sortOrder ?? this.sortOrder,
    );
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        other is DiscoverCategoryModel &&
            runtimeType == other.runtimeType &&
            categoryId == other.categoryId &&
            name == other.name &&
            description == other.description &&
            iconCodePoint == other.iconCodePoint &&
            sortOrder == other.sortOrder;
  }

  @override
  int get hashCode => Object.hash(categoryId, name, description, iconCodePoint, sortOrder);
}
