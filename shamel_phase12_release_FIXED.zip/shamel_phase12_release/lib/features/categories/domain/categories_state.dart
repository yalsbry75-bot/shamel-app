import '../../../core/utils/ui_state.dart';
import 'discover_category_model.dart';

class CategoriesState {
  const CategoriesState({
    this.viewState = ViewState.initial,
    this.categories = const [],
    this.selectedCategoryId,
    this.errorMessage,
  });

  final ViewState viewState;
  final List<DiscoverCategoryModel> categories;
  final String? selectedCategoryId;
  final String? errorMessage;

  DiscoverCategoryModel? get selectedCategory {
    final selected = selectedCategoryId;
    if (selected == null || selected.isEmpty) return null;
    for (final category in categories) {
      if (category.categoryId == selected) return category;
    }
    return null;
  }

  CategoriesState copyWith({
    ViewState? viewState,
    List<DiscoverCategoryModel>? categories,
    String? selectedCategoryId,
    bool clearSelected = false,
    String? errorMessage,
    bool clearError = false,
  }) {
    return CategoriesState(
      viewState: viewState ?? this.viewState,
      categories: categories ?? this.categories,
      selectedCategoryId: clearSelected ? null : selectedCategoryId ?? this.selectedCategoryId,
      errorMessage: clearError ? null : errorMessage ?? this.errorMessage,
    );
  }
}
