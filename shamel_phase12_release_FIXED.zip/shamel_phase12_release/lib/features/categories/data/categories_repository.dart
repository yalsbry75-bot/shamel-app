import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../domain/discover_category_model.dart';
import 'categories_service.dart';

final categoriesServiceProvider = Provider<CategoriesService>((ref) => FirebaseCategoriesService());

final categoriesRepositoryProvider = Provider<CategoriesRepository>((ref) {
  return CategoriesRepository(ref.watch(categoriesServiceProvider));
});

class CategoriesRepository {
  const CategoriesRepository(this._service);

  final CategoriesService _service;

  Future<List<DiscoverCategoryModel>> loadCategories() {
    return _service.loadCategories();
  }
}
