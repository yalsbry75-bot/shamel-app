import 'package:cloud_firestore/cloud_firestore.dart';

import '../../../core/database/firestore_collections.dart';
import '../../../core/database/firestore_json.dart';
import '../domain/discover_category_model.dart';

abstract class CategoriesService {
  Future<List<DiscoverCategoryModel>> loadCategories();
}

class FirebaseCategoriesService implements CategoriesService {
  FirebaseCategoriesService({FirebaseFirestore? firestore}) : _firestore = firestore ?? FirebaseFirestore.instance;

  final FirebaseFirestore _firestore;

  @override
  Future<List<DiscoverCategoryModel>> loadCategories() async {
    final snapshot = await _firestore.collection(FirestoreCollections.categories).orderBy('sortOrder').limit(80).get();
    if (snapshot.docs.isEmpty) return DefaultCategories.catalog;
    return snapshot.docs
        .map((doc) => DiscoverCategoryModel.fromJson(FirestoreJson.normalize(doc.data())))
        .toList(growable: false);
  }
}

class DefaultCategories {
  const DefaultCategories._();

  static const catalog = <DiscoverCategoryModel>[
    DiscoverCategoryModel(categoryId: 'water', name: 'المياه', description: 'وايتات ومياه للمنازل والمنشآت', iconCodePoint: 0xe574, sortOrder: 1),
    DiscoverCategoryModel(categoryId: 'taxi', name: 'التكاسي', description: 'مشاوير وتنقل داخل المدينة', iconCodePoint: 0xe574, sortOrder: 2),
    DiscoverCategoryModel(categoryId: 'tire', name: 'البنشري', description: 'إطارات وبطاريات وخدمات طريق', iconCodePoint: 0xe574, sortOrder: 3),
    DiscoverCategoryModel(categoryId: 'mechanic', name: 'الميكانيكي', description: 'فحص وصيانة سيارات', iconCodePoint: 0xe574, sortOrder: 4),
    DiscoverCategoryModel(categoryId: 'restaurants', name: 'المطاعم', description: 'مطاعم وعروض وجبات', iconCodePoint: 0xe574, sortOrder: 5),
    DiscoverCategoryModel(categoryId: 'groceries', name: 'البقالات', description: 'مواد غذائية وطلبات يومية', iconCodePoint: 0xe574, sortOrder: 6),
    DiscoverCategoryModel(categoryId: 'pharmacy', name: 'الصيدليات', description: 'صيدليات ومستلزمات صحية', iconCodePoint: 0xe574, sortOrder: 7),
    DiscoverCategoryModel(categoryId: 'real_estate', name: 'العقارات', description: 'إيجار وبيع وشقق وأراضي', iconCodePoint: 0xe574, sortOrder: 8),
    DiscoverCategoryModel(categoryId: 'cars', name: 'السيارات', description: 'بيع وشراء وخدمات سيارات', iconCodePoint: 0xe574, sortOrder: 9),
    DiscoverCategoryModel(categoryId: 'craftsmen', name: 'الحرفيين', description: 'كهرباء وسباكة ونجارة وأعمال منزلية', iconCodePoint: 0xe574, sortOrder: 10),
    DiscoverCategoryModel(categoryId: 'other_services', name: 'خدمات أخرى', description: 'خدمات متنوعة حسب احتياجك', iconCodePoint: 0xe574, sortOrder: 11),
  ];
}
