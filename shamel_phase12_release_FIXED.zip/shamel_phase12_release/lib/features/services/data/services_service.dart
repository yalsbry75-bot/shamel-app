import '../../../core/errors/app_exception.dart';

class ServicesService {
  const ServicesService();

  Future<void> load() {
    throw const AppException('Services service is prepared but disabled until its dedicated phase.');
  }
}
