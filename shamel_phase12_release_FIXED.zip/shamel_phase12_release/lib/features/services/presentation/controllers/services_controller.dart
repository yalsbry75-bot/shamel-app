import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../domain/services_state.dart';

final servicesControllerProvider = StateNotifierProvider<ServicesController, ServicesState>((ref) {
  return ServicesController();
});

class ServicesController extends StateNotifier<ServicesState> {
  ServicesController() : super(const ServicesState());
}
