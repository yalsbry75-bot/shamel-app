import 'package:flutter/material.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/widgets/glass_container.dart';
import '../../../../core/widgets/premium_app_bar.dart';
import '../../../../core/widgets/premium_scaffold.dart';
import '../../../../core/widgets/shamel_button.dart';
import '../../../../routes/app_routes.dart';
import '../../../../shared/components/provider_card.dart';

class ServiceDetailsScreen extends StatelessWidget {
  const ServiceDetailsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return PremiumScaffold(
      appBar: const PremiumAppBar(title: 'تفاصيل الخدمة', showBack: true),
      child: ListView(
        children: [
          GlassContainer(
            padding: const EdgeInsets.all(28),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 68,
                  height: 68,
                  decoration: BoxDecoration(
                    color: AppColors.primary.withOpacity(0.16),
                    borderRadius: BorderRadius.circular(24),
                  ),
                  child: const Icon(Icons.design_services_outlined, color: AppColors.primary, size: 32),
                ),
                const SizedBox(height: 20),
                Text('اسم الخدمة', style: AppTextStyles.display),
                const SizedBox(height: 10),
                Text('وصف تفصيلي للخدمة. يمكنك إنشاء طلب مرتبط بمقدم الخدمة عند توفر البيانات.', style: AppTextStyles.caption),
              ],
            ),
          ),
          const SizedBox(height: 16),
          const ProviderCard(name: 'مقدم الخدمة', specialty: 'تصميم فقط', rating: 5),
          const SizedBox(height: 20),
          ShamelButton.primary(
            label: 'إنشاء طلب',
            icon: Icons.add_circle_outline_rounded,
            onPressed: () => Navigator.of(context).pushNamed(AppRoutes.createOrder),
          ),
        ],
      ),
    );
  }
}
