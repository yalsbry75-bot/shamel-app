import '../../../core/utils/ui_state.dart';

class ServicesState {
  const ServicesState({this.viewState = ViewState.success, this.message});

  final ViewState viewState;
  final String? message;

  ServicesState copyWith({ViewState? viewState, String? message}) {
    return ServicesState(
      viewState: viewState ?? this.viewState,
      message: message ?? this.message,
    );
  }
}
