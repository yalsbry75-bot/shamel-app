import 'package:flutter/material.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/widgets/glass_container.dart';
import '../../domain/ad_category.dart';
import '../../domain/ad_model.dart';
import 'ad_image.dart';
import 'ad_status_chip.dart';

class PremiumAdCard extends StatelessWidget {
  const PremiumAdCard({
    super.key,
    required this.ad,
    required this.onDetails,
    required this.onFavorite,
    required this.isFavorite,
  });

  final AdModel ad;
  final VoidCallback onDetails;
  final VoidCallback onFavorite;
  final bool isFavorite;

  @override
  Widget build(BuildContext context) {
    final category = AdCategory.byId(ad.categoryId);
    return GlassContainer(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            children: [
              AdImage(url: ad.mainImage),
              PositionedDirectional(
                top: 10,
                start: 10,
                child: AdStatusChip(status: ad.status),
              ),
              PositionedDirectional(
                top: 8,
                end: 8,
                child: IconButton.filledTonal(
                  onPressed: onFavorite,
                  icon: Icon(isFavorite ? Icons.favorite_rounded : Icons.favorite_border_rounded),
                ),
              ),
              if (ad.effectiveDiscountPercent > 0)
                PositionedDirectional(
                  bottom: 10,
                  start: 10,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: AppColors.accentGold.withOpacity(0.96),
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Text('خصم ${ad.effectiveDiscountPercent}%', style: const TextStyle(color: Colors.black, fontWeight: FontWeight.w900)),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Icon(IconData(category.iconCodePoint, fontFamily: 'MaterialIcons'), color: AppColors.accentGold, size: 18),
              const SizedBox(width: 6),
              Text(category.name, style: AppTextStyles.caption.copyWith(color: AppColors.accentGold)),
              const Spacer(),
              const Icon(Icons.place_outlined, size: 16, color: AppColors.textSecondary),
              const SizedBox(width: 4),
              Flexible(child: Text(ad.locationText, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTextStyles.caption)),
            ],
          ),
          const SizedBox(height: 8),
          Text(ad.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTextStyles.body.copyWith(fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          Text(ad.description, maxLines: 2, overflow: TextOverflow.ellipsis, style: AppTextStyles.caption),
          const SizedBox(height: 12),
          Row(
            children: [
              Text(_price(ad.priceAfter), style: AppTextStyles.body.copyWith(color: AppColors.textPrimary, fontWeight: FontWeight.w900)),
              if (ad.priceBefore > 0 && ad.priceBefore > ad.priceAfter) ...[
                const SizedBox(width: 8),
                Text(
                  _price(ad.priceBefore),
                  style: AppTextStyles.caption.copyWith(decoration: TextDecoration.lineThrough, color: AppColors.textSecondary),
                ),
              ],
              const Spacer(),
              TextButton.icon(
                onPressed: onDetails,
                icon: const Icon(Icons.arrow_back_rounded, size: 18),
                label: const Text('التفاصيل'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  String _price(double value) {
    if (value <= 0) return 'السعر عند التواصل';
    final clean = value % 1 == 0 ? value.toStringAsFixed(0) : value.toStringAsFixed(2);
    return '$clean ر.ي';
  }
}
