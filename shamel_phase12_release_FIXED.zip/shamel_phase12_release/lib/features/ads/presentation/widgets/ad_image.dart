import 'package:flutter/material.dart';

import '../../../../core/theme/app_colors.dart';

class AdImage extends StatelessWidget {
  const AdImage({super.key, required this.url, this.height = 156, this.width = double.infinity, this.borderRadius = 24});

  final String url;
  final double height;
  final double width;
  final double borderRadius;

  @override
  Widget build(BuildContext context) {
    final fallback = _ImageFallback(height: height, width: width, borderRadius: borderRadius);
    if (url.trim().isEmpty) return fallback;
    return ClipRRect(
      borderRadius: BorderRadius.circular(borderRadius),
      child: Image.network(
        url,
        height: height,
        width: width,
        fit: BoxFit.cover,
        loadingBuilder: (context, child, progress) {
          if (progress == null) return child;
          return fallback;
        },
        errorBuilder: (context, error, stackTrace) => fallback,
      ),
    );
  }
}

class _ImageFallback extends StatelessWidget {
  const _ImageFallback({required this.height, required this.width, required this.borderRadius});

  final double height;
  final double width;
  final double borderRadius;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      width: width,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(borderRadius),
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [AppColors.primary.withOpacity(0.28), AppColors.surfaceHigh.withOpacity(0.96)],
        ),
        border: Border.all(color: AppColors.border),
      ),
      child: const Center(child: Icon(Icons.image_outlined, color: AppColors.textSecondary, size: 34)),
    );
  }
}
