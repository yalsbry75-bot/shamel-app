import 'package:flutter/material.dart';

import '../../../../core/theme/app_colors.dart';
import '../../domain/ad_status.dart';

class AdStatusChip extends StatelessWidget {
  const AdStatusChip({super.key, required this.status});

  final AdStatus status;

  @override
  Widget build(BuildContext context) {
    final color = switch (status) {
      AdStatus.active => AppColors.success,
      AdStatus.pending => AppColors.warning,
      AdStatus.rejected => AppColors.error,
      AdStatus.expired => AppColors.textSecondary,
    };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.16),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: color.withOpacity(0.35)),
      ),
      child: Text(status.label, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w800)),
    );
  }
}
