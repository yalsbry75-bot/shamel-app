import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/widgets/glass_container.dart';
import '../../../../routes/app_routes.dart';
import '../../domain/ad_model.dart';
import '../controllers/ads_controller.dart';
import 'ad_image.dart';

class TopBannerSlider extends ConsumerStatefulWidget {
  const TopBannerSlider({super.key});

  @override
  ConsumerState<TopBannerSlider> createState() => _TopBannerSliderState();
}

class _TopBannerSliderState extends ConsumerState<TopBannerSlider> {
  late final PageController _controller;
  Timer? _timer;
  int _index = 0;

  @override
  void initState() {
    super.initState();
    _controller = PageController(viewportFraction: 0.94);
    Future.microtask(() => ref.read(adsControllerProvider.notifier).loadAds());
    _timer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (!mounted || !_controller.hasClients) return;
      final banners = ref.read(adsControllerProvider).bannerAds;
      if (banners.length < 2) return;
      _index = (_index + 1) % banners.length;
      _controller.animateToPage(_index, duration: const Duration(milliseconds: 520), curve: Curves.easeOutCubic);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final banners = ref.watch(adsControllerProvider).bannerAds;
    if (banners.isEmpty) {
      return const GlassContainer(
        child: Row(
          children: [
            Icon(Icons.campaign_outlined, color: AppColors.accentGold),
            SizedBox(width: 12),
            Expanded(child: Text('الشريط الإعلاني جاهز وسيظهر هنا بعد إضافة إعلانات نشطة.')),
          ],
        ),
      );
    }
    return SizedBox(
      height: 210,
      child: PageView.builder(
        controller: _controller,
        itemCount: banners.length,
        onPageChanged: (value) => _index = value,
        itemBuilder: (context, index) => Padding(
          padding: const EdgeInsetsDirectional.only(end: 10),
          child: _BannerTile(ad: banners[index]),
        ),
      ),
    );
  }
}

class _BannerTile extends StatelessWidget {
  const _BannerTile({required this.ad});

  final AdModel ad;

  @override
  Widget build(BuildContext context) {
    return GlassContainer(
      padding: EdgeInsets.zero,
      child: Stack(
        fit: StackFit.expand,
        children: [
          AdImage(url: ad.mainImage, height: 210, borderRadius: 24),
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              gradient: const LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Colors.transparent, Color(0xE6000000)],
              ),
            ),
          ),
          PositionedDirectional(
            start: 16,
            end: 16,
            bottom: 16,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (ad.effectiveDiscountPercent > 0)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(color: AppColors.accentGold, borderRadius: BorderRadius.circular(999)),
                    child: Text('خصم ${ad.effectiveDiscountPercent}%', style: const TextStyle(color: Colors.black, fontWeight: FontWeight.w900)),
                  ),
                const SizedBox(height: 8),
                Text(ad.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTextStyles.title),
                const SizedBox(height: 4),
                Text(ad.description, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTextStyles.caption.copyWith(color: AppColors.textPrimary)),
                Align(
                  alignment: AlignmentDirectional.centerEnd,
                  child: TextButton(
                    onPressed: () => Navigator.of(context).pushNamed(AppRoutes.adDetails, arguments: ad.adId),
                    child: const Text('عرض التفاصيل'),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
