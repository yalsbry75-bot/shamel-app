import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/errors/app_exception.dart';
import '../../../../core/utils/ui_state.dart';
import '../../data/ads_repository.dart';
import '../../domain/ad_model.dart';
import '../../domain/ads_state.dart';

final adsControllerProvider = StateNotifierProvider<AdsController, AdsState>((ref) {
  return AdsController(ref.watch(adsRepositoryProvider));
});

class AdsController extends StateNotifier<AdsState> {
  AdsController(this._repository) : super(const AdsState());

  final AdsRepository _repository;

  Future<void> loadAds() async {
    state = state.copyWith(viewState: ViewState.loading, clearError: true, clearMessage: true);
    try {
      final ads = await _repository.loadAll();
      state = state.copyWith(viewState: ads.isEmpty ? ViewState.empty : ViewState.success, ads: ads);
    } catch (error) {
      state = state.copyWith(viewState: ViewState.error, errorMessage: _safeMessage(error));
    }
  }

  Future<AdModel?> findAd(String adId) async {
    final local = state.byId(adId);
    if (local != null) return local;
    return _repository.findById(adId);
  }

  void selectCategory(String categoryId) {
    state = state.copyWith(selectedCategoryId: categoryId, clearError: true, clearMessage: true);
  }

  void clearCategory() {
    state = state.copyWith(clearSelectedCategory: true, clearError: true, clearMessage: true);
  }

  Future<bool> createAd({
    required String userId,
    required String providerId,
    required String ownerName,
    required String title,
    required String description,
    required String categoryId,
    required List<String> images,
    required double priceBefore,
    required double priceAfter,
    required String locationText,
    required String phoneNumber,
    required int durationDays,
  }) async {
    state = state.copyWith(viewState: ViewState.loading, clearError: true, clearMessage: true);
    try {
      await _repository.createAd(
        userId: userId,
        providerId: providerId,
        ownerName: ownerName,
        title: title,
        description: description,
        categoryId: categoryId,
        images: images,
        priceBefore: priceBefore,
        priceAfter: priceAfter,
        locationText: locationText,
        phoneNumber: phoneNumber,
        durationDays: durationDays,
      );
      final ads = await _repository.loadAll();
      state = state.copyWith(viewState: ViewState.success, ads: ads, message: 'تم إنشاء الإعلان بحالة بانتظار المراجعة');
      return true;
    } catch (error) {
      state = state.copyWith(viewState: ViewState.error, errorMessage: _safeMessage(error));
      return false;
    }
  }

  Future<void> toggleFavorite({required String adId, required String userId}) async {
    try {
      final updated = await _repository.toggleFavorite(adId: adId, userId: userId);
      final ads = state.ads.map((item) => item.adId == updated.adId ? updated : item).toList(growable: false);
      state = state.copyWith(ads: ads, message: updated.isFavoriteFor(userId) ? 'تم حفظ الإعلان' : 'تمت إزالة الإعلان من المفضلة');
    } catch (error) {
      state = state.copyWith(errorMessage: _safeMessage(error));
    }
  }

  void clearMessages() {
    state = state.copyWith(clearError: true, clearMessage: true);
  }

  String _safeMessage(Object error) {
    if (error is AppException) return error.message;
    return 'تعذر إكمال العملية. حاول مرة أخرى.';
  }
}
