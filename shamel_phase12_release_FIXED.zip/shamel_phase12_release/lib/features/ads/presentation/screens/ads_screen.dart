import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/utils/ui_state.dart';
import '../../../../core/widgets/empty_state.dart';
import '../../../../core/widgets/error_state.dart';
import '../../../../core/widgets/glass_container.dart';
import '../../../../core/widgets/loading_skeleton.dart';
import '../../../../core/widgets/premium_app_bar.dart';
import '../../../../core/widgets/premium_scaffold.dart';
import '../../../../routes/app_routes.dart';
import '../../../auth/presentation/controllers/auth_controller.dart';
import '../../domain/ad_category.dart';
import '../controllers/ads_controller.dart';
import '../widgets/premium_ad_card.dart';

class AdsScreen extends ConsumerStatefulWidget {
  const AdsScreen({super.key});

  @override
  ConsumerState<AdsScreen> createState() => _AdsScreenState();
}

class _AdsScreenState extends ConsumerState<AdsScreen> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() => ref.read(adsControllerProvider.notifier).loadAds());
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(adsControllerProvider);
    final user = ref.watch(authControllerProvider).user;
    final userId = user?.userId ?? '';
    final ads = state.filteredAds;
    return PremiumScaffold(
      appBar: PremiumAppBar(
        title: 'Marketplace',
        subtitle: 'إعلانات، عروض، ومنتجات داخل شامل',
        showBack: true,
        actions: [
          IconButton(
            onPressed: () => Navigator.of(context).pushNamed(AppRoutes.createAd),
            icon: const Icon(Icons.add_circle_outline_rounded),
          ),
        ],
      ),
      child: RefreshIndicator(
        onRefresh: () => ref.read(adsControllerProvider.notifier).loadAds(),
        child: ListView(
          children: [
            _Header(onCreate: () => Navigator.of(context).pushNamed(AppRoutes.createAd)),
            const SizedBox(height: 18),
            _Categories(selected: state.selectedCategoryId),
            const SizedBox(height: 16),
            if (state.viewState == ViewState.loading) ...const [
              LoadingSkeleton(height: 170),
              SizedBox(height: 12),
              LoadingSkeleton(height: 170),
            ] else if (state.viewState == ViewState.error)
              ErrorState(message: state.errorMessage ?? 'تعذر تحميل الإعلانات.', onRetry: () => ref.read(adsControllerProvider.notifier).loadAds())
            else if (ads.isEmpty)
              const EmptyState(title: 'لا توجد إعلانات', message: 'غيّر التصنيف أو أضف إعلانًا جديدًا.', icon: Icons.campaign_outlined)
            else
              ...ads.map(
                (ad) => PremiumAdCard(
                  ad: ad,
                  isFavorite: ad.isFavoriteFor(userId),
                  onFavorite: () => ref.read(adsControllerProvider.notifier).toggleFavorite(adId: ad.adId, userId: userId),
                  onDetails: () => Navigator.of(context).pushNamed(AppRoutes.adDetails, arguments: ad.adId),
                ),
              ),
            const SizedBox(height: 90),
          ],
        ),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header({required this.onCreate});

  final VoidCallback onCreate;

  @override
  Widget build(BuildContext context) {
    return GlassContainer(
      child: Row(
        children: [
          Container(
            width: 54,
            height: 54,
            decoration: BoxDecoration(color: AppColors.primary.withOpacity(0.18), borderRadius: BorderRadius.circular(18)),
            child: const Icon(Icons.storefront_rounded, color: AppColors.primary),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('سوق شامل', style: AppTextStyles.body.copyWith(fontWeight: FontWeight.w900)),
                const SizedBox(height: 4),
                Text('عروض اليوم، منتجات، سيارات، عقارات، مطاعم وخدمات.', style: AppTextStyles.caption),
              ],
            ),
          ),
          IconButton.filledTonal(onPressed: onCreate, icon: const Icon(Icons.add_rounded)),
        ],
      ),
    );
  }
}

class _Categories extends ConsumerWidget {
  const _Categories({required this.selected});

  final String? selected;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          Padding(
            padding: const EdgeInsetsDirectional.only(end: 8),
            child: ChoiceChip(
              selected: selected == null,
              label: const Text('الكل'),
              onSelected: (_) => ref.read(adsControllerProvider.notifier).clearCategory(),
            ),
          ),
          ...AdCategory.values.map(
            (category) => Padding(
              padding: const EdgeInsetsDirectional.only(end: 8),
              child: ChoiceChip(
                selected: selected == category.categoryId,
                avatar: Icon(IconData(category.iconCodePoint, fontFamily: 'MaterialIcons'), size: 16),
                label: Text(category.name),
                onSelected: (_) => ref.read(adsControllerProvider.notifier).selectCategory(category.categoryId),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
