import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/widgets/empty_state.dart';
import '../../../../core/widgets/glass_container.dart';
import '../../../../core/widgets/premium_app_bar.dart';
import '../../../../core/widgets/premium_scaffold.dart';
import '../../../../core/widgets/shamel_button.dart';
import '../../../auth/presentation/controllers/auth_controller.dart';
import '../../../favorites/domain/favorite_item_type.dart';
import '../../../favorites/presentation/controllers/favorites_controller.dart';
import '../../domain/ad_category.dart';
import '../../domain/ad_model.dart';
import '../controllers/ads_controller.dart';
import '../widgets/ad_image.dart';
import '../widgets/ad_status_chip.dart';

class AdDetailsScreen extends ConsumerStatefulWidget {
  const AdDetailsScreen({super.key, required this.adId});

  final String adId;

  @override
  ConsumerState<AdDetailsScreen> createState() => _AdDetailsScreenState();
}

class _AdDetailsScreenState extends ConsumerState<AdDetailsScreen> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() async {
      await ref.read(adsControllerProvider.notifier).loadAds();
      final userId = ref.read(authControllerProvider).user?.userId ?? '';
      await ref.read(favoritesControllerProvider.notifier).load(userId);
    });
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(adsControllerProvider);
    final userId = ref.watch(authControllerProvider).user?.userId ?? '';
    final ad = state.byId(widget.adId);
    final favoritesState = ref.watch(favoritesControllerProvider);
    if (ad == null) {
      return const PremiumScaffold(
        appBar: PremiumAppBar(title: 'تفاصيل الإعلان', showBack: true),
        child: Center(child: EmptyState(title: 'الإعلان غير متاح', message: 'قد يكون الإعلان محذوفًا أو لم يتم تحميله بعد.', icon: Icons.campaign_outlined)),
      );
    }
    final category = AdCategory.byId(ad.categoryId);
    return PremiumScaffold(
      appBar: const PremiumAppBar(title: 'تفاصيل الإعلان', showBack: true),
      child: ListView(
        children: [
          _Images(ad: ad),
          const SizedBox(height: 14),
          GlassContainer(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    AdStatusChip(status: ad.status),
                    const Spacer(),
                    IconButton.filledTonal(
                      onPressed: () async {
                        await ref.read(adsControllerProvider.notifier).toggleFavorite(adId: ad.adId, userId: userId);
                        await ref.read(favoritesControllerProvider.notifier).toggleSnapshot(
                              userId: userId,
                              itemId: ad.adId,
                              itemType: FavoriteItemType.ad,
                              title: ad.title,
                              subtitle: ad.ownerName.isEmpty ? 'إعلان' : ad.ownerName,
                              locationText: ad.locationText,
                              imageUrl: ad.mainImage,
                            );
                      },
                      icon: Icon(ad.isFavoriteFor(userId) || favoritesState.isFavorite(userId: userId, itemId: ad.adId, itemType: FavoriteItemType.ad) ? Icons.favorite_rounded : Icons.favorite_border_rounded),
                    ),
                    IconButton.filledTonal(onPressed: () {}, icon: const Icon(Icons.share_outlined)),
                  ],
                ),
                const SizedBox(height: 12),
                Text(ad.title, style: AppTextStyles.title),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Icon(IconData(category.iconCodePoint, fontFamily: 'MaterialIcons'), color: AppColors.accentGold, size: 18),
                    const SizedBox(width: 6),
                    Text(category.name, style: AppTextStyles.caption.copyWith(color: AppColors.accentGold)),
                  ],
                ),
                const SizedBox(height: 16),
                Text(ad.description, style: AppTextStyles.body.copyWith(height: 1.65)),
                const SizedBox(height: 18),
                _Price(ad: ad),
                const SizedBox(height: 14),
                _InfoRow(icon: Icons.place_outlined, label: 'الموقع', value: ad.locationText),
                _InfoRow(icon: Icons.person_outline_rounded, label: 'صاحب الإعلان', value: ad.ownerName.isEmpty ? 'مستخدم شامل' : ad.ownerName),
                _InfoRow(icon: Icons.timer_outlined, label: 'ينتهي في', value: _date(ad.expiresAt)),
                const SizedBox(height: 18),
                ShamelButton.primary(label: 'اتصال', icon: Icons.phone_outlined, onPressed: () {}),
              ],
            ),
          ),
          const SizedBox(height: 90),
        ],
      ),
    );
  }

  String _date(DateTime value) => '${value.year}/${value.month.toString().padLeft(2, '0')}/${value.day.toString().padLeft(2, '0')}';
}

class _Images extends StatelessWidget {
  const _Images({required this.ad});

  final AdModel ad;

  @override
  Widget build(BuildContext context) {
    if (ad.images.length <= 1) return AdImage(url: ad.mainImage, height: 240, borderRadius: 28);
    return SizedBox(
      height: 240,
      child: PageView(
        children: ad.images.map((url) => Padding(padding: const EdgeInsetsDirectional.only(end: 10), child: AdImage(url: url, height: 240, borderRadius: 28))).toList(),
      ),
    );
  }
}

class _Price extends StatelessWidget {
  const _Price({required this.ad});

  final AdModel ad;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(_price(ad.priceAfter), style: AppTextStyles.title.copyWith(color: AppColors.accentGold)),
        if (ad.priceBefore > 0 && ad.priceBefore > ad.priceAfter) ...[
          const SizedBox(width: 10),
          Text(_price(ad.priceBefore), style: AppTextStyles.caption.copyWith(decoration: TextDecoration.lineThrough)),
        ],
        if (ad.effectiveDiscountPercent > 0) ...[
          const SizedBox(width: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(color: AppColors.accentGold.withOpacity(0.18), borderRadius: BorderRadius.circular(999)),
            child: Text('${ad.effectiveDiscountPercent}% خصم', style: const TextStyle(color: AppColors.accentGold, fontWeight: FontWeight.w900)),
          ),
        ],
      ],
    );
  }

  String _price(double value) {
    if (value <= 0) return 'السعر عند التواصل';
    final clean = value % 1 == 0 ? value.toStringAsFixed(0) : value.toStringAsFixed(2);
    return '$clean ر.ي';
  }
}

class _InfoRow extends StatelessWidget {
  const _InfoRow({required this.icon, required this.label, required this.value});

  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          Icon(icon, color: AppColors.textSecondary, size: 19),
          const SizedBox(width: 8),
          Text('$label: ', style: AppTextStyles.caption),
          Expanded(child: Text(value, style: AppTextStyles.body.copyWith(fontWeight: FontWeight.w700))),
        ],
      ),
    );
  }
}
