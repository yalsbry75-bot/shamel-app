import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/utils/ui_state.dart';
import '../../../../core/widgets/glass_container.dart';
import '../../../../core/widgets/premium_app_bar.dart';
import '../../../../core/widgets/premium_scaffold.dart';
import '../../../../core/widgets/shamel_button.dart';
import '../../../../core/widgets/shamel_text_field.dart';
import '../../../../core/widgets/cloud_image_picker_field.dart';
import '../../../auth/presentation/controllers/auth_controller.dart';
import '../../../provider/presentation/controllers/provider_controller.dart';
import '../../domain/ad_category.dart';
import '../controllers/ads_controller.dart';

class CreateAdScreen extends ConsumerStatefulWidget {
  const CreateAdScreen({super.key});

  @override
  ConsumerState<CreateAdScreen> createState() => _CreateAdScreenState();
}

class _CreateAdScreenState extends ConsumerState<CreateAdScreen> {
  final _title = TextEditingController();
  final _description = TextEditingController();
  final _priceBefore = TextEditingController();
  final _priceAfter = TextEditingController();
  final _location = TextEditingController();
  final _phone = TextEditingController();
  final _duration = TextEditingController(text: '7');
  final _images = TextEditingController();
  String _categoryId = AdCategory.offers.categoryId;

  @override
  void dispose() {
    _title.dispose();
    _description.dispose();
    _priceBefore.dispose();
    _priceAfter.dispose();
    _location.dispose();
    _phone.dispose();
    _duration.dispose();
    _images.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final adsState = ref.watch(adsControllerProvider);
    final user = ref.watch(authControllerProvider).user;
    final provider = ref.watch(providerControllerProvider).profile;
    return PremiumScaffold(
      appBar: const PremiumAppBar(title: 'إضافة إعلان', subtitle: 'إعلان مرتبط بقاعدة البيانات والتخزين السحابي', showBack: true),
      child: ListView(
        children: [
          GlassContainer(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('بيانات الإعلان', style: AppTextStyles.body.copyWith(fontWeight: FontWeight.w900)),
                const SizedBox(height: 12),
                ShamelTextField(controller: _title, hintText: 'عنوان الإعلان', prefixIcon: Icons.title_rounded),
                const SizedBox(height: 12),
                ShamelTextField(controller: _description, hintText: 'وصف الإعلان', prefixIcon: Icons.description_outlined, maxLines: 4),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: _categoryId,
                  decoration: const InputDecoration(labelText: 'التصنيف'),
                  items: AdCategory.values.map((item) => DropdownMenuItem(value: item.categoryId, child: Text(item.name))).toList(),
                  onChanged: (value) => setState(() => _categoryId = value ?? AdCategory.other.categoryId),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(child: ShamelTextField(controller: _priceBefore, hintText: 'السعر القديم', prefixIcon: Icons.money_off_outlined, keyboardType: TextInputType.number)),
                    const SizedBox(width: 10),
                    Expanded(child: ShamelTextField(controller: _priceAfter, hintText: 'السعر الجديد', prefixIcon: Icons.payments_outlined, keyboardType: TextInputType.number)),
                  ],
                ),
                const SizedBox(height: 12),
                ShamelTextField(controller: _location, hintText: 'الموقع النصي', prefixIcon: Icons.place_outlined),
                const SizedBox(height: 12),
                ShamelTextField(controller: _phone, hintText: 'رقم التواصل', prefixIcon: Icons.phone_outlined, keyboardType: TextInputType.phone),
                const SizedBox(height: 12),
                ShamelTextField(controller: _duration, hintText: 'مدة الإعلان بالأيام', prefixIcon: Icons.timer_outlined, keyboardType: TextInputType.number),
                const SizedBox(height: 12),
                CloudImagePickerField(
                  controller: _images,
                  hintText: 'صور الإعلان — يمكن رفع أكثر من صورة',
                  storagePathPrefix: "ads/${user?.userId ?? 'anonymous'}",
                  maxLines: 3,
                ),
                const SizedBox(height: 18),
                if (adsState.errorMessage != null)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Text(adsState.errorMessage!, style: const TextStyle(color: Colors.redAccent, fontWeight: FontWeight.w700)),
                  ),
                ShamelButton.primary(
                  label: 'إنشاء الإعلان',
                  icon: Icons.add_circle_outline_rounded,
                  isLoading: adsState.viewState == ViewState.loading,
                  onPressed: () async {
                    final navigator = Navigator.of(context);
                    final ok = await ref.read(adsControllerProvider.notifier).createAd(
                          userId: user?.userId ?? '',
                          providerId: provider?.providerId ?? '',
                          ownerName: provider?.businessName ?? user?.name ?? '',
                          title: _title.text,
                          description: _description.text,
                          categoryId: _categoryId,
                          images: _images.text.split('\n'),
                          priceBefore: double.tryParse(_priceBefore.text.trim()) ?? 0,
                          priceAfter: double.tryParse(_priceAfter.text.trim()) ?? 0,
                          locationText: _location.text,
                          phoneNumber: _phone.text,
                          durationDays: int.tryParse(_duration.text.trim()) ?? 7,
                        );
                    if (ok && mounted) navigator.pop();
                  },
                ),
              ],
            ),
          ),
          const SizedBox(height: 80),
        ],
      ),
    );
  }
}
