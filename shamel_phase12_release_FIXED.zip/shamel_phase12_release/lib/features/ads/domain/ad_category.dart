class AdCategory {
  const AdCategory({required this.categoryId, required this.name, required this.iconCodePoint});

  final String categoryId;
  final String name;
  final int iconCodePoint;

  static const offers = AdCategory(categoryId: 'offers', name: 'عروض اليوم', iconCodePoint: 0xe54e);
  static const products = AdCategory(categoryId: 'products', name: 'منتجات للبيع', iconCodePoint: 0xe59c);
  static const cars = AdCategory(categoryId: 'cars', name: 'سيارات', iconCodePoint: 0xe1d7);
  static const realEstate = AdCategory(categoryId: 'real_estate', name: 'عقارات', iconCodePoint: 0xe318);
  static const restaurants = AdCategory(categoryId: 'restaurants', name: 'مطاعم', iconCodePoint: 0xe56c);
  static const services = AdCategory(categoryId: 'services', name: 'خدمات', iconCodePoint: 0xe1af);
  static const grocery = AdCategory(categoryId: 'grocery', name: 'بقالات', iconCodePoint: 0xe59e);
  static const devices = AdCategory(categoryId: 'devices', name: 'أجهزة', iconCodePoint: 0xe30a);
  static const other = AdCategory(categoryId: 'other', name: 'أخرى', iconCodePoint: 0xe5c3);

  static const values = [
    offers,
    products,
    cars,
    realEstate,
    restaurants,
    services,
    grocery,
    devices,
    other,
  ];

  static AdCategory byId(String id) {
    return values.firstWhere((item) => item.categoryId == id, orElse: () => other);
  }
}
