import 'ad_status.dart';

class AdModel {
  const AdModel({
    required this.adId,
    required this.userId,
    required this.providerId,
    required this.title,
    required this.description,
    required this.categoryId,
    required this.images,
    required this.priceBefore,
    required this.priceAfter,
    required this.locationText,
    required this.phoneNumber,
    required this.createdAt,
    required this.expiresAt,
    required this.status,
    this.ownerName = '',
    this.discountPercent = 0,
    this.startDate,
    this.endDate,
    this.favoriteUserIds = const [],
  });

  final String adId;
  final String userId;
  final String providerId;
  final String title;
  final String description;
  final String categoryId;
  final List<String> images;
  final double priceBefore;
  final double priceAfter;
  final String locationText;
  final String phoneNumber;
  final DateTime createdAt;
  final DateTime expiresAt;
  final AdStatus status;
  final String ownerName;
  final int discountPercent;
  final DateTime? startDate;
  final DateTime? endDate;
  final List<String> favoriteUserIds;

  bool get isActive => status == AdStatus.active && DateTime.now().isBefore(expiresAt);
  bool get isOffer => discountPercent > 0 || (priceBefore > 0 && priceAfter > 0 && priceAfter < priceBefore);
  bool get hasImage => images.where((item) => item.trim().isNotEmpty).isNotEmpty;
  String get mainImage => hasImage ? images.firstWhere((item) => item.trim().isNotEmpty) : '';

  int get effectiveDiscountPercent {
    if (discountPercent > 0) return discountPercent;
    if (priceBefore <= 0 || priceAfter <= 0 || priceAfter >= priceBefore) return 0;
    return (((priceBefore - priceAfter) / priceBefore) * 100).round();
  }

  bool isFavoriteFor(String userId) => favoriteUserIds.contains(userId);

  factory AdModel.fromJson(Map<String, dynamic> json) {
    return AdModel(
      adId: json['adId'] as String? ?? '',
      userId: json['userId'] as String? ?? '',
      providerId: json['providerId'] as String? ?? '',
      title: json['title'] as String? ?? '',
      description: json['description'] as String? ?? '',
      categoryId: json['categoryId'] as String? ?? 'other',
      images: (json['images'] as List<dynamic>? ?? const []).map((item) => item.toString()).toList(growable: false),
      priceBefore: _double(json['priceBefore']),
      priceAfter: _double(json['priceAfter']),
      locationText: json['locationText'] as String? ?? '',
      phoneNumber: json['phoneNumber'] as String? ?? '',
      createdAt: DateTime.parse(json['createdAt'] as String),
      expiresAt: DateTime.parse(json['expiresAt'] as String),
      status: AdStatusX.fromValue(json['status'] as String? ?? 'pending'),
      ownerName: json['ownerName'] as String? ?? '',
      discountPercent: json['discountPercent'] as int? ?? 0,
      startDate: _date(json['startDate']),
      endDate: _date(json['endDate']),
      favoriteUserIds: (json['favoriteUserIds'] as List<dynamic>? ?? const []).map((item) => item.toString()).toList(growable: false),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'adId': adId,
      'userId': userId,
      'providerId': providerId,
      'title': title,
      'description': description,
      'categoryId': categoryId,
      'images': images,
      'priceBefore': priceBefore,
      'priceAfter': priceAfter,
      'locationText': locationText,
      'phoneNumber': phoneNumber,
      'createdAt': createdAt.toIso8601String(),
      'expiresAt': expiresAt.toIso8601String(),
      'status': status.value,
      'ownerName': ownerName,
      'discountPercent': discountPercent,
      'startDate': startDate?.toIso8601String(),
      'endDate': endDate?.toIso8601String(),
      'favoriteUserIds': favoriteUserIds,
    };
  }

  AdModel copyWith({
    String? adId,
    String? userId,
    String? providerId,
    String? title,
    String? description,
    String? categoryId,
    List<String>? images,
    double? priceBefore,
    double? priceAfter,
    String? locationText,
    String? phoneNumber,
    DateTime? createdAt,
    DateTime? expiresAt,
    AdStatus? status,
    String? ownerName,
    int? discountPercent,
    DateTime? startDate,
    DateTime? endDate,
    List<String>? favoriteUserIds,
  }) {
    return AdModel(
      adId: adId ?? this.adId,
      userId: userId ?? this.userId,
      providerId: providerId ?? this.providerId,
      title: title ?? this.title,
      description: description ?? this.description,
      categoryId: categoryId ?? this.categoryId,
      images: images ?? this.images,
      priceBefore: priceBefore ?? this.priceBefore,
      priceAfter: priceAfter ?? this.priceAfter,
      locationText: locationText ?? this.locationText,
      phoneNumber: phoneNumber ?? this.phoneNumber,
      createdAt: createdAt ?? this.createdAt,
      expiresAt: expiresAt ?? this.expiresAt,
      status: status ?? this.status,
      ownerName: ownerName ?? this.ownerName,
      discountPercent: discountPercent ?? this.discountPercent,
      startDate: startDate ?? this.startDate,
      endDate: endDate ?? this.endDate,
      favoriteUserIds: favoriteUserIds ?? this.favoriteUserIds,
    );
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        other is AdModel &&
            runtimeType == other.runtimeType &&
            adId == other.adId &&
            userId == other.userId &&
            providerId == other.providerId &&
            title == other.title &&
            description == other.description &&
            categoryId == other.categoryId &&
            _sameList(images, other.images) &&
            priceBefore == other.priceBefore &&
            priceAfter == other.priceAfter &&
            locationText == other.locationText &&
            phoneNumber == other.phoneNumber &&
            createdAt == other.createdAt &&
            expiresAt == other.expiresAt &&
            status == other.status &&
            ownerName == other.ownerName &&
            discountPercent == other.discountPercent &&
            startDate == other.startDate &&
            endDate == other.endDate &&
            _sameList(favoriteUserIds, other.favoriteUserIds);
  }

  @override
  int get hashCode => Object.hashAll([
        adId,
        userId,
        providerId,
        title,
        description,
        categoryId,
        Object.hashAll(images),
        priceBefore,
        priceAfter,
        locationText,
        phoneNumber,
        createdAt,
        expiresAt,
        status,
        ownerName,
        discountPercent,
        startDate,
        endDate,
        Object.hashAll(favoriteUserIds),
      ]);

  static DateTime? _date(dynamic value) {
    if (value == null || value.toString().trim().isEmpty) return null;
    return DateTime.tryParse(value.toString());
  }

  static double _double(dynamic value) {
    if (value == null) return 0;
    if (value is num) return value.toDouble();
    return double.tryParse(value.toString()) ?? 0;
  }

  static bool _sameList(List<String> first, List<String> second) {
    if (first.length != second.length) return false;
    for (var i = 0; i < first.length; i += 1) {
      if (first[i] != second[i]) return false;
    }
    return true;
  }
}
