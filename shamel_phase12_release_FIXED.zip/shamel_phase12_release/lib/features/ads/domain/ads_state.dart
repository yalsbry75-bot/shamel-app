import '../../../core/utils/ui_state.dart';
import 'ad_model.dart';

class AdsState {
  const AdsState({
    this.viewState = ViewState.initial,
    this.ads = const [],
    this.selectedCategoryId,
    this.message,
    this.errorMessage,
  });

  final ViewState viewState;
  final List<AdModel> ads;
  final String? selectedCategoryId;
  final String? message;
  final String? errorMessage;

  bool get isLoading => viewState == ViewState.loading;
  List<AdModel> get activeAds => ads.where((item) => item.isActive).toList(growable: false);
  List<AdModel> get bannerAds => activeAds.take(5).toList(growable: false);
  List<AdModel> get offers => activeAds.where((item) => item.isOffer).toList(growable: false);
  List<AdModel> get filteredAds {
    final category = selectedCategoryId;
    if (category == null || category.isEmpty) return activeAds;
    return activeAds.where((item) => item.categoryId == category).toList(growable: false);
  }

  List<AdModel> favoritesFor(String userId) {
    if (userId.trim().isEmpty) return const [];
    return activeAds.where((item) => item.isFavoriteFor(userId)).toList(growable: false);
  }

  AdModel? byId(String adId) {
    for (final ad in ads) {
      if (ad.adId == adId) return ad;
    }
    return null;
  }

  AdsState copyWith({
    ViewState? viewState,
    List<AdModel>? ads,
    String? selectedCategoryId,
    bool clearSelectedCategory = false,
    String? message,
    bool clearMessage = false,
    String? errorMessage,
    bool clearError = false,
  }) {
    return AdsState(
      viewState: viewState ?? this.viewState,
      ads: ads ?? this.ads,
      selectedCategoryId: clearSelectedCategory ? null : selectedCategoryId ?? this.selectedCategoryId,
      message: clearMessage ? null : message ?? this.message,
      errorMessage: clearError ? null : errorMessage ?? this.errorMessage,
    );
  }
}
