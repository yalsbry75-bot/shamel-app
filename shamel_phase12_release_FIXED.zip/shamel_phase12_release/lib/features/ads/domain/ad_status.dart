enum AdStatus { pending, active, rejected, expired }

extension AdStatusX on AdStatus {
  String get value {
    switch (this) {
      case AdStatus.pending:
        return 'pending';
      case AdStatus.active:
        return 'active';
      case AdStatus.rejected:
        return 'rejected';
      case AdStatus.expired:
        return 'expired';
    }
  }

  String get label {
    switch (this) {
      case AdStatus.pending:
        return 'بانتظار المراجعة';
      case AdStatus.active:
        return 'نشط';
      case AdStatus.rejected:
        return 'مرفوض';
      case AdStatus.expired:
        return 'منتهي';
    }
  }

  static AdStatus fromValue(String value) {
    return AdStatus.values.firstWhere(
      (item) => item.value == value,
      orElse: () => AdStatus.pending,
    );
  }
}
