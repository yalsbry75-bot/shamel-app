import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/errors/app_exception.dart';
import '../domain/ad_model.dart';
import '../domain/ad_status.dart';
import 'ads_service.dart';

final adsServiceProvider = Provider<AdsService>((ref) => FirebaseAdsService());

final adsRepositoryProvider = Provider<AdsRepository>((ref) {
  return AdsRepository(ref.watch(adsServiceProvider));
});

class AdsRepository {
  const AdsRepository(this._service);

  final AdsService _service;

  Future<List<AdModel>> loadAll() => _service.loadAll();
  Future<AdModel?> findById(String adId) => _service.findById(adId);

  Future<AdModel> createAd({
    required String userId,
    required String providerId,
    required String ownerName,
    required String title,
    required String description,
    required String categoryId,
    required List<String> images,
    required double priceBefore,
    required double priceAfter,
    required String locationText,
    required String phoneNumber,
    required int durationDays,
  }) async {
    if (userId.trim().isEmpty) {
      throw const AppException('الجلسة غير متاحة. أعد تسجيل الدخول.', code: 'SESSION_REQUIRED');
    }
    if (title.trim().length < 3 || description.trim().length < 10) {
      throw const AppException('اكتب عنوانًا واضحًا ووصفًا لا يقل عن 10 أحرف.', code: 'INVALID_AD_COPY');
    }
    if (phoneNumber.trim().isEmpty || locationText.trim().isEmpty) {
      throw const AppException('رقم التواصل والموقع مطلوبة.', code: 'INVALID_AD_CONTACT');
    }
    final now = DateTime.now();
    final normalizedDuration = durationDays <= 0 ? 7 : durationDays;
    final ad = AdModel(
      adId: _id('ad', userId),
      userId: userId,
      providerId: providerId,
      title: title.trim(),
      description: description.trim(),
      categoryId: categoryId.trim(),
      images: images.where((item) => item.trim().isNotEmpty).map((item) => item.trim()).toList(growable: false),
      priceBefore: priceBefore,
      priceAfter: priceAfter,
      locationText: locationText.trim(),
      phoneNumber: phoneNumber.trim(),
      createdAt: now,
      expiresAt: now.add(Duration(days: normalizedDuration)),
      status: AdStatus.pending,
      ownerName: ownerName.trim().isEmpty ? 'مستخدم شامل' : ownerName.trim(),
      discountPercent: _discount(priceBefore, priceAfter),
      startDate: now,
      endDate: now.add(Duration(days: normalizedDuration)),
    );
    return _service.create(ad);
  }

  Future<AdModel> updateStatus(String adId, AdStatus status) async {
    final ad = await _mustFind(adId);
    return _service.update(ad.copyWith(status: status));
  }

  Future<AdModel> toggleFavorite({required String adId, required String userId}) async {
    if (userId.trim().isEmpty) throw const AppException('سجل الدخول لإضافة الإعلان إلى المفضلة.', code: 'SESSION_REQUIRED');
    final ad = await _mustFind(adId);
    final favorites = [...ad.favoriteUserIds];
    if (favorites.contains(userId)) {
      favorites.remove(userId);
    } else {
      favorites.add(userId);
    }
    return _service.update(ad.copyWith(favoriteUserIds: favorites));
  }

  Future<AdModel> _mustFind(String adId) async {
    final ad = await _service.findById(adId);
    if (ad == null) throw const AppException('لم يتم العثور على الإعلان.', code: 'AD_NOT_FOUND');
    return ad;
  }

  int _discount(double before, double after) {
    if (before <= 0 || after <= 0 || after >= before) return 0;
    return (((before - after) / before) * 100).round();
  }

  String _id(String prefix, String owner) {
    return '${prefix}_${owner.hashCode.abs()}_${DateTime.now().microsecondsSinceEpoch}';
  }
}
