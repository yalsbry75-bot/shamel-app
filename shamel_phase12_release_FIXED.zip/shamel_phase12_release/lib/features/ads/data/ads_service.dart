import '../../../core/performance/app_performance.dart';
import '../../../core/security/rate_limiter_service.dart';
import '../domain/ad_model.dart';

import '../../../core/database/firestore_json.dart';
import '../../../core/database/firestore_collections.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
abstract class AdsService {
  Future<List<AdModel>> loadAll();
  Future<AdModel> create(AdModel ad);
  Future<AdModel> update(AdModel ad);
  Future<AdModel?> findById(String adId);
}

class FirebaseAdsService implements AdsService {
  FirebaseAdsService({FirebaseFirestore? firestore, RateLimiterService? rateLimiter})
      : _firestore = firestore ?? FirebaseFirestore.instance,
        _rateLimiter = rateLimiter ?? const RateLimiterService();

  final FirebaseFirestore _firestore;
  final RateLimiterService _rateLimiter;

  @override
  Future<List<AdModel>> loadAll() async {
    return AppPerformance.trace('ads_load_all', () async {
      final snapshot = await _firestore.collection(FirestoreCollections.ads).orderBy('createdAt', descending: true).limit(100).get();
      return snapshot.docs.map((doc) => AdModel.fromJson(FirestoreJson.normalize(doc.data()))).toList(growable: false);
    });
  }

  @override
  Future<AdModel?> findById(String adId) async {
    final doc = await _firestore.collection(FirestoreCollections.ads).doc(adId).get();
    if (!doc.exists || doc.data() == null) return null;
    return AdModel.fromJson(FirestoreJson.normalize(doc.data()!));
  }

  @override
  Future<AdModel> create(AdModel ad) async {
    await _rateLimiter.check(key: 'ad_${ad.userId}', rule: RateLimiterService.adRule, message: 'تم إنشاء إعلانات كثيرة خلال وقت قصير. حاول لاحقًا.');
    await _firestore.collection(FirestoreCollections.ads).doc(ad.adId).set(FirestoreJson.withServerAudit(ad.toJson(), isCreate: true), SetOptions(merge: true));
    return ad;
  }

  @override
  Future<AdModel> update(AdModel ad) async {
    await _firestore.collection(FirestoreCollections.ads).doc(ad.adId).set(FirestoreJson.withServerAudit(ad.toJson()), SetOptions(merge: true));
    return ad;
  }
}
