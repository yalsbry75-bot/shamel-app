import '../../../core/errors/app_exception.dart';
import '../domain/rating_model.dart';

import '../../../core/database/firestore_json.dart';
import '../../../core/database/firestore_collections.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
abstract class RatingService {
  Future<List<RatingModel>> getProviderRatings(String providerId);
  Future<RatingModel> save(RatingModel rating);
  Future<void> delete(String ratingId);
}

class FirebaseRatingService implements RatingService {
  FirebaseRatingService({FirebaseFirestore? firestore}) : _firestore = firestore ?? FirebaseFirestore.instance;
  final FirebaseFirestore _firestore;

  @override
  Future<List<RatingModel>> getProviderRatings(String providerId) async {
    final snapshot = await _firestore.collection(FirestoreCollections.ratings).where('providerId', isEqualTo: providerId).orderBy('createdAt', descending: true).limit(80).get();
    return snapshot.docs.map((doc) => RatingModel.fromJson(FirestoreJson.normalize(doc.data()))).toList(growable: false);
  }

  @override
  Future<RatingModel> save(RatingModel rating) async {
    if (rating.stars < 1 || rating.stars > 5) {
      throw const AppException('التقييم يجب أن يكون من 1 إلى 5.', code: 'INVALID_RATING');
    }
    await _firestore.collection(FirestoreCollections.ratings).doc(rating.ratingId).set(FirestoreJson.withServerAudit(rating.toJson(), isCreate: true), SetOptions(merge: true));
    return rating;
  }

  @override
  Future<void> delete(String ratingId) async {
    await _firestore.collection(FirestoreCollections.ratings).doc(ratingId).delete();
  }
}
