import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../domain/rating_model.dart';
import 'rating_service.dart';

final ratingServiceProvider = Provider<RatingService>((ref) => FirebaseRatingService());

final ratingRepositoryProvider = Provider<RatingRepository>((ref) {
  return RatingRepository(ref.watch(ratingServiceProvider));
});

class RatingRepository {
  const RatingRepository(this._service);

  final RatingService _service;

  Future<List<RatingModel>> getProviderRatings(String providerId) {
    return _service.getProviderRatings(providerId);
  }

  Future<RatingModel> addRating({required String providerId, required String userId, required int stars, required String comment}) {
    final rating = RatingModel(
      ratingId: 'rat_${providerId}_${DateTime.now().microsecondsSinceEpoch}',
      providerId: providerId,
      userId: userId,
      stars: stars,
      comment: comment.trim(),
      createdAt: DateTime.now(),
    );
    return _service.save(rating);
  }

  Future<void> deleteRating(String ratingId) {
    return _service.delete(ratingId);
  }
}
