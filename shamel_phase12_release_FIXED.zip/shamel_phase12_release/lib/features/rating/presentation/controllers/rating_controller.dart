import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/errors/app_exception.dart';
import '../../../../core/utils/ui_state.dart';
import '../../data/rating_repository.dart';
import '../../domain/rating_state.dart';
import '../../domain/rating_summary.dart';

final ratingControllerProvider = StateNotifierProvider<RatingController, RatingState>((ref) {
  return RatingController(ref.watch(ratingRepositoryProvider));
});

class RatingController extends StateNotifier<RatingState> {
  RatingController(this._repository) : super(const RatingState());

  final RatingRepository _repository;

  Future<void> load(String providerId) async {
    state = state.copyWith(viewState: ViewState.loading, clearError: true, clearMessage: true);
    try {
      final ratings = await _repository.getProviderRatings(providerId);
      state = state.copyWith(
        viewState: ratings.isEmpty ? ViewState.empty : ViewState.success,
        ratings: ratings,
        summary: RatingSummary.fromRatings(ratings),
      );
    } catch (error) {
      state = state.copyWith(viewState: ViewState.error, errorMessage: _safeMessage(error));
    }
  }

  Future<void> addRating({required String providerId, required String userId, required int stars, required String comment}) async {
    state = state.copyWith(viewState: ViewState.loading, clearError: true, clearMessage: true);
    try {
      await _repository.addRating(providerId: providerId, userId: userId, stars: stars, comment: comment);
      final ratings = await _repository.getProviderRatings(providerId);
      state = state.copyWith(
        viewState: ratings.isEmpty ? ViewState.empty : ViewState.success,
        ratings: ratings,
        summary: RatingSummary.fromRatings(ratings),
        message: 'تمت إضافة التقييم',
      );
    } catch (error) {
      state = state.copyWith(viewState: ViewState.error, errorMessage: _safeMessage(error));
    }
  }

  Future<void> deleteRating({required String providerId, required String ratingId}) async {
    await _repository.deleteRating(ratingId);
    final ratings = await _repository.getProviderRatings(providerId);
    state = state.copyWith(
      viewState: ratings.isEmpty ? ViewState.empty : ViewState.success,
      ratings: ratings,
      summary: RatingSummary.fromRatings(ratings),
      message: 'تم حذف التقييم',
    );
  }

  String _safeMessage(Object error) {
    if (error is AppException) return error.message;
    return 'تعذر إكمال العملية. حاول مرة أخرى.';
  }
}
