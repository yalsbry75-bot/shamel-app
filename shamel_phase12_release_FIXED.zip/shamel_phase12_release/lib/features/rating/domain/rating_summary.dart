import 'rating_model.dart';

class RatingSummary {
  const RatingSummary({required this.average, required this.count});

  final double average;
  final int count;

  factory RatingSummary.fromRatings(List<RatingModel> ratings) {
    if (ratings.isEmpty) return const RatingSummary(average: 0, count: 0);
    final total = ratings.fold<int>(0, (sum, item) => sum + item.stars);
    return RatingSummary(average: total / ratings.length, count: ratings.length);
  }
}
