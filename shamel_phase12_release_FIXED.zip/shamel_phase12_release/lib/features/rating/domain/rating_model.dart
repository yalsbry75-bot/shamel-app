class RatingModel {
  const RatingModel({
    required this.ratingId,
    required this.providerId,
    required this.userId,
    required this.stars,
    required this.comment,
    required this.createdAt,
  });

  final String ratingId;
  final String providerId;
  final String userId;
  final int stars;
  final String comment;
  final DateTime createdAt;

  factory RatingModel.fromJson(Map<String, dynamic> json) {
    return RatingModel(
      ratingId: json['ratingId'] as String? ?? '',
      providerId: json['providerId'] as String? ?? '',
      userId: json['userId'] as String? ?? '',
      stars: json['stars'] as int? ?? 0,
      comment: json['comment'] as String? ?? '',
      createdAt: DateTime.parse(json['createdAt'] as String),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'ratingId': ratingId,
      'providerId': providerId,
      'userId': userId,
      'stars': stars,
      'comment': comment,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  RatingModel copyWith({
    String? ratingId,
    String? providerId,
    String? userId,
    int? stars,
    String? comment,
    DateTime? createdAt,
  }) {
    return RatingModel(
      ratingId: ratingId ?? this.ratingId,
      providerId: providerId ?? this.providerId,
      userId: userId ?? this.userId,
      stars: stars ?? this.stars,
      comment: comment ?? this.comment,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        other is RatingModel &&
            runtimeType == other.runtimeType &&
            ratingId == other.ratingId &&
            providerId == other.providerId &&
            userId == other.userId &&
            stars == other.stars &&
            comment == other.comment &&
            createdAt == other.createdAt;
  }

  @override
  int get hashCode => Object.hash(ratingId, providerId, userId, stars, comment, createdAt);
}
