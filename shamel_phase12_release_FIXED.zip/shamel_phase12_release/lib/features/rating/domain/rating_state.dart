import '../../../core/utils/ui_state.dart';
import 'rating_model.dart';
import 'rating_summary.dart';

class RatingState {
  const RatingState({
    this.viewState = ViewState.initial,
    this.ratings = const [],
    this.summary = const RatingSummary(average: 0, count: 0),
    this.message,
    this.errorMessage,
  });

  final ViewState viewState;
  final List<RatingModel> ratings;
  final RatingSummary summary;
  final String? message;
  final String? errorMessage;

  RatingState copyWith({
    ViewState? viewState,
    List<RatingModel>? ratings,
    RatingSummary? summary,
    String? message,
    bool clearMessage = false,
    String? errorMessage,
    bool clearError = false,
  }) {
    return RatingState(
      viewState: viewState ?? this.viewState,
      ratings: ratings ?? this.ratings,
      summary: summary ?? this.summary,
      message: clearMessage ? null : message ?? this.message,
      errorMessage: clearError ? null : errorMessage ?? this.errorMessage,
    );
  }
}
