import '../../../core/utils/ui_state.dart';
import 'marketplace_category_model.dart';

class MarketplaceState {
  const MarketplaceState({this.viewState = ViewState.success, this.categories = const []});

  final ViewState viewState;
  final List<MarketplaceCategoryModel> categories;
}
