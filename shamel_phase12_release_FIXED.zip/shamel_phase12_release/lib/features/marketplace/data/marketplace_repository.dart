import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../domain/marketplace_category_model.dart';

final marketplaceRepositoryProvider = Provider<MarketplaceRepository>((ref) => const MarketplaceRepository());

class MarketplaceRepository {
  const MarketplaceRepository();

  List<MarketplaceCategoryModel> categories() {
    return const [
      MarketplaceCategoryModel(id: 'offers', name: 'عروض اليوم', description: 'خصومات مؤقتة وعروض يومية'),
      MarketplaceCategoryModel(id: 'products', name: 'منتجات للبيع', description: 'منتجات متنوعة من المستخدمين ومقدمي الخدمات'),
      MarketplaceCategoryModel(id: 'cars', name: 'سيارات', description: 'سيارات ومستلزمات المركبات'),
      MarketplaceCategoryModel(id: 'real_estate', name: 'عقارات', description: 'عقارات للإيجار أو البيع'),
      MarketplaceCategoryModel(id: 'restaurants', name: 'مطاعم', description: 'عروض وجبات ومطاعم'),
      MarketplaceCategoryModel(id: 'services', name: 'خدمات', description: 'خدمات فردية وتجارية'),
      MarketplaceCategoryModel(id: 'other', name: 'أخرى', description: 'إعلانات لا تندرج تحت قسم محدد'),
    ];
  }
}
