class MarketplaceService {
  const MarketplaceService();
}
