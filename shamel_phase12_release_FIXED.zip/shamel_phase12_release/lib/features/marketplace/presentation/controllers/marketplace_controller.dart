import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/marketplace_repository.dart';
import '../../domain/marketplace_state.dart';

final marketplaceControllerProvider = Provider<MarketplaceState>((ref) {
  final repository = ref.watch(marketplaceRepositoryProvider);
  return MarketplaceState(categories: repository.categories());
});
