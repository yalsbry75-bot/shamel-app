import '../../../ads/presentation/screens/ads_screen.dart';

class MarketplaceScreen extends AdsScreen {
  const MarketplaceScreen({super.key});
}
