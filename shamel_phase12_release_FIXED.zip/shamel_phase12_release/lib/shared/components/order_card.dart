import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../core/widgets/glass_container.dart';

class OrderCard extends StatelessWidget {
  const OrderCard({
    super.key,
    required this.title,
    required this.status,
    required this.dateLabel,
  });

  final String title;
  final String status;
  final String dateLabel;

  @override
  Widget build(BuildContext context) {
    return GlassContainer(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text(title, style: AppTextStyles.section)),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: AppColors.primary.withOpacity(0.16),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(status, style: AppTextStyles.caption.copyWith(color: AppColors.primary)),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(dateLabel, style: AppTextStyles.caption),
        ],
      ),
    );
  }
}
