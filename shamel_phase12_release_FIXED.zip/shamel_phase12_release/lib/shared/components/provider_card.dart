import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../core/widgets/glass_container.dart';

class ProviderCard extends StatelessWidget {
  const ProviderCard({
    super.key,
    required this.name,
    required this.specialty,
    required this.rating,
  });

  final String name;
  final String specialty;
  final double rating;

  @override
  Widget build(BuildContext context) {
    return GlassContainer(
      child: Row(
        children: [
          const CircleAvatar(
            radius: 24,
            backgroundColor: AppColors.surfaceHigh,
            child: Icon(Icons.person_outline_rounded, color: AppColors.textPrimary),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(name, style: AppTextStyles.body.copyWith(fontWeight: FontWeight.w800)),
                const SizedBox(height: 4),
                Text(specialty, style: AppTextStyles.caption),
              ],
            ),
          ),
          Row(
            children: [
              const Icon(Icons.star_rounded, color: AppColors.accentGold, size: 18),
              Text(rating.toStringAsFixed(1), style: AppTextStyles.caption),
            ],
          ),
        ],
      ),
    );
  }
}
