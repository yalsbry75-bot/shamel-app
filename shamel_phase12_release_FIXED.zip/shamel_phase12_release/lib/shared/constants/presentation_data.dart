class PresentationData {
  const PresentationData._();

  static const categories = [
    'صيانة',
    'نقل',
    'تنظيف',
    'تعليم',
    'تصميم',
    'تقنية',
  ];

  static const services = [
    ('صيانة منزلية', 'صيانة', 'تصميم فقط'),
    ('تصميم إعلان', 'تصميم', 'تصميم فقط'),
    ('دعم تقني', 'تقنية', 'تصميم فقط'),
  ];
}
