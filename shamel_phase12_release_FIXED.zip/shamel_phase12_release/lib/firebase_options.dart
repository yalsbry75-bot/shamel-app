import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart' show TargetPlatform, defaultTargetPlatform, kIsWeb;

/// Firebase runtime configuration for Shamel production builds.
///
/// Preferred setup: replace this file with the output of:
///   flutterfire configure --project=<firebase-project-id>
///
/// Alternative setup: pass the values below with --dart-define during build.
class DefaultFirebaseOptions {
  const DefaultFirebaseOptions._();

  static FirebaseOptions get currentPlatform {
    if (kIsWeb) return web;
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        return macos;
      case TargetPlatform.windows:
        return windows;
      case TargetPlatform.linux:
        return linux;
      case TargetPlatform.fuchsia:
        return android;
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: String.fromEnvironment('SHAMEL_FIREBASE_WEB_API_KEY'),
    appId: String.fromEnvironment('SHAMEL_FIREBASE_WEB_APP_ID'),
    messagingSenderId: String.fromEnvironment('SHAMEL_FIREBASE_MESSAGING_SENDER_ID'),
    projectId: String.fromEnvironment('SHAMEL_FIREBASE_PROJECT_ID'),
    authDomain: String.fromEnvironment('SHAMEL_FIREBASE_AUTH_DOMAIN'),
    storageBucket: String.fromEnvironment('SHAMEL_FIREBASE_STORAGE_BUCKET'),
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: String.fromEnvironment('SHAMEL_FIREBASE_ANDROID_API_KEY'),
    appId: String.fromEnvironment('SHAMEL_FIREBASE_ANDROID_APP_ID'),
    messagingSenderId: String.fromEnvironment('SHAMEL_FIREBASE_MESSAGING_SENDER_ID'),
    projectId: String.fromEnvironment('SHAMEL_FIREBASE_PROJECT_ID'),
    storageBucket: String.fromEnvironment('SHAMEL_FIREBASE_STORAGE_BUCKET'),
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: String.fromEnvironment('SHAMEL_FIREBASE_IOS_API_KEY'),
    appId: String.fromEnvironment('SHAMEL_FIREBASE_IOS_APP_ID'),
    messagingSenderId: String.fromEnvironment('SHAMEL_FIREBASE_MESSAGING_SENDER_ID'),
    projectId: String.fromEnvironment('SHAMEL_FIREBASE_PROJECT_ID'),
    storageBucket: String.fromEnvironment('SHAMEL_FIREBASE_STORAGE_BUCKET'),
    iosBundleId: 'com.shamel.app',
  );

  static const FirebaseOptions macos = FirebaseOptions(
    apiKey: String.fromEnvironment('SHAMEL_FIREBASE_MACOS_API_KEY'),
    appId: String.fromEnvironment('SHAMEL_FIREBASE_MACOS_APP_ID'),
    messagingSenderId: String.fromEnvironment('SHAMEL_FIREBASE_MESSAGING_SENDER_ID'),
    projectId: String.fromEnvironment('SHAMEL_FIREBASE_PROJECT_ID'),
    storageBucket: String.fromEnvironment('SHAMEL_FIREBASE_STORAGE_BUCKET'),
    iosBundleId: 'com.shamel.app',
  );

  static const FirebaseOptions windows = FirebaseOptions(
    apiKey: String.fromEnvironment('SHAMEL_FIREBASE_WINDOWS_API_KEY'),
    appId: String.fromEnvironment('SHAMEL_FIREBASE_WINDOWS_APP_ID'),
    messagingSenderId: String.fromEnvironment('SHAMEL_FIREBASE_MESSAGING_SENDER_ID'),
    projectId: String.fromEnvironment('SHAMEL_FIREBASE_PROJECT_ID'),
    authDomain: String.fromEnvironment('SHAMEL_FIREBASE_AUTH_DOMAIN'),
    storageBucket: String.fromEnvironment('SHAMEL_FIREBASE_STORAGE_BUCKET'),
  );

  static const FirebaseOptions linux = FirebaseOptions(
    apiKey: String.fromEnvironment('SHAMEL_FIREBASE_LINUX_API_KEY'),
    appId: String.fromEnvironment('SHAMEL_FIREBASE_LINUX_APP_ID'),
    messagingSenderId: String.fromEnvironment('SHAMEL_FIREBASE_MESSAGING_SENDER_ID'),
    projectId: String.fromEnvironment('SHAMEL_FIREBASE_PROJECT_ID'),
    storageBucket: String.fromEnvironment('SHAMEL_FIREBASE_STORAGE_BUCKET'),
  );
}
