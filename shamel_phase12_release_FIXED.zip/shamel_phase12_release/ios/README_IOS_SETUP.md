# iOS Setup Note

لم يتم إنشاء مجلد iOS كامل داخل هذه البيئة لأن Flutter SDK غير متاح لتشغيل:

```bash
flutter create --platforms=ios .
```

لتهيئة iOS لاحقًا من نفس المشروع:

```bash
flutter create --platforms=ios .
flutterfire configure --project=<your-firebase-project-id>
flutter pub get
cd ios && pod install
```

بعد ذلك أضف Bundle ID مطابقًا في Firebase وApple Developer Console، ثم اختبر على جهاز iPhone حقيقي.
