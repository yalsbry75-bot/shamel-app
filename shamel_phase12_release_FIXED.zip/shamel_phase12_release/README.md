# شامل — Production Release

تطبيق شامل: كل خدماتك في مكان واحد.

هذه النسخة هي **Phase 12 — Production Release** مبنية على جميع المراحل السابقة، مع تجهيزات الإنتاج، Android Release configuration، وثائق البناء والنشر، وحماية تشغيل تمنع الانهيار عند غياب إعداد Firebase الحقيقي.

## معلومات الإصدار

- App Name: شامل
- Package Name: `com.shamel.app`
- Version: `1.0.1+13`
- UI: Arabic RTL
- Theme: Dark Premium / Apple Style
- State Management: Riverpod
- Backend Target: Firebase

## حالة المشروع

المشروع جاهز كمصدر Production Release، لكن APK/AAB لم يتم بناؤهما داخل هذه البيئة لأن Flutter SDK وAndroid build tools غير متاحة هنا.

قبل البناء الحقيقي يجب إضافة:

```text
lib/firebase_options.dart              # مولد من FlutterFire CLI
android/app/google-services.json       # من Firebase Console
android/key.properties                 # إعداد توقيع محلي
release-keystore.jks                   # مفتاح توقيع محلي
```

عند غياب Firebase الحقيقي سيعرض التطبيق شاشة إعداد إنتاج بدل Crash أو شاشة بيضاء.

## أوامر التشغيل والبناء

```bash
flutter clean
flutter pub get
flutter analyze
flutter test
flutter run --release
flutter build apk --release
flutter build appbundle --release
```

## أهم الوثائق

- `docs/FINAL_DOCUMENTATION.md`
- `docs/release/BUILD_RELEASE_GUIDE.md`
- `docs/release/RELEASE_NOTES.md`
- `docs/release/APP_DESCRIPTION_AR.md`
- `docs/release/PRIVACY_POLICY.md`
- `docs/release/TERMS_AND_CONDITIONS.md`
- `docs/release/FINAL_RELEASE_CHECKLIST.md`
- `PHASE12_IMPLEMENTATION_REPORT.md`
- `PLATFORM_NOTE.md`

## هيكل المشروع

```text
lib/
 ├── admin_panel/
 ├── core/
 ├── features/
 ├── models/
 ├── routes/
 └── shared/
```

## Firebase

راجع:

```text
docs/BACKEND_SETUP.md
docs/FINAL_DOCUMENTATION.md
```

أوامر النشر بعد إعداد Firebase:

```bash
firebase deploy --only firestore:rules,firestore:indexes,storage
firebase deploy --only functions
```

## Android Signing

انسخ:

```text
android/key.properties.example
```

إلى:

```text
android/key.properties
```

ثم عدل القيم الحقيقية. لا ترفع `key.properties` أو `release-keystore.jks` لأي مستودع.

## ملاحظة نهائية

هذه النسخة لا تحتوي على بيانات تطوير أو بيانات دخول مضمّنة أو مفاتيح حساسة. الربط الحقيقي يتطلب إعداد Firebase ومفتاح التوقيع محليًا قبل إصدار APK/AAB النهائي.
