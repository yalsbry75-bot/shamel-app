# PENDING_ACTIONS_REPORT — النواقص والمتطلبات الخارجية

> **تحديث مراجعة إضافية (هذه الجلسة):** تم فتح نفس مشروع Phase 12 (لم يُنشأ مشروع جديد) وإجراء مراجعة يدوية شاملة لأخطاء الكود. بيئة هذه الجلسة أيضًا لا تحتوي على Flutter SDK ولا اتصال إنترنت (نفس القيد الموثق أدناه)، لذلك لم يكن ممكنًا تشغيل `flutter pub get` / `flutter analyze` / `flutter test` / `flutter build apk` فعليًا. التفاصيل الكاملة لما تم فحصه وإصلاحه موجودة في `BUILD_FIX_REPORT.md` الجديد في جذر المشروع.

## 1. المتطلبات التي يجب أن ينفذها مالك المشروع

### Firebase
يجب على مالك المشروع إنشاء أو استخدام مشروع Firebase حقيقي، ثم إضافة الإعدادات التالية:

- `lib/firebase_options.dart` الحقيقي عبر الأمر:

```bash
flutterfire configure --project=<firebase-project-id>
```

- ملف Android:

```text
android/app/google-services.json
```

- ملف iOS عند إنشاء مشروع iOS الرسمي:

```text
ios/Runner/GoogleService-Info.plist
```

- تفعيل Firebase Authentication:
  - Phone Authentication.
  - Email/Password لحسابات الإدارة.

- إضافة SHA-1 وSHA-256 لتطبيق Android داخل Firebase Console حتى يعمل OTP بشكل صحيح.

- إنشاء حساب مدير داخل Firebase Auth، ثم إنشاء وثيقة مقابلة داخل:

```text
admins/{uid}
```

مع الحقول المناسبة مثل الدور `superAdmin` وحالة التفعيل `isActive: true`.

### Push Notifications
يجب تنفيذ التالي من حساب المالك:

- تفعيل Firebase Cloud Messaging.
- رفع APNs Key في Firebase Console عند دعم iOS.
- نشر Cloud Function الموجودة داخل `firebase/functions`.

### Android Release Signing
يجب على مالك المشروع توليد keystore محليًا، ثم إنشاء:

```text
android/key.properties
release-keystore.jks
```

يجب عدم رفع هذه الملفات إلى Git أو مشاركتها علنًا.

### المتاجر والسياسات
يجب على مالك المشروع مراجعة واعتماد:

- سياسة الخصوصية.
- الشروط والأحكام.
- وصف التطبيق في المتجر.
- صور المتجر ولقطات الشاشة.

## 2. الأشياء التي لا يمكن تنفيذها داخل بيئة الذكاء الاصطناعي

- تشغيل `flutter pub get` لعدم توفر Flutter SDK.
- تشغيل `flutter analyze` لعدم توفر Dart/Flutter SDK.
- تشغيل `flutter test` لعدم توفر Flutter SDK.
- بناء APK أو AAB لعدم توفر Android SDK وسلسلة بناء Flutter.
- نشر Firebase Rules أو Cloud Functions لعدم توفر Firebase CLI وصلاحيات المالك.
- رفع التطبيق إلى Google Play أو App Store.
- شراء دومين أو استضافة أو اشتراكات خارجية.
- إنشاء مفاتيح توقيع Release الخاصة بالمالك.
- اختبار OTP الحقيقي لأن ذلك يتطلب Firebase فعلي ورقم هاتف حقيقي.

## 3. أي ميزات مؤجلة عمدًا

لا توجد ميزات من مراحل 1 إلى 12 مؤجلة عمدًا داخل الكود الحالي حسب نطاق المشروع. توجد فقط متطلبات خارجية لازمة لتفعيل الإنتاج الحقيقي، وأهمها Firebase وملفات التوقيع والبناء المحلي.

ملاحظة: الدفع الإلكتروني، الخرائط GPS، والمحادثة الداخلية لم تكن ضمن مراحل التنفيذ النهائية أو كانت ممنوعة في مراحل سابقة، لذلك لا تُعد نواقصًا في هذه النسخة.

## 4. المشكلات المعروفة

### عدم إمكانية تشغيل Backend الحقيقي قبل إعداد Firebase
- **الوصف:** التطبيق يعرض شاشة إعداد الإنتاج إذا لم تكن إعدادات Firebase الحقيقية مضافة.
- **السبب:** لا يمكن توليد مفاتيح Firebase أو ملفات Google الخاصة بالمالك داخل هذه البيئة.
- **طريقة الإصلاح:** تشغيل `flutterfire configure` وإضافة `google-services.json`، ثم نشر Rules وFunctions.

### عدم وجود APK/AAB داخل التسليم
- **الوصف:** ZIP يحتوي المشروع جاهزًا للبناء، ولا يحتوي ملف APK أو AAB.
- **السبب:** بيئة العمل لا تحتوي على Flutter SDK أو Android SDK.
- **طريقة الإصلاح:** تنفيذ أوامر البناء محليًا كما في `docs/release/BUILD_RELEASE_GUIDE.md`.

### iOS غير مبني فعليًا
- **الوصف:** يوجد توثيق إعداد iOS فقط، ولا يوجد بناء iOS فعلي.
- **السبب:** إنشاء وتشغيل iOS يتطلب macOS وXcode وحساب Apple Developer.
- **طريقة الإصلاح:** إنشاء منصة iOS من Flutter محليًا، إضافة `GoogleService-Info.plist`، ثم اختبارها عبر Xcode.

## 5. تقييم الجاهزية

- **نسبة اكتمال المشروع داخل ZIP:** 96%.
- **هل التطبيق جاهز للاستخدام الحقيقي؟** جاهز برمجيًا بعد إضافة Firebase الحقيقي ونشر قواعد الأمان وCloud Functions وبناء نسخة Release محليًا. بدون هذه الخطوات لا يكون جاهزًا للاستخدام الحقيقي.
- **هل التطبيق جاهز لاستخراج APK؟** نعم من ناحية بنية المشروع، لكن استخراج APK يتطلب تشغيله على جهاز يحتوي Flutter SDK وAndroid SDK وملف توقيع Release.
- **هل التطبيق جاهز للنشر مستقبلًا؟** نعم بعد اجتياز `flutter analyze` و`flutter test` وتجربة APK على جهاز حقيقي وإضافة بيانات المتجر.
- **آخر خطوة يجب أن تقوم بها أنت شخصيًا:** إنشاء مشروع Firebase الحقيقي وإضافة ملف `android/app/google-services.json` وتشغيل `flutterfire configure`، ثم تنفيذ:

```bash
flutter clean
flutter pub get
flutter analyze
flutter test
flutter build apk --release
flutter build appbundle --release
```
