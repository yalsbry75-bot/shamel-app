# دليل بناء نسخة الإنتاج — شامل

الإصدار الحالي بعد المراجعة النهائية: `1.0.1+13`.

## أوامر التحضير

```bash
flutter clean
flutter pub get
flutter analyze
flutter test
```

## إعداد Firebase قبل البناء

الطريقة المفضلة:

```bash
dart pub global activate flutterfire_cli
flutterfire configure --project=<firebase-project-id>
```

تأكد بعد ذلك من وجود:

```text
lib/firebase_options.dart
android/app/google-services.json
```

طريقة CI/CD البديلة: يمكن تمرير مفاتيح Firebase عبر `--dart-define` حسب المفاتيح الموجودة في `lib/firebase_options.dart`.

## إعداد توقيع Android

أنشئ keystore محليًا، ثم أنشئ الملف التالي خارج Git:

```text
android/key.properties
```

يمكن استخدام `android/key.properties.example` كقالب.

## بناء APK

```bash
flutter build apk --release
```

## بناء AAB

```bash
flutter build appbundle --release
```

## نشر Firebase Rules وCloud Functions

```bash
firebase deploy --only firestore:rules,firestore:indexes,storage
cd firebase/functions
npm install
cd ../..
firebase deploy --only functions
```

## فحص سريع بعد التثبيت

1. افتح التطبيق وتأكد من ظهور Splash بدون شاشة بيضاء.
2. جرّب تسجيل الدخول OTP برقم حقيقي.
3. جرّب إنشاء ملف مقدم خدمة ورفع صورة.
4. جرّب إنشاء طلب وتغيير حالته.
5. جرّب إضافة إعلان وفتح تفاصيله.
6. جرّب وصول إشعار عند إنشاء أو تغيير حالة الطلب.
7. افتح لوحة الإدارة وتحقق من صلاحيات المدير.
