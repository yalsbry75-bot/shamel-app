# قائمة إصدار شامل النهائية

## المشروع
- [x] اسم التطبيق ثابت: شامل.
- [x] Package Name ثابت: `com.shamel.app`.
- [x] الإصدار محدّث إلى `1.0.1+13`.
- [x] الهوية البصرية محفوظة.
- [x] لا توجد بيانات دخول إدارية داخل الكود.
- [x] لا توجد مفاتيح حساسة داخل المشروع.

## Firebase
- [x] طبقات Authentication / Firestore / Storage / FCM موجودة في الكود.
- [x] Firestore Rules موجودة.
- [x] Storage Rules موجودة ومشددة حسب المالك.
- [x] Firestore Indexes موجودة.
- [x] Cloud Function للإشعارات موجودة.
- [ ] يجب على مالك المشروع إضافة إعدادات Firebase الحقيقية.
- [ ] يجب نشر rules/functions من جهاز يملك صلاحيات Firebase.

## Android Release
- [x] إعدادات Release موجودة.
- [x] ProGuard موجود.
- [x] Notification Channel موجود.
- [x] توقيع Release جاهز عبر `key.properties`.
- [ ] يجب توليد keystore محليًا.
- [ ] يجب بناء APK/AAB على جهاز يحتوي Flutter وAndroid SDK.

## الاختبار النهائي المحلي
- [ ] `flutter pub get`.
- [ ] `flutter analyze`.
- [ ] `flutter test`.
- [ ] `flutter build apk --release`.
- [ ] تجربة APK على جهاز Android حقيقي.
