# Phase 3 Architecture — Core Authentication System

## الهدف

تجهيز نظام حسابات كامل قابل للربط الحقيقي لاحقًا دون إدخال Firebase أو Backend في هذه المرحلة.

## طبقات Auth

```text
auth/
 ├── data/
 │    ├── auth_repository.dart
 │    ├── auth_service.dart
 │    ├── secure_session_storage.dart
 ├── domain/
 │    ├── account_type.dart
 │    ├── auth_state.dart
 │    ├── user_model.dart
 ├── presentation/
      ├── controllers/auth_controller.dart
      ├── screens/login_screen.dart
      ├── screens/otp_screen.dart
      ├── screens/account_type_screen.dart
      ├── widgets/otp_code_field.dart
```

## تدفق المسؤوليات

```text
Screen → AuthController → AuthRepository → AuthService → SecureSessionStorage
```

- الشاشة لا تقرأ التخزين.
- الشاشة لا تعرف مصدر OTP.
- الشاشة لا تعرف طريقة إنشاء المستخدم.
- الاستبدال المستقبلي سيكون داخل `AuthService` فقط عند إدخال Backend/Firebase.

## Session Management

يتم حفظ الجلسة محليًا عبر `flutter_secure_storage`:

- `userId`
- `sessionStatus`
- `userType`
- قائمة المستخدمين المحلية السابقة، مع تعطيلها في نسخة الإنتاج

## OTP Production Policy

- تم تعطيل رمز الاختبار المحلي في نسخة الإنتاج، ويجب استخدام OTP الحقيقي عبر Firebase Authentication.
- مدة إعادة الإرسال: 60 ثانية.
- الحد الأقصى للمحاولات: 5.
- لا يتم كشف أخطاء داخلية للمستخدم.

## User Model

يحتوي `UserModel` على الحقول المطلوبة:

- `userId`
- `phoneNumber`
- `name`
- `userType`
- `createdAt`
- `isVerified`
- `isBlocked`
- `profileCompleted`
- `governorate`
- `district`

مع دعم:

- `fromJson`
- `toJson`
- `copyWith`
- equality

## Anti-Break Rules

- لا توجد شاشة Auth بدون Loading/Error handling.
- لا توجد عملية Auth من الواجهة مباشرة.
- لا يوجد خلط State Management.
- لا يوجد Firebase أو API حقيقي.
- لا يوجد تغيير في الهوية البصرية.
