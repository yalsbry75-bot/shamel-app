# Phase 2 Architecture

## القاعدة الأساسية

لا يتم إنشاء أي Feature بدون الطبقات التالية:

- data: خدمات ومصادر بيانات مستقبلية.
- domain: حالات ونماذج منطقية.
- presentation: الشاشات والـ controllers.

## State Management

تم اعتماد Riverpod فقط. لا يوجد Bloc أو Provider كلاسيكي أو GetX.

## UI Layer

الواجهة لا تتعامل مع API أو Firebase أو Database. أي تعامل مستقبلي يكون عبر Controller/Provider.

## Network Layer

`DisabledApiService` موجود كتحضير فقط، وجميع العمليات ترمي استثناء واضحًا لأن الشبكة ممنوعة في Phase 2.

## Error Prevention

كل Feature يحتوي على:

- State class.
- Controller.
- Service placeholder.
- UI screens.

كل شاشة يجب أن تستخدم Components موحدة قدر الإمكان.
