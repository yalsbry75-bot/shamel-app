# قائمة الشاشات المعتمدة في Phase 1

## Auth
1. Splash
2. Login برقم الهاتف
3. OTP
4. اختيار نوع الحساب

## العميل
1. Home
2. Categories
3. Search
4. Service Details
5. Create Order
6. Orders
7. Favorites
8. Notifications
9. Profile

## مقدم الخدمة
1. Dashboard
2. Incoming Orders
3. Services Management
4. Subscription
5. Business Profile

## عامة
1. Ads Page
2. Settings
3. Support

## قاعدة اعتماد التصميم
كل شاشة لها نسختان داخل مجلد التصميم:

- Wireframe منخفض التفاصيل.
- High Fidelity بتطبيق الهوية البصرية.
