# Design System — شامل

## Tokens

### Colors
- Primary: `#0A84FF`
- Background: `#000000`
- Surface: `#1C1C1E`
- Accent Gold: `#F5C542`
- Text Primary: `#FFFFFF`
- Text Secondary: `#8E8E93`
- Border: `rgba(255,255,255,0.12)`
- Glass Fill: `rgba(28,28,30,0.72)`

### Radius
- Small: 14px
- Medium: 20px
- Large: 28px
- Full: 999px

### Spacing
- XS: 4px
- SM: 8px
- MD: 16px
- LG: 24px
- XL: 32px
- XXL: 48px

### Shadow
- Light: `0 8px 24px rgba(0,0,0,0.22)`
- Premium: `0 18px 50px rgba(10,132,255,0.16)`

## Components

### Primary Button
- خلفية أزرق Primary.
- ارتفاع 56px.
- Radius 20px.
- نص أبيض SemiBold.
- يستخدم للإجراء الأساسي في الشاشة.

### Secondary Button
- خلفية Glass Fill.
- Border أبيض شفاف.
- ارتفاع 56px.
- Radius 20px.
- يستخدم للإجراء الثانوي.

### Input Field
- خلفية Surface.
- Border خفيف.
- Radius 20px.
- Padding أفقي 16px.
- حالة تحميل مؤقتة بلون Text Secondary.

### Service Card
- صورة/أيقونة في الأعلى أو يمين البطاقة.
- اسم الخدمة.
- السعر التقديري.
- التقييم.
- المسافة أو نطاق الخدمة.
- CTA صغير: عرض التفاصيل.

### Provider Card
- صورة أو رمز مقدم الخدمة.
- الاسم التجاري.
- التقييم.
- عدد الطلبات المنجزة.
- حالة التوفر.

### Order Card
- رقم الطلب.
- نوع الخدمة.
- الحالة.
- التاريخ.
- زر متابعة.

### Ad Card
- عنوان الإعلان.
- وصف قصير.
- زر استكشاف.
- تمييز بصري ذهبي خفيف.

### Bottom Navigation
- خلفية Blur/Glass.
- ارتفاع 76px.
- أيقونات خطية.
- العنصر النشط أزرق.
- العنصر غير النشط Text Secondary.
