# Database Design — ERD فقط

## الكيانات الأساسية

### users
يمثل حساب العميل أو مقدم الخدمة.

الحقول المقترحة:
- id
- full_name
- phone
- account_type
- avatar_url
- created_at
- status

### providers
يمثل الملف التجاري لمقدم الخدمة.

الحقول المقترحة:
- id
- user_id
- business_name
- category_id
- description
- location
- rating_average
- rating_count
- is_available
- subscription_id

### categories
تصنيفات الخدمات.

الحقول المقترحة:
- id
- name
- icon
- sort_order
- is_active

### services
الخدمات التي يقدمها مقدم الخدمة.

الحقول المقترحة:
- id
- provider_id
- category_id
- title
- description
- price_from
- estimated_time
- is_active

### orders
طلبات العملاء.

الحقول المقترحة:
- id
- user_id
- provider_id
- service_id
- status
- description
- location
- scheduled_at
- created_at

### ads
الإعلانات داخل التطبيق.

الحقول المقترحة:
- id
- title
- description
- image_url
- target_type
- target_id
- starts_at
- ends_at
- is_active

### subscriptions
اشتراكات مقدمي الخدمة.

الحقول المقترحة:
- id
- provider_id
- plan_name
- price
- starts_at
- ends_at
- status

### notifications
إشعارات المستخدمين.

الحقول المقترحة:
- id
- user_id
- title
- body
- type
- is_read
- created_at

### ratings
تقييمات الطلبات ومقدمي الخدمة.

الحقول المقترحة:
- id
- order_id
- user_id
- provider_id
- rating
- comment
- created_at

### reports
بلاغات المستخدمين.

الحقول المقترحة:
- id
- user_id
- target_type
- target_id
- reason
- status
- created_at

## العلاقات الأساسية

- user يمكن أن يكون provider إذا كان نوع الحساب مقدم خدمة.
- provider يمتلك services متعددة.
- category تحتوي services متعددة.
- user ينشئ orders متعددة.
- order يرتبط بـ service وprovider وuser.
- provider يمتلك subscriptions.
- user يستقبل notifications.
- order يمكن أن ينتج عنه rating.
- user يمكن أن ينشئ reports.

## ملاحظة
هذا التصميم مبدئي لمرحلة التخطيط فقط، ويحتاج في المراحل القادمة إلى تحويله إلى نموذج قاعدة بيانات فعلي حسب التقنية المختارة.
