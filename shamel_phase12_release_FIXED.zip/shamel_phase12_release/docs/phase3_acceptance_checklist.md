# Phase 3 Acceptance Checklist

## Authentication

- [x] شاشة تسجيل الدخول برقم الهاتف.
- [x] كود الدولة اليمني +967.
- [x] منع الرقم الفارغ.
- [x] منع الأحرف داخل الرقم.
- [x] منع الرقم غير المكتمل.
- [x] شاشة OTP من 6 خانات.
- [x] دعم اللصق داخل OTP.
- [x] عداد إعادة الإرسال 60 ثانية.
- [x] Loading أثناء التحقق.
- [x] رسائل خطأ آمنة.
- [x] تحديد محاولات OTP.

## User Management

- [x] إنشاء مستخدم تلقائيًا بعد نجاح OTP.
- [x] منع تكرار الحساب بنفس الرقم محليًا.
- [x] اختيار نوع الحساب.
- [x] منع تغيير نوع الحساب بعد الحفظ.
- [x] ملف شخصي يحتوي الاسم ورقم الهاتف والنوع والمحافظة والمديرية.
- [x] حفظ تعديل بيانات الملف الشخصي.

## Session

- [x] حفظ الجلسة عبر Secure Storage.
- [x] التوجيه حسب حالة الجلسة عند فتح التطبيق.
- [x] تسجيل الخروج.

## Architecture

- [x] Riverpod فقط.
- [x] Auth Controller.
- [x] Auth Repository.
- [x] Auth Service.
- [x] Secure Storage isolated layer.
- [x] User Model كامل.
- [x] لا Firebase.
- [x] لا Backend.
- [x] لا API حقيقي.

## Manual Test Flow

- [ ] `flutter pub get`.
- [ ] `flutter run`.
- [ ] Login برقم يمني.
- [ ] OTP حقيقي عبر Firebase Authentication بعد تفعيل إعدادات المشروع.
- [ ] اختيار نوع الحساب.
- [ ] حفظ الملف الشخصي.
- [ ] إغلاق وفتح التطبيق للتأكد من الجلسة.
- [ ] تسجيل الخروج.
