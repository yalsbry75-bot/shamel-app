# قائمة جاهزية الإنتاج — شامل Phase 11

## البنية

- [x] المشروع مبني فوق Phase 10 بدون إنشاء مشروع جديد.
- [x] Clean Architecture محفوظة.
- [x] لوحة الإدارة منفصلة داخل `lib/admin_panel`.
- [x] طبقات Firebase موجودة داخل `core/database`, `core/authentication`, `core/storage`, `core/notifications`.
- [x] طبقات الإنتاج موجودة: `security`, `monitoring`, `logger`, `cache`, `performance`, `validators`.

## الحسابات والجلسات

- [x] Firebase Auth هو مسار المصادقة الفعلي.
- [x] تم تعطيل المصادقة المحلية في إصدار الإنتاج.
- [x] جلسة المستخدم محفوظة عبر Firebase Auth وSecure Storage.
- [x] مسار المدير يعتمد على Firebase Auth ووثيقة `admins/{uid}`.

## البيانات

- [x] Firestore collections موثقة.
- [x] لا توجد بيانات ثابتة مدمجة لملء السوق أو لوحة الإدارة.
- [x] مناطق العمل مرتبطة بـ `providerId`.
- [x] قواعد Firestore تغطي المستخدمين، مقدمي الخدمات، الخدمات، الطلبات، الإعلانات، التقييمات، الاشتراكات، الإشعارات، المفضلة، الإدارة، والسجلات.

## التخزين

- [x] ضغط الصور قبل الرفع.
- [x] إنشاء صور مصغرة.
- [x] فحص نوع الملف.
- [x] فحص الحجم.
- [x] Storage Rules موجودة.

## الإشعارات والمراقبة

- [x] FCM token registration موجود.
- [x] Cloud Function لإرسال الإشعارات موجودة.
- [x] Crashlytics مدمج على مستوى الكود.
- [x] Firebase Performance مدمج على مستوى الكود.
- [x] سجلات أخطاء التطبيق تظهر للمدير عند توفر بيانات Firestore.

## تجربة المستخدم

- [x] حالات التحميل والخطأ والفارغ موجودة في الميزات الأساسية.
- [x] Offline Banner موجود.
- [x] التصميم والهوية لم يتم تغييرهما.
- [x] RTL مفعل للعربية.

## يلزم تنفيذه محليًا قبل النشر

- [ ] تشغيل `flutter pub get`.
- [ ] تشغيل `flutter analyze`.
- [ ] تشغيل `flutter test`.
- [ ] تشغيل التطبيق على Android حقيقي.
- [ ] تشغيل التطبيق على Emulator.
- [ ] تفعيل Firebase Authentication Phone.
- [ ] إضافة SHA-1/SHA-256 لتطبيق Android.
- [ ] نشر Firestore Rules وStorage Rules والفهارس.
- [ ] نشر Cloud Functions.
- [ ] اختبار OTP حقيقي.
- [ ] اختبار رفع صور حقيقي.
- [ ] اختبار إشعار FCM حقيقي.
- [ ] بناء APK/AAB بنسخة Release.
