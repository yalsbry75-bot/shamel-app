# إعداد Backend — Phase 9

## 1. Firebase project
أنشئ مشروع Firebase ثم نفذ:

```bash
firebase login
dart pub global activate flutterfire_cli
flutterfire configure --project=<project-id>
```

استبدل الملف الناتج `lib/firebase_options.dart` بالملف الحقيقي.

## 2. Authentication
فعّل من Firebase Console:
- Phone Authentication.
- Email/Password للمدير.

## 3. Firestore
فعّل Cloud Firestore، ثم انشر القواعد والفهارس:

```bash
firebase deploy --only firestore:rules,firestore:indexes
```

## 4. Storage
فعّل Cloud Storage، ثم انشر القواعد:

```bash
firebase deploy --only storage
```

## 5. FCM
أضف إعدادات FCM حسب المنصة:
- Android: تأكد من package name `com.shamel.app` وإعداد SHA-1/SHA-256 للمصادقة بالهاتف.
- iOS: أضف APNs key داخل Firebase Console.

## 6. Admin
أنشئ مستخدم مدير في Firebase Auth، ثم أضف وثيقة داخل `admins/{uid}` بالدور المناسب.

## 7. تشغيل محلي
```bash
flutter clean
flutter pub get
flutter run
```

## ملاحظة
بدون إعداد Firebase الحقيقي، سيظل المشروع مهيأ برمجيًا فقط ولن يتصل بقاعدة بيانات فعلية.

## Push notification backend function

A Cloud Function is included in `firebase/functions` to send FCM messages when a document is created in `notifications`. Deploy it with:

```bash
cd firebase/functions
npm install
cd ../..
firebase deploy --only functions
```

## Phase 10 additions: Crashlytics and Performance

After running `flutterfire configure`, enable these Firebase products in the Firebase Console:

1. Crashlytics for Android/iOS/macOS builds.
2. Performance Monitoring for Android/iOS/web where applicable.
3. Firestore collection `appErrorLogs` for application-level non-crash logs.

Deploy updated rules and indexes:

```bash
firebase deploy --only firestore:rules,storage,firestore:indexes
```

Then verify locally:

```bash
flutter pub get
flutter analyze
flutter test
flutter run --release
```

## إعدادات الإصدار النهائي بعد المراجعة

يدعم المشروع طريقتين لإعداد Firebase:

1. الطريقة المفضلة: تشغيل `flutterfire configure` واستبدال `lib/firebase_options.dart` بالملف الناتج.
2. طريقة CI/CD: تمرير قيم Firebase عبر `--dart-define` حسب المفاتيح الموجودة داخل `lib/firebase_options.dart`.

تمت إضافة `.firebaserc.example`. انسخه إلى `.firebaserc` وعدّل معرف مشروع Firebase قبل النشر.

> لا تضف مفاتيح خاصة أو ملفات توقيع أو ملفات إعداد إنتاجية حساسة إلى مستودع عام.
