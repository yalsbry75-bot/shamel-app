# الوثائق النهائية لتطبيق شامل — Production Release

## 1. معلومات التطبيق

- اسم التطبيق: شامل
- الشعار: كل خدماتك في مكان واحد
- Package Name: `com.shamel.app`
- الإصدار: `1.0.1+13`
- الواجهة الأساسية: العربية RTL
- الثيم: Dark Premium / Apple Style
- إدارة الحالة: Riverpod
- Backend المستهدف: Firebase

## 2. حالة النسخة النهائية

هذه النسخة هي حزمة Production Release جاهزة للتجهيز المحلي والبناء، مع الحفاظ على جميع ميزات المراحل السابقة. تم تجهيز المشروع بحيث لا يحدث انهيار عند غياب إعداد Firebase الحقيقي؛ بدلًا من ذلك تظهر شاشة إعداد إنتاج واضحة تطلب إكمال الربط.

لا يمكن اعتبار APK/AAB النهائي جاهزًا للاستخدام الحقيقي إلا بعد تنفيذ الخطوات التالية محليًا:

1. إنشاء مشروع Firebase حقيقي.
2. تشغيل FlutterFire CLI لتوليد `lib/firebase_options.dart` الحقيقي.
3. إضافة `android/app/google-services.json`.
4. إنشاء مفتاح توقيع Android Release.
5. تشغيل أوامر البناء والاختبار الموضحة أدناه.

## 3. المتطلبات المحلية

- Flutter SDK مثبت ومضاف إلى PATH.
- Dart SDK المتوافق مع Flutter.
- Android Studio أو VS Code.
- JDK 17.
- Firebase CLI.
- FlutterFire CLI.
- حساب Firebase مفعل.
- جهاز Android حقيقي أو Emulator للاختبار.

## 4. إعداد Firebase النهائي

من جذر المشروع:

```bash
firebase login
firebase projects:list
flutterfire configure --project=<your-firebase-project-id>
```

يجب التأكد من أن تطبيق Android داخل Firebase يستخدم:

```text
com.shamel.app
```

بعد التهيئة، يجب أن تكون الملفات التالية موجودة:

```text
lib/firebase_options.dart
android/app/google-services.json
```

لتفعيل قواعد Firebase:

```bash
firebase deploy --only firestore:rules,firestore:indexes,storage
firebase deploy --only functions
```

## 5. إعداد توقيع Android Release

إنشاء keystore:

```bash
keytool -genkey -v -keystore release-keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias shamel-release
```

انسخ ملف `android/key.properties.example` إلى:

```text
android/key.properties
```

ثم عدّل القيم الحقيقية:

```properties
storePassword=YOUR_STORE_PASSWORD
keyPassword=YOUR_KEY_PASSWORD
keyAlias=shamel-release
storeFile=../release-keystore.jks
```

لا ترفع ملف `key.properties` أو ملف keystore إلى أي مستودع عام.

## 6. تشغيل المشروع

```bash
flutter clean
flutter pub get
flutter analyze
flutter test
flutter run --release
```

## 7. بناء APK للتثبيت المباشر

```bash
flutter build apk --release
```

المخرجات المتوقعة:

```text
build/app/outputs/flutter-apk/app-release.apk
```

## 8. بناء AAB للنشر مستقبلًا

```bash
flutter build appbundle --release
```

المخرجات المتوقعة:

```text
build/app/outputs/bundle/release/app-release.aab
```

## 9. الاختبار النهائي بعد البناء

### العميل

- تثبيت التطبيق.
- فتح التطبيق بدون شاشة بيضاء أو Crash.
- تسجيل الدخول برقم الهاتف.
- إدخال OTP الحقيقي.
- البحث عن الخدمات.
- فتح مقدم خدمة.
- إنشاء طلب.
- متابعة الحالة.
- تقييم الخدمة.
- تصفح الإعلانات.

### مقدم الخدمة

- تسجيل الدخول.
- إنشاء الملف التجاري.
- إضافة الخدمات.
- رفع الصور.
- استقبال الطلبات.
- قبول الطلبات ورفضها.
- تحديث حالة الطلب.
- مراجعة الاشتراك والتقييمات.

### المدير

- تسجيل الدخول إلى `/admin/login`.
- التحقق من وثيقة المدير داخل `admins/{uid}`.
- إدارة المستخدمين.
- إدارة مقدمي الخدمات.
- إدارة الطلبات.
- إدارة الإعلانات.
- إدارة الاشتراكات.
- إدارة البلاغات.
- التحقق من الصلاحيات حسب الدور.

## 10. هيكل المشروع النهائي

```text
lib/
 ├── admin_panel/
 ├── core/
 │    ├── api/
 │    ├── authentication/
 │    ├── cache/
 │    ├── config/
 │    ├── database/
 │    ├── errors/
 │    ├── logger/
 │    ├── monitoring/
 │    ├── network/
 │    ├── notifications/
 │    ├── performance/
 │    ├── security/
 │    ├── storage/
 │    ├── theme/
 │    ├── utils/
 │    └── widgets/
 ├── features/
 │    ├── ads/
 │    ├── auth/
 │    ├── categories/
 │    ├── favorites/
 │    ├── home/
 │    ├── marketplace/
 │    ├── notifications/
 │    ├── orders/
 │    ├── profile/
 │    ├── provider/
 │    ├── rating/
 │    ├── release/
 │    ├── search/
 │    ├── services/
 │    └── subscription/
 ├── models/
 ├── routes/
 └── shared/
```

## 11. ملاحظات مهمة للمطور القادم

- لا تستخدم بيانات محلية بديلة في الإنتاج.
- لا تفعّل دخول مدير ثابت.
- لا تضع مفاتيح Firebase أو keystore في Git.
- لا تغيّر Package Name بعد ربط Firebase إلا إذا أعدت إعداد Firebase بالكامل.
- يجب تشغيل `flutter analyze` و`flutter test` قبل أي نشر.
- يجب اختبار التطبيق على جهاز Android حقيقي قبل توزيع APK.

