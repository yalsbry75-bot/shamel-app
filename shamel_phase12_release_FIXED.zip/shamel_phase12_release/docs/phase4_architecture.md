# Phase 4 Architecture — شامل

## الهدف
تحويل جزء مقدم الخدمة إلى نظام قابل للتوسع دون ربط Backend، مع فصل واضح بين الواجهة، الحالة، الخدمة، والنماذج.

## الطبقات

### Provider Feature
- Domain: نماذج الملف التجاري والخدمات والصور ومناطق الخدمة وحالات النشاط.
- Data: Repository + Local Service للتخزين المحلي.
- Presentation: Controller + Screens.

### Subscription Feature
- Domain: SubscriptionModel وحالات الاشتراك والدفع والخطط.
- Data: Repository + Local Service.
- Presentation: Controller + Subscription Screen.

### Rating Feature
- Domain: RatingModel + RatingSummary + RatingState.
- Data: Repository + Local Service.
- Presentation: Controller.

## قاعدة الربط المستقبلية
عند إضافة Backend لاحقًا يتم استبدال Local Services فقط، مع بقاء Controllers وUI وModels دون تغيير جوهري.
