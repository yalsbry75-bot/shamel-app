const { onDocumentCreated } = require('firebase-functions/v2/firestore');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');
const { getMessaging } = require('firebase-admin/messaging');

initializeApp();

exports.sendNotificationOnCreate = onDocumentCreated('notifications/{notificationId}', async (event) => {
  const snapshot = event.data;
  if (!snapshot) return;
  const notification = snapshot.data();
  const userId = (notification.userId || '').toString();
  if (!userId) return;

  const db = getFirestore();
  const devices = await db.collection('userDevices').where('userId', '==', userId).limit(20).get();
  const tokens = devices.docs.map((doc) => doc.id).filter(Boolean);
  if (tokens.length === 0) return;

  const payload = {
    notification: {
      title: (notification.title || 'شامل').toString().substring(0, 120),
      body: (notification.message || '').toString().substring(0, 240),
    },
    data: {
      notificationId: event.params.notificationId,
      type: (notification.type || 'system').toString(),
      orderId: (notification.orderId || '').toString(),
      adId: (notification.adId || '').toString(),
    },
    tokens,
  };

  const response = await getMessaging().sendEachForMulticast(payload);
  const invalidTokens = [];
  response.responses.forEach((item, index) => {
    if (!item.success) {
      const code = item.error && item.error.code ? item.error.code : '';
      if (code.includes('registration-token-not-registered') || code.includes('invalid-argument')) {
        invalidTokens.push(tokens[index]);
      }
    }
  });

  const batch = db.batch();
  invalidTokens.forEach((token) => batch.delete(db.collection('userDevices').doc(token)));
  batch.set(snapshot.ref, {
    pushDelivery: {
      attemptedAt: FieldValue.serverTimestamp(),
      successCount: response.successCount,
      failureCount: response.failureCount,
      invalidTokenCount: invalidTokens.length,
    },
  }, { merge: true });
  await batch.commit();
});
