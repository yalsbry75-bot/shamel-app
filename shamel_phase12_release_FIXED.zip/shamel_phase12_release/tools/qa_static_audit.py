#!/usr/bin/env python3
"""Static QA checks that do not require Flutter/Dart SDK.

Checks:
- Missing relative Dart imports.
- Basic bracket balance for Dart source files.
- Development markers and fixed credentials in production-facing files.
- Required production documentation files.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PRODUCTION_SCOPES = [ROOT / "lib", ROOT / "firebase", ROOT / "docs", ROOT / "README.md", ROOT / "test"]
FORBIDDEN_PATTERNS = re.compile(
    "|".join([
        r"\b" + ("TO" + "DO") + r"\b",
        r"\b" + ("FIX" + "ME") + r"\b",
        r"\b" + ("mo" + "ck") + r"\b",
        r"\b" + ("dum" + "my") + r"\b",
        r"\b" + ("sam" + "ple") + r"\b",
        r"\b" + ("de" + "mo") + r"\b",
        re.escape("تج" + "ريبي"),
        re.escape("123" + "456"),
        re.escape("system_" + "seed"),
        re.escape("seed_"),
        re.escape("admin@" + "shamel"),
        re.escape("Admin" + "@"),
    ]),
    re.IGNORECASE,
)
REQUIRED_DOCS = [
    ROOT / "README.md",
    ROOT / "PLATFORM_NOTE.md",
    ROOT / "docs" / "BACKEND_SETUP.md",
    ROOT / "docs" / "PRODUCTION_OPTIMIZATION.md",
    ROOT / "docs" / "QA_TEST_PLAN.md",
    ROOT / "docs" / "QA_RESULTS.md",
    ROOT / "docs" / "PRODUCTION_READINESS_CHECKLIST.md",
    ROOT / "FINAL_MASTER_REVIEW_REPORT.md",
    ROOT / "PENDING_ACTIONS_REPORT.md",
    ROOT / "docs" / "release" / "BUILD_RELEASE_GUIDE.md",
]


def dart_files() -> list[Path]:
    return sorted((ROOT / "lib").rglob("*.dart")) + sorted((ROOT / "test").rglob("*.dart"))


def check_missing_imports() -> list[str]:
    issues: list[str] = []
    for file in dart_files():
        text = file.read_text(encoding="utf-8", errors="ignore")
        for match in re.finditer(r"import\s+'([^']+)';", text):
            target = match.group(1)
            if target.startswith(("dart:", "package:")):
                continue
            if not (file.parent / target).resolve().exists():
                issues.append(f"{file.relative_to(ROOT)} -> {target}")
    return issues


def check_brackets() -> list[str]:
    issues: list[str] = []
    for file in dart_files():
        text = file.read_text(encoding="utf-8", errors="ignore")
        pairs = [("{", "}"), ("(", ")"), ("[", "]")]
        for left, right in pairs:
            if text.count(left) != text.count(right):
                issues.append(f"{file.relative_to(ROOT)} has unbalanced {left}{right}")
    return issues


def check_forbidden_markers() -> list[str]:
    issues: list[str] = []
    for scope in PRODUCTION_SCOPES:
        files = [scope] if scope.is_file() else sorted(scope.rglob("*"))
        for file in files:
            if not file.is_file() or file.suffix in {".png", ".jpg", ".jpeg", ".webp", ".svg"}:
                continue
            text = file.read_text(encoding="utf-8", errors="ignore")
            for line_no, line in enumerate(text.splitlines(), start=1):
                if FORBIDDEN_PATTERNS.search(line):
                    issues.append(f"{file.relative_to(ROOT)}:{line_no}: {line.strip()}")
    return issues


def check_required_docs() -> list[str]:
    return [str(path.relative_to(ROOT)) for path in REQUIRED_DOCS if not path.exists()]


def main() -> int:
    checks = {
        "missing_relative_imports": check_missing_imports(),
        "unbalanced_dart_brackets": check_brackets(),
        "forbidden_dev_markers": check_forbidden_markers(),
        "missing_required_docs": check_required_docs(),
    }
    failed = False
    for name, issues in checks.items():
        status = "PASS" if not issues else "FAIL"
        print(f"{name}: {status}")
        for issue in issues[:50]:
            print(f"  - {issue}")
        if len(issues) > 50:
            print(f"  ... {len(issues) - 50} more")
        failed = failed or bool(issues)
    print(f"dart_files_checked: {len(dart_files())}")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
